(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.fault_response = {
  "id": "fault_response",
  "title": "Fault Script with Work Order Creation",
  "sections": [
    {
      "title": "WO Details",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_originatorpriority",
          "level": 1,
          "label": "Originator Priority",
          "type": "text",
          "required": false
        },
        {
          "id": "xa_ws_workgroup",
          "level": 1,
          "label": "Work Group",
          "type": "text",
          "required": false
        },
        {
          "id": "xa_ws_mainttype",
          "level": 1,
          "label": "Maintenance Type *",
          "type": "select",
          "required": true,
          "options": [
            "BREAKDOWN",
            "CORRECTIVE",
            "NOT APPLICABLE",
            "PREVENTIVE MAINTENANCE"
          ]
        },
        {
          "id": "xa_ws_userstatus",
          "level": 1,
          "label": "User Status *",
          "type": "number",
          "required": true
        },
        {
          "id": "xa_ws_wotype",
          "level": 1,
          "label": "Work Order Type *",
          "type": "select",
          "required": true,
          "options": [
            "ADMINISTRATION",
            "CAPITAL",
            "MAINTENANCE"
          ]
        }
      ]
    },
    {
      "title": "Fault Asset Information",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_fswwoc_yes_no_17",
          "level": 1,
          "label": "Is this a network fault? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ]
        }
      ]
    },
    {
      "title": "Network Fault",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_fswwoc_19",
          "level": 2,
          "label": "Describe the fault as found: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_1508",
          "level": 2,
          "label": "Please upload a picture of the faulted asset upon arrival *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_13478",
          "level": 2,
          "label": "Would you like to attach another photo? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_13479",
          "level": 3,
          "label": "Please upload additional photo *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_aref_13478",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_13480",
          "level": 3,
          "label": "Would you like to attach another photo? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_aref_13478",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_13481",
          "level": 4,
          "label": "Please upload additional photo *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_aref_13480",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_1308",
          "level": 2,
          "label": "Dispatch Call Received From *",
          "type": "select",
          "required": true,
          "options": [
            "CALLCARE",
            "CONTROL ROOM",
            "HSL",
            "OTHER"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_1309",
          "level": 3,
          "label": "Other: Please specify *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_aref_1308",
              "values": [
                "OTHER"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_11524",
          "level": 2,
          "label": "Time of Dispatch (please be as accurate as possible by referencing dispatch call / text) *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_1312",
          "level": 2,
          "label": "Time of arrival at Fault location *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_29",
          "level": 2,
          "label": "Did the fault originate from a network or a private asset? *",
          "type": "select",
          "required": true,
          "options": [
            "Customer Asset",
            "Network Asset"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_30",
          "level": 2,
          "label": "Faulted Asset ID *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_31",
          "level": 2,
          "label": "Which asset type failed? *",
          "type": "select",
          "required": true,
          "options": [
            "CABLE JOINT",
            "CROSSARM",
            "DDO CARRIER",
            "DDO FUSE",
            "HV UNDERGROUND CABLE",
            "INSULATOR",
            "LIGHTNING ARRESTORS",
            "LINK PILLAR",
            "LV SERVICE FUSE",
            "LV SERVICE FUSE CARRIER",
            "LV UNDERGROUND CABLE",
            "OTHER",
            "OVERHEAD CONDUCTOR",
            "OVERHEAD JUMPER",
            "OVERHEAD SWITCHGEAR (ABS)",
            "OVERHEAD SWITCHGEAR (AUTOMATED)",
            "OVERHEAD SWITCHGEAR (ENCLOSED)",
            "POLE",
            "PROTECTION RELAY",
            "RMU",
            "SERVICE PILLAR",
            "TRANSFORMER (DISTRIBUTION)",
            "TRANSFORMER (POWER TX)",
            "ZONE SUB CIRCUIT BREAKER"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_32",
          "level": 3,
          "label": "Other failed asset type: Please specify *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_31",
              "values": [
                "OTHER"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_fault_cause",
          "level": 2,
          "label": "Fault Cause *",
          "type": "select",
          "required": true,
          "options": [
            "3RD PARTY INTERFERENCE",
            "ADVERSE ENVIRONMENT",
            "ADVERSE WEATHER",
            "DEFECTIVE EQUIPMENT",
            "HUMAN ERROR",
            "LIGHTNING",
            "OTHER",
            "UNKNOWN CAUSE",
            "VEGETATION",
            "WILDLIFE"
          ],
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_1342",
          "level": 3,
          "label": "Other or Unknown fault cause: Please specify *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_1317",
          "level": 2,
          "label": "Fault voltage level *",
          "type": "select",
          "required": true,
          "options": [
            "0.4KV",
            "11KV",
            "33KV",
            "50KV"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Capital WIP Assets",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_fswwoc_yes_no_37",
          "level": 2,
          "label": "Did the job involve any asset replacement or repairs other than replacing links or reclosing? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_38",
          "level": 3,
          "label": "Please select all of the asset types that have been replaced (or N/A) *",
          "type": "select",
          "required": false,
          "options": [
            "ABS",
            "CROSSARM",
            "DISTRIBUTION TRANSFORMER",
            "ENCLOSED SWITCH",
            "FUSE/DDO CARRIERS (FULL SET)",
            "LINK PILLAR",
            "PEANUT TRANSFORMER",
            "POLE",
            "RADIO/COMMS EQUIPMENT",
            "RECLOSER",
            "RMU",
            "SECTIONALISER",
            "SERVICE PILLAR"
          ],
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_37",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_yes_no_39",
          "level": 4,
          "label": "Have you replaced all of the crossarms on a pole? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_37",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_yes_no_replaced_phases",
          "level": 3,
          "label": "Have you replaced all phases of any cable/conductor? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_37",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_41",
          "level": 4,
          "label": "What length of circuit (all phases) has been replaced? *",
          "type": "number",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_37",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_replaced_phases",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Not a Network Fault",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_fswwoc_44",
          "level": 2,
          "label": "What is the job type? *",
          "type": "select",
          "required": true,
          "options": [
            "CLOSE APPROACH",
            "HIGH LOAD",
            "LV COVER-UP",
            "OTHER",
            "PRIVATE ONLY FAULT",
            "SAFETY DISCONNECT/RECONNECT"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_45",
          "level": 3,
          "label": "Other job type: please specify *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_fswwoc_44",
              "values": [
                "OTHER"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_48",
          "level": 2,
          "label": "Details. Include name & phone num and any other relevant details (rego, police case num, adderss, etc..) *",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Third party charges",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_fswwoc_yes_no_47",
          "level": 1,
          "label": "Is this chargeable to a third party? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ]
        }
      ]
    },
    {
      "title": "Meter or relay bypass",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_fswwoc_bypassed",
          "level": 1,
          "label": "Has a meter or relay been bypassed? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ]
        }
      ]
    },
    {
      "title": "Log Details",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_description",
          "level": 1,
          "label": "Site Address *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_requiredbydate",
          "level": 1,
          "label": "Date of fault *",
          "type": "date",
          "required": true
        },
        {
          "id": "xa_ws_fswwoc_aref_13483",
          "level": 1,
          "label": "Is/was HV switching required? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ]
        }
      ]
    },
    {
      "title": "HV switching",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_fswwoc_aref_13484",
          "level": 2,
          "label": "Switching Schedule Number *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_aref_13483",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "No HV switching",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_fswwoc_aref_13485",
          "level": 2,
          "label": "CallCare Number *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_aref_13483",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Works undertaken",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_extendedtext",
          "level": 1,
          "label": "Works Undertaken (Provide detailed description of works carried out) *",
          "type": "text",
          "required": true
        }
      ]
    },
    {
      "title": "Test Results",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_fswwoc_yes_no_62",
          "level": 1,
          "label": "Are tests required? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ]
        },
        {
          "id": "xa_ws_fswwoc_63",
          "level": 2,
          "label": "Polarity (Independant Earth): *",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_64",
          "level": 2,
          "label": "Voltage (Phase - Neutral): *",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_65",
          "level": 2,
          "label": "Insulation Resistance: *",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_66",
          "level": 2,
          "label": "Earth Fault Loop Impedance: *",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_67",
          "level": 2,
          "label": "Phase Rotation: *",
          "type": "select",
          "required": false,
          "options": [
            "ANTICLOCKWISE",
            "CLOCKWISE",
            "N/A"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_68",
          "level": 2,
          "label": "Additional Test Details: *",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_yes_no_69",
          "level": 2,
          "label": "Have multiple tests been conducted? *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ],
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_70",
          "level": 3,
          "label": "Please provide the address and test results of the other tests: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_69",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Fault Completion",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_fswwoc_yes_no_72",
          "level": 1,
          "label": "Has the fault been completed? (select no if additional work is yet to be completed) *",
          "type": "radio",
          "required": true,
          "options": [
            "YES",
            "NO"
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_1496",
          "level": 2,
          "label": "What time was the fault completed? *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_72",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_aref_10535",
          "level": 1,
          "label": "Please upload a picture of the asset after your work has been completed *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_fswwoc_75",
          "level": 1,
          "label": "Additional Comments / Details: *",
          "type": "text",
          "required": false
        }
      ]
    }
  ]
};
})();
