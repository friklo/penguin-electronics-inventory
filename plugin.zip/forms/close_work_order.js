(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.close_work_order = {
  "id": "close_work_order",
  "title": "Close Work Order Task",
  "sections": [
    {
      "title": "Work Order Task Closure Script",
      "fields": [
        {
          "id": "xa_ws_cwot_2",
          "label": "Close Date *",
          "type": "date",
          "required": true
        },
        {
          "id": "xa_ws_cwot_3",
          "label": "Close Time *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cwot_4",
          "label": "Completion Comments",
          "type": "text",
          "required": false
        },
        {
          "id": "xa_ws_cwot_5",
          "label": "Completion Code *",
          "type": "select",
          "options": [
            "ALL COMPLETE",
            "CANCELLED"
          ],
          "required": true
        }
      ]
    }
  ]
};
})();
