(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.rmu_oil_checklist = {
  "id": "rmu_oil_checklist",
  "title": "RMU \u2013 OIL MAINTENANCE CHECKLIST",
  "sections": [
    {
      "title": "RMU \u2013 OIL MAINTENANCE CHECKLIST",
      "fields": [
        {
          "id": "rmuo_asset_num",
          "label": "Asset Number",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_project_no",
          "label": "Project No.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_location",
          "label": "Location",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_feeder",
          "label": "Feeder",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_manufacturer",
          "label": "Manufacturer",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_model",
          "label": "Model",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_serial_no",
          "label": "Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_voltage",
          "label": "Voltage",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_test_equip",
          "label": "Test Equipment/Tools Used",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_test_asset_no",
          "label": "Asset No.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_calib_date",
          "label": "Test/Calibration Date",
          "type": "date",
          "required": false
        },
        {
          "id": "rmuo_expiry_date",
          "label": "Expiry Date",
          "type": "date",
          "required": false
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "rmuo_task1_status",
          "label": "Check for signs of imminent failure such as odours or unusual noises.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check for signs of imminent failure such as odours or unusual noises."
        },
        {
          "id": "rmuo_task2_status",
          "label": "Check all required tools are on hand and have a valid calibration certificate (if required).",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check all required tools are on hand and have a valid calibration certificate (if required)."
        },
        {
          "id": "rmuo_task3_status",
          "label": "Check all appropriate hazard & equipment ID is present and in good legible condition.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check all appropriate hazard & equipment ID is present and in good legible condition."
        },
        {
          "id": "rmuo_task4_status",
          "label": "Check all locks are present and in good working condition.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check all locks are present and in good working condition."
        },
        {
          "id": "rmuo_task5_status",
          "label": "Check voltage indicators (if fitted) are working and showing voltage.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check voltage indicators (if fitted) are working and showing voltage."
        },
        {
          "id": "rmuo_task6_status",
          "label": "Clean & spray all vegetation build up, weeds, dust and debris away from the asset.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Clean & spray all vegetation build up, weeds, dust and debris away from the asset."
        },
        {
          "id": "rmuo_task7_status",
          "label": "Check external surface is free from corrosion, electrical discharge/tracking and graffiti.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check external surface is free from corrosion, electrical discharge/tracking and graffiti."
        },
        {
          "id": "rmuo_task8_status",
          "label": "Check any external visible earth is attached to the unit and not broken or disconnected.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task8_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check any external visible earth is attached to the unit and not broken or disconnected."
        },
        {
          "id": "rmuo_task9_status",
          "label": "Check the correct fuse size is installed if fuse switches are in use and is graded appropriately.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task9_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check the correct fuse size is installed if fuse switches are in use and is graded appropriately."
        },
        {
          "id": "rmuo_task10_status",
          "label": "Earth conductor is attached (if visible).",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task10_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Earth conductor is attached (if visible)."
        },
        {
          "id": "rmuo_task11_status",
          "label": "Cables wiped, cleaned and there is no scoring or damage to the outer cable sheath.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_task11_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Cables wiped, cleaned and there is no scoring or damage to the outer cable sheath."
        }
      ]
    },
    {
      "title": "Test Completed",
      "fields": [
        {
          "id": "rmuo_test_equip_used",
          "label": "Test Equipment Used",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_test_equip_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_test_comments",
          "label": "Rmuo test comments",
          "type": "textarea",
          "required": false,
          "rows": 3
        },
        {
          "id": "rmuo_pd_result",
          "label": "Perform PD testing & ensure unit is safe to remove from service.",
          "type": "number",
          "required": false,
          "min": 0,
          "max": 999,
          "step": 1
        },
        {
          "id": "rmuo_pd_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Perform PD testing & ensure unit is safe to remove from service."
        },
        {
          "id": "rmuo_notes",
          "label": "Notes",
          "type": "textarea",
          "required": false,
          "rows": 3
        }
      ]
    },
    {
      "title": "Oil RMU \u2013 Specific Tasks",
      "fields": [
        {
          "id": "rmuo_oil_task1_status",
          "label": "Check the fuse carrier is undamaged and free of cracks.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_oil_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check the fuse carrier is undamaged and free of cracks."
        },
        {
          "id": "rmuo_oil_task2_status",
          "label": "Check contacts alignment is acceptable.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_oil_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check contacts alignment is acceptable."
        },
        {
          "id": "rmuo_oil_task3_status",
          "label": "Check fuse size is correct for transformer sizing and grades correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_oil_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check fuse size is correct for transformer sizing and grades correctly."
        },
        {
          "id": "rmuo_oil_task4_status",
          "label": "Clean fuse carrier contacts if poor contact resistance test.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_oil_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Clean fuse carrier contacts if poor contact resistance test."
        },
        {
          "id": "rmuo_oil_task5_status",
          "label": "Check earth braid is in good condition.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_oil_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check earth braid is in good condition."
        },
        {
          "id": "rmuo_oil_task6_status",
          "label": "Check all contacts are free moving, have no arcing or carbon build up; clean contacts.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_oil_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check all contacts are free moving, have no arcing or carbon build up; clean contacts."
        },
        {
          "id": "rmuo_oil_task7_status",
          "label": "All oil sludge build up has been removed and tank is fully flushed.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_oil_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "All oil sludge build up has been removed and tank is fully flushed."
        }
      ]
    },
    {
      "title": "Oil RMU \u2013 Specific Tests",
      "fields": [
        {
          "id": "rmuo_oil_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_oil_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_oil_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmuo_oil_breakdown",
          "label": "Oil breakdown test on sample oil.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_contact_resist",
          "label": "Contact resistance tests.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmuo_busbar_ir",
          "label": "Busbar insulation resistance test.",
          "type": "text",
          "required": false
        }
      ]
    }
  ]
};
})();
