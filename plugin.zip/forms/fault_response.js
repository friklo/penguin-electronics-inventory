(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.fault_response = {
  "id": "fault_response",
  "title": "Fault Script with Work Order Creation",
  "sections": [
    {
      "title": "Fault Asset Information",
      "fields": [
        {
          "id": "xa_ws_fswwoc_yes_no_17",
          "label": "Is this a network fault? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Network Fault",
      "fields": [
        {
          "id": "xa_ws_fswwoc_19",
          "label": "Describe the fault as found: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_29",
          "label": "Did the fault originate from a network or a private asset? *",
          "type": "select",
          "options": [
            "Customer Asset",
            "Network Asset"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_30",
          "label": "Faulted Asset ID *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_31",
          "label": "Which asset type failed? *",
          "type": "select",
          "options": [
            "CABLE JOINT",
            "CROSSARM",
            "DDO CARRIER",
            "DDO FUSE",
            "HV UNDERGROUND CABLE",
            "INSULATOR",
            "LIGHTNING ARRESTORS",
            "LINK PILLAR",
            "LV SERVICE FUSE",
            "LV SERVICE FUSE CARRIER",
            "LV UNDERGROUND CABLE",
            "OTHER",
            "OVERHEAD CONDUCTOR",
            "OVERHEAD JUMPER",
            "OVERHEAD SWITCHGEAR (ABS)",
            "OVERHEAD SWITCHGEAR (AUTOMATED)",
            "OVERHEAD SWITCHGEAR (ENCLOSED)",
            "POLE",
            "PROTECTION RELAY",
            "RMU",
            "SERVICE PILLAR",
            "TRANSFORMER (DISTRIBUTION)",
            "TRANSFORMER (POWER TX)",
            "ZONE SUB CIRCUIT BREAKER"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_32",
          "label": "Other failed asset type: Please specify *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_31",
              "values": [
                "OTHER"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_fault_cause",
          "label": "Fault Cause *",
          "type": "select",
          "options": [
            "3RD PARTY INTERFERENCE",
            "ADVERSE ENVIRONMENT",
            "ADVERSE WEATHER",
            "DEFECTIVE EQUIPMENT",
            "HUMAN ERROR",
            "LIGHTNING",
            "OTHER",
            "UNKNOWN CAUSE",
            "VEGETATION",
            "WILDLIFE"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_34",
          "label": "Other or Unknown fault cause: Please specify *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_fault_cause",
              "values": [
                "OTHER",
                "UNKNOWN CAUSE"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_fault_voltage",
          "label": "Fault voltage level *",
          "type": "select",
          "options": [
            "0.4KV",
            "11KV",
            "33KV",
            "50KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Capital WIP Assets",
      "fields": [
        {
          "id": "xa_ws_fswwoc_yes_no_37",
          "label": "Did the job involve any asset replacement or repairs other than replacing links or reclosing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_38",
          "label": "Please select all of the asset types that have been replaced (or N/A) *",
          "type": "select",
          "options": [
            "NA",
            "ABS",
            "CROSSARM",
            "DISTRIBUTION TRANSFORMER",
            "ENCLOSED SWITCH",
            "FUSE/DDO CARRIERS (FULL SET)",
            "LINK PILLAR",
            "PEANUT TRANSFORMER",
            "POLE",
            "RADIO/COMMS EQUIPMENT",
            "RECLOSER",
            "RMU",
            "SECTIONALISER",
            "SERVICE PILLAR"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_37",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_yes_no_39",
          "label": "Have you replaced all of the crossarms on a pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_38",
              "values": [
                "CROSSARM"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_37",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_yes_no_replaced_phases",
          "label": "Have you replaced all phases of any cable/conductor? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_37",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_41",
          "label": "What length of circuit (all phases) has been replaced? *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_replaced_phases",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_37",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Not a Network Fault",
      "fields": [
        {
          "id": "xa_ws_fswwoc_44",
          "label": "What is the job type? *",
          "type": "select",
          "options": [
            "CLOSE APPROACH",
            "HIGH LOAD",
            "LV COVER-UP",
            "OTHER",
            "PRIVATE ONLY FAULT",
            "SAFETY DISCONNECT/RECONNECT"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_45",
          "label": "Other job type: please specify *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_44",
              "values": [
                "OTHER"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_17",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_yes_no_47",
          "label": "Is this chargeable to a third party? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_fswwoc_48",
          "label": "Details. Include name & phone num and any other relevant details (rego, police case num, adderss, etc..) *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_47",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_bypassed",
          "label": "Has a meter or relay been bypassed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Log Details",
      "fields": [
        {
          "id": "xa_ws_description",
          "label": "Site Address *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_requiredbydate",
          "label": "Date of fault *",
          "type": "date",
          "required": true
        },
        {
          "id": "xa_ws_extendedtext",
          "label": "Works Undertaken (Provide detailed description of works carried out) *",
          "type": "text",
          "required": true
        }
      ]
    },
    {
      "title": "Test Results",
      "fields": [
        {
          "id": "xa_ws_fswwoc_yes_no_62",
          "label": "Are tests required? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_fswwoc_63",
          "label": "Polarity (Independant Earth): *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_64",
          "label": "Voltage (Phase - Neutral): *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_65",
          "label": "Insulation Resistance: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_66",
          "label": "Earth Fault Loop Impedance: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_67",
          "label": "Phase Rotation: *",
          "type": "select",
          "options": [
            "NA",
            "ANTICLOCKWISE",
            "CLOCKWISE",
            "N/A"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_68",
          "label": "Additional Test Details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_yes_no_69",
          "label": "Have multiple tests been conducted? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fswwoc_70",
          "label": "Have multiple tests been conducted? *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fswwoc_yes_no_69",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_fswwoc_yes_no_62",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Fault Completion",
      "fields": [
        {
          "id": "xa_ws_fswwoc_yes_no_72",
          "label": "Has the fault been completed? (select no if additional work is yet to be completed) *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_fswwoc_75",
          "label": "Additional Comments / Details: *",
          "type": "text",
          "required": true
        }
      ]
    }
  ]
};
})();
