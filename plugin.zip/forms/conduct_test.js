(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.conduct_test = {
  "id": "conduct_test",
  "title": "Earthing test for all Asset types",
  "sections": [
    {
      "title": "GENERAL INFORMATION",
      "fields": [
        {
          "id": "xa_ws_g_insp_date",
          "label": "Test Date: *",
          "type": "date",
          "required": true
        },
        {
          "id": "xa_ws_etfaat_4",
          "label": "Test Date: *",
          "type": "date",
          "required": true
        },
        {
          "id": "xa_ws_etfaat_5",
          "label": "GPS Location: *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_g_equip",
          "label": "What test equipment will be used? *",
          "type": "select",
          "options": [
            "Megger DET2/3",
            "Megger DET3TD",
            "Megger Det4TCR2",
            "Other"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Test Equipment",
      "fields": [
        {
          "id": "xa_ws_g_equip_othr",
          "label": "Please type in the equipment used (Brand - Model) *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_equip",
              "values": [
                "Other",
                "Other-8"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "SITE ACCESS",
      "fields": [
        {
          "id": "xa_ws_g_visual_y_n",
          "label": "Is it possible to conduct a visual inspection safely? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Terminating the Inspection",
      "fields": [
        {
          "id": "xa_ws_g_visual_n_r",
          "label": "Please select a reason *",
          "type": "select",
          "options": [
            "Electrical failure",
            "Mechanical / Structure failure",
            "Missing earth wire",
            "No access track",
            "Other",
            "Partial discharge",
            "Private property"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "NO",
                "NO-13",
                "YES",
                "YES-20"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_visual_n",
          "label": "Please select a reason *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_n_r",
              "values": [
                "Other"
              ]
            },
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "NO",
                "NO-13",
                "YES",
                "YES-20"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_comment_n",
          "label": "Additional comments (if any): *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "NO",
                "NO-13",
                "YES",
                "YES-20"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "VISUAL OBSERVATION AND TESTING",
      "fields": [
        {
          "id": "xa_ws_g_asset_id",
          "label": "Additional comments (if any): *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_g_asset_typ",
          "label": "Please select the mount type of the asset: *",
          "type": "select",
          "options": [
            "GM",
            "OH"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "OH SPECIFIC OBSERVATIONS",
      "fields": [
        {
          "id": "xa_ws_g_asset_oh",
          "label": "Please select the OH primary asset/s category: *",
          "type": "select",
          "options": [
            "ABS",
            "Cable 11kV",
            "Cable 33kV",
            "Circuit Breaker",
            "DDO",
            "LV line",
            "Lightning Arrester",
            "Recloser",
            "Sectionaliser",
            "Transformer"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43",
                "OH",
                "OH-23"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "EARTH WIRE CONNECTIONS",
      "fields": [
        {
          "id": "xa_ws_g_ewire_oh",
          "label": "Is the earth wire properly connected to the OH asset/s and to the Earthing Plate on the pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43",
                "OH",
                "OH-23"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Earth Wire Connection Problem",
      "fields": [
        {
          "id": "xa_ws_g_ewire_oh_n",
          "label": "Is it possible to fix safely on site? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_ewire_oh",
              "values": [
                "NO",
                "NO-27"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43",
                "OH",
                "OH-23"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Fixing Earth Wire Connection",
      "fields": [
        {
          "id": "xa_ws_g_ewire_oh_s",
          "label": "Please fix and describe *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_ewire_oh_n",
              "values": [
                "NO",
                "NO-32",
                "YES",
                "YES-29"
              ]
            },
            {
              "field": "xa_ws_g_ewire_oh",
              "values": [
                "NO",
                "NO-27"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43",
                "OH",
                "OH-23"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Raising Defect on Earth Wire Connection",
      "fields": [
        {
          "id": "xa_ws_etfaat_34",
          "label": "Please describe and raise defect *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_ewire_oh",
              "values": [
                "NO",
                "NO-27"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43",
                "OH",
                "OH-23"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_ewire_szoh",
          "label": "What is the size of the earth bank conductor in mm? *",
          "type": "select",
          "options": [
            "NA",
            "16",
            "25",
            "35",
            "50",
            "70",
            "90",
            "Other"
          ],
          "required": true
        },
        {
          "id": "xa_ws_g_ew_szoh_ot",
          "label": "What is the size of the earth bank conductor in mm? *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_ewire_szoh",
              "values": [
                "Other"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Raising Defect on Earth Wire Insulation",
      "fields": [
        {
          "id": "xa_ws_etfaat_41",
          "label": "This is a Fail! Please describe and raise defect *",
          "type": "text",
          "required": true
        }
      ]
    }
  ]
};
})();
