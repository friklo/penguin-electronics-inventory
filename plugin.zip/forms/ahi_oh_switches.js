(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.ahi_oh_switches = {
  "id": "ahi_oh_switches",
  "title": "Asset Health Index - INSP - OH Switches",
  "sections": [
    {
      "title": "General",
      "fields": [
        {
          "id": "xa_ws_i_access",
          "label": "Can you access the asset for inspection (including at a distance)? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_ahiios_1",
          "label": "Determine the type of the switch *",
          "type": "select",
          "options": [
            "ABS",
            "DDO / LINK",
            "ENCLOSED SWITCH",
            "OTHER",
            "RECLOSER / SECTIONALISER"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "RECLOSER / SECTIONALISER",
      "fields": [
        {
          "id": "xa_ws_i_sw_rpl_dts",
          "label": "Please determine the make & model *",
          "type": "select",
          "options": [
            "ABB SECTOS",
            "AK DDO SECTIONALISER",
            "COOPER POWER NOVA",
            "ENTEC SCS",
            "OTHER"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiios_1",
              "values": [
                "ABS",
                "ABS-6",
                "ENCLOSED SWITCH",
                "ENCLOSED SWITCH-3",
                "RECLOSER / SECTIONALISER",
                "RECLOSER / SECTIONALISER-3"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "ABS",
      "fields": [
        {
          "id": "xa_ws_i_drive_type",
          "label": "Is the drive rod wooden? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_drvrod_dmg",
          "label": "Is the drive rod rotten or damaged? *",
          "type": "select",
          "options": [
            "Major ( >60 )",
            "Minor ( < 30% )",
            "Moderate ( >30 & <60 )",
            "None ( 0% )"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_drive_type",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_earth",
          "label": "Is the earthing system intact? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_mech_miss",
          "label": "Is there a mechanical part missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_ahiios_yes_no_11",
          "label": "Are there OH Links / DDOs on this pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_link_ear11",
          "label": "Do the OH Links have an earthing lead (spigot)? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiios_yes_no_11",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_ddo_carr",
          "label": "Please determine the DDO carrier type *",
          "type": "select",
          "options": [
            "Bronze DDO (Brown procelain)",
            "L shaped bracket (Grey procelain)",
            "SANDC Electric DDO (Grey procelain)",
            "Silicon DDO",
            "Stainless DDO (Grey procelain)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiios_yes_no_11",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    }
  ]
};
})();
