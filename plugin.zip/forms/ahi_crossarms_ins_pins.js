(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.ahi_crossarms_ins_pins = {
  "id": "ahi_crossarms_ins_pins",
  "title": "Asset Health Index - INSP - Crossarms, insulators,pins",
  "sections": [
    {
      "title": "General",
      "fields": [
        {
          "id": "xa_ws_ahiici_yes_no_1",
          "label": "First set of crossarms or hardware *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "First level of crossarms",
      "fields": [
        {
          "id": "xa_ws_n_xarm_1_vol",
          "label": "Determine the voltage of the first level of crossarms. *",
          "type": "select",
          "options": [
            "NA",
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_1_fu",
          "label": "Determine the crossarm material *",
          "type": "select",
          "options": [
            "Fibreglass",
            "Hardwood",
            "Other",
            "Steel"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_1_fun",
          "label": "Determine the crosssarm function *",
          "type": "select",
          "options": [
            "NA",
            "DDO ARM",
            "DOUBLE PIN",
            "DOUBLE TERMINATION",
            "SINGLE PIN",
            "SINGLE TERMINATION",
            "SUSPENSION",
            "SUSPENSION - ANGLE",
            "TRAINER ARM",
            "TX HANGER ARM"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm1_con1",
          "label": "Are there signs of corrosion, damage, bowing, drill holes deterioration? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm1_con2",
          "label": "Are the bolts or nuts corroded, damaged or missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Insulators",
      "fields": [
        {
          "id": "xa_ws_i_insu1_con1",
          "label": "Are the insulators and related pins and nuts damaged, corroded, missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu1_con2",
          "label": "Are the Insulators and related pins secured in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu1_con3",
          "label": "Are the binders ok? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu2_con1",
          "label": "Are the insulators and related pins and nuts damaged, corroded, missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu2_con2",
          "label": "Are the Insulators and related pins secured in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu2_con3",
          "label": "Are the binders ok? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu3_con1",
          "label": "Are the insulators and related pins and nuts damaged, corroded, missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu3_con2",
          "label": "Are the Insulators and related pins secured in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu3_con3",
          "label": "Are the binders ok? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu4_con1",
          "label": "Are the insulators and related pins and nuts damaged, corroded, missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu4_con2",
          "label": "Are the Insulators and related pins secured in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu4_con3",
          "label": "Are the binders ok? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu5_con1",
          "label": "Are the insulators and related pins and nuts damaged, corroded, missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu5_con2",
          "label": "Are the Insulators and related pins secured in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu5_con3",
          "label": "Are the binders ok? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Armbraces",
      "fields": [
        {
          "id": "xa_ws_i_armb1_con1",
          "label": "Are the armbraces corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb1_con2",
          "label": "Are any bolts or nuts missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb1_con3",
          "label": "Are the bolts or nuts corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb2_con1",
          "label": "Are the armbraces corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb2_con2",
          "label": "Are any bolts or nuts missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb2_con3",
          "label": "Are the bolts or nuts corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb3_con1",
          "label": "Are the armbraces corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb3_con2",
          "label": "Are any bolts or nuts missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb3_con3",
          "label": "Are the bolts or nuts corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb4_con1",
          "label": "Are the armbraces corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb4_con2",
          "label": "Are any bolts or nuts missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb4_con3",
          "label": "Are the bolts or nuts corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb5_con1",
          "label": "Are the armbraces corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb5_con2",
          "label": "Are any bolts or nuts missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb5_con3",
          "label": "Are the bolts or nuts corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Jumpers and Connectors",
      "fields": [
        {
          "id": "xa_ws_i_jumper_thermal_scan_1",
          "label": "Can you perform a thermal scan? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_temp50_1",
          "label": "Is the maximum temperature above 50 \u00b0C? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jumper_thermal_scan_1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump1_con1",
          "label": "Are there any Jumpers and Connectors installed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump1_con2",
          "label": "Are the Jumpers and Connectors corroded or damaged? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jump1_con1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_thermal_scan_2",
          "label": "Can you perform a thermal scan? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_temp50_2",
          "label": "Is the maximum temperature above 50 \u00b0C? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jumper_thermal_scan_2",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump2_con1",
          "label": "Are there any Jumpers and Connectors installed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump2_con2",
          "label": "Are the Jumpers and Connectors corroded or damaged? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jump2_con1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_thermal_scan_3",
          "label": "Can you perform a thermal scan? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_temp50_3",
          "label": "Is the maximum temperature above 50 \u00b0C? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jumper_thermal_scan_3",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump3_con1",
          "label": "Are there any Jumpers and Connectors installed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump3_con2",
          "label": "Are the Jumpers and Connectors corroded or damaged? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jump3_con1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_thermal_scan_4",
          "label": "Can you perform a thermal scan? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_temp50_4",
          "label": "Is the maximum temperature above 50 \u00b0C? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jumper_thermal_scan_4",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump4_con1",
          "label": "Are there any Jumpers and Connectors installed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump4_con2",
          "label": "Are the Jumpers and Connectors corroded or damaged? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jump4_con1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_thermal_scan_5",
          "label": "Can you perform a thermal scan? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_temp50_5",
          "label": "Is the maximum temperature above 50 \u00b0C? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jumper_thermal_scan_5",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump5_con1",
          "label": "Are there any Jumpers and Connectors installed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump5_con2",
          "label": "Are the Jumpers and Connectors corroded or damaged? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jump5_con1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Second level of crossarms",
      "fields": [
        {
          "id": "xa_ws_n_xarm_2_vol",
          "label": "Determine the voltage of the second level of crossarms *",
          "type": "select",
          "options": [
            "NA",
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_2_fu",
          "label": "Determine the crossarm material *",
          "type": "select",
          "options": [
            "Fibreglass",
            "Hardwood",
            "Other",
            "Steel"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_2_fun",
          "label": "Determine the crossarm function *",
          "type": "select",
          "options": [
            "NA",
            "DDO ARM",
            "DOUBLE PIN",
            "DOUBLE TERMINATION",
            "SINGLE PIN",
            "SINGLE TERMINATION",
            "SUSPENSION",
            "SUSPENSION - ANGLE",
            "TRAINER ARM",
            "TX HANGER ARM"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm2_con1",
          "label": "Are there signs of corrosion, damage, bowing, drill holes deterioration? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm2_con2",
          "label": "Are the bolts or nuts corroded, damaged or missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Third level of crossarms",
      "fields": [
        {
          "id": "xa_ws_n_xarm_3_vol",
          "label": "Determine the voltage of the third level of crossarms *",
          "type": "select",
          "options": [
            "NA",
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_3_fu",
          "label": "Determine the crossarm material *",
          "type": "select",
          "options": [
            "Fibreglass",
            "Hardwood",
            "Other",
            "Steel"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_3_fun",
          "label": "Determine the crossarm function *",
          "type": "select",
          "options": [
            "NA",
            "DDO ARM",
            "DOUBLE PIN",
            "DOUBLE TERMINATION",
            "SINGLE PIN",
            "SINGLE TERMINATION",
            "SUSPENSION",
            "SUSPENSION - ANGLE",
            "TRAINER ARM",
            "TX HANGER ARM"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm3_con1",
          "label": "Are there signs of corrosion, damage, bowing, drill holes deterioration? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm3_con2",
          "label": "Are the bolts or nuts corroded, damaged or missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Fourth level of crossarms",
      "fields": [
        {
          "id": "xa_ws_n_xarm_4_vol",
          "label": "Determine the voltage of the fourth level of crossarms. *",
          "type": "select",
          "options": [
            "NA",
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_4_fu",
          "label": "Determine the crossarm material *",
          "type": "select",
          "options": [
            "Fibreglass",
            "Hardwood",
            "Other",
            "Steel"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_4_fun",
          "label": "Determine the crossarm function *",
          "type": "select",
          "options": [
            "NA",
            "DDO ARM",
            "DOUBLE PIN",
            "DOUBLE TERMINATION",
            "SINGLE PIN",
            "SINGLE TERMINATION",
            "SUSPENSION",
            "SUSPENSION - ANGLE",
            "TRAINER ARM",
            "TX HANGER ARM"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm4_con1",
          "label": "Are there signs of corrosion, damage, bowing, drill holes deterioration? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm4_con2",
          "label": "Are the bolts or nuts corroded, damaged or missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Fifth level of crossarms",
      "fields": [
        {
          "id": "xa_ws_n_xarm_5_vol",
          "label": "Determine the voltage of the fifth level of crossarms *",
          "type": "select",
          "options": [
            "NA",
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_5_fu",
          "label": "Determine the crossarm material *",
          "type": "select",
          "options": [
            "Fibreglass",
            "Hardwood",
            "Other",
            "Steel"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_5_fun",
          "label": "Determine the crossarm function *",
          "type": "select",
          "options": [
            "NA",
            "DDO ARM",
            "DOUBLE PIN",
            "DOUBLE TERMINATION",
            "SINGLE PIN",
            "SINGLE TERMINATION",
            "SUSPENSION",
            "SUSPENSION - ANGLE",
            "TRAINER ARM",
            "TX HANGER ARM"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm5_con1",
          "label": "Are there signs of corrosion, damage, bowing, drill holes deterioration? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm5_con2",
          "label": "Are the bolts or nuts corroded, damaged or missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    }
  ]
};
})();
