(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.distribution_tx_checklist = {
  "id": "distribution_tx_checklist",
  "title": "Distribution Transformer Maintenance Checklist",
  "sections": [
    {
      "title": "Distribution Transformer Maintenance Checklist",
      "fields": [
        {
          "id": "dtx_asset_num",
          "label": "ASSET NUMBER",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_project_no",
          "label": "PROJECT NO.",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_location",
          "label": "LOCATION",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_feeder",
          "label": "FEEDER",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_manufacturer",
          "label": "MANUFACTURER",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_model",
          "label": "MODEL",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_serial_no",
          "label": "SERIAL NO.",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_voltage",
          "label": "VOLTAGE",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_insp_type",
          "label": "INSPECTION TYPE",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_test_equip",
          "label": "TEST EQUIPMENT / TOOLS USED",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_test_asset_no",
          "label": "ASSET NO.",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_calib_date",
          "label": "TEST / CALIBRATION DATE",
          "type": "date",
          "required": false
        },
        {
          "id": "dtx_expiry_date",
          "label": "EXPIRY DATE",
          "type": "date",
          "required": false
        },
        {
          "id": "dtx_task1_cond",
          "label": "Cubicle clean, free of debris, and any damage or corrosion within acceptable limits.",
          "type": "select",
          "options": [
            "-- Select --",
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Cubicle clean, free of debris, and any damage or corrosion within acceptable limits."
        },
        {
          "id": "dtx_task2_cond",
          "label": "Doors in sound condition and secure.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Doors in sound condition and secure."
        },
        {
          "id": "dtx_task3_cond",
          "label": "Door latches effective and in good condition.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Door latches effective and in good condition."
        },
        {
          "id": "dtx_task4_cond",
          "label": "Fire extinguishers serviceable (where fitted).",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Fire extinguishers serviceable (where fitted)."
        },
        {
          "id": "dtx_task5_cond",
          "label": "Air vents unobstructed.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Air vents unobstructed."
        },
        {
          "id": "dtx_task6_cond",
          "label": "Log MDI readings & multipliers \u2013 where fitted.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Log MDI readings & multipliers \u2013 where fitted."
        },
        {
          "id": "dtx_task7_cond",
          "label": "Area around unit base clear of rubbish; adequate gap at floor level maintained to prevent moisture build-up.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Area around unit base clear of rubbish; adequate gap at floor level maintained to prevent moisture build-up."
        },
        {
          "id": "dtx_task8_cond",
          "label": "Mountings and foundations visually secure and free from damage, settling, cracking or spalling.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task8_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Mountings and foundations visually secure and free from damage, settling, cracking or spalling."
        },
        {
          "id": "dtx_task9_cond",
          "label": "Thermochromic strip indication within acceptable range (50\u00b0C\u2013100\u00b0C), where fitted.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task9_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Thermochromic strip indication within acceptable range (50\u00b0C\u2013100\u00b0C), where fitted."
        },
        {
          "id": "dtx_task10_cond",
          "label": "Equipment & associated cables (esp. crotches) visually free from discharge/tracking; cables undamaged.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task10_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Equipment & associated cables (esp. crotches) visually free from discharge/tracking; cables undamaged."
        },
        {
          "id": "dtx_task11_cond",
          "label": "Insulators and bushings visually clean, unbroken, and secure.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task11_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Insulators and bushings visually clean, unbroken, and secure."
        },
        {
          "id": "dtx_task12_cond",
          "label": "Support structure, tank and radiators undamaged, clean, secure; free from corrosion, damage and leaks.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task12_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Support structure, tank and radiators undamaged, clean, secure; free from corrosion, damage and leaks."
        },
        {
          "id": "dtx_task13_cond",
          "label": "Oil levels clearly visible (sight glass/indicator clean & secure), where fitted.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task13_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Oil levels clearly visible (sight glass/indicator clean & secure), where fitted."
        },
        {
          "id": "dtx_task14_cond",
          "label": "No oil leaks from bushings or tank.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task14_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "No oil leaks from bushings or tank."
        },
        {
          "id": "dtx_task15_cond",
          "label": "Silica gel desiccant breathers dry & full (replace if colour indicates), where fitted.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task15_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Silica gel desiccant breathers dry & full (replace if colour indicates), where fitted."
        },
        {
          "id": "dtx_task16_cond",
          "label": "Breathing vent transport plug removed (free-breathing units).",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task16_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Breathing vent transport plug removed (free-breathing units)."
        },
        {
          "id": "dtx_task17_cond",
          "label": "Tap change mechanism bolted or locked.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task17_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Tap change mechanism bolted or locked."
        },
        {
          "id": "dtx_task18_cond",
          "label": "All mounting bolts correct & secure; corrosion within acceptable limits.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task18_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "All mounting bolts correct & secure; corrosion within acceptable limits."
        },
        {
          "id": "dtx_task19_cond",
          "label": "Signs & equipment numbers legible, secure and up-to-date.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task19_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Signs & equipment numbers legible, secure and up-to-date."
        },
        {
          "id": "dtx_task20_cond",
          "label": "Hazard label attached prominently and clearly legible.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task20_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Hazard label attached prominently and clearly legible."
        },
        {
          "id": "dtx_task21_cond",
          "label": "Surface corrosion within acceptable limits; painted surfaces in good repair.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task21_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Surface corrosion within acceptable limits; painted surfaces in good repair."
        },
        {
          "id": "dtx_task22_cond",
          "label": "Soil around unit free from earth movement / unauthorised excavations.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task22_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Soil around unit free from earth movement / unauthorised excavations."
        },
        {
          "id": "dtx_task23_cond",
          "label": "Earthing connections secure, undamaged, free from corrosion.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task23_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Earthing connections secure, undamaged, free from corrosion."
        },
        {
          "id": "dtx_task24_cond",
          "label": "Debris (bird nests, vermin, vegetation, rags, etc) cleared.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task24_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Debris (bird nests, vermin, vegetation, rags, etc) cleared."
        },
        {
          "id": "dtx_task25_cond",
          "label": "Site free of weeds and unintended plant growth (incl. mould).",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task25_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Site free of weeds and unintended plant growth (incl. mould)."
        },
        {
          "id": "dtx_task26_cond",
          "label": "Site free of vegetation rubbish/trimmings and sprayed for weed growth.",
          "type": "select",
          "options": [
            "OK",
            "Not OK",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task26_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Site free of vegetation rubbish/trimmings and sprayed for weed growth."
        },
        {
          "id": "dtx_task27_cond",
          "label": "Thermal scan of transformer enclosure.",
          "type": "select",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task27_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Thermal scan of transformer enclosure."
        },
        {
          "id": "dtx_task28_cond",
          "label": "Perform PD testing and record dB reading.",
          "type": "select",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "dtx_task28_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Perform PD testing and record dB reading."
        },
        {
          "id": "dtx_test_equip_used",
          "label": "TEST EQUIPMENT USED",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_test_equip_serial",
          "label": "TEST EQUIPMENT SERIAL NO.",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_test_comments",
          "label": "Dtx test comments",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_dielectric_result",
          "label": "Dielectric Strength",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_dielectric_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Dielectric Strength"
        },
        {
          "id": "dtx_moisture_result",
          "label": "Moisture Level",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_moisture_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Moisture Level"
        },
        {
          "id": "dtx_acidity_result",
          "label": "Acidity Level",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_acidity_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Acidity Level"
        },
        {
          "id": "dtx_dga_result",
          "label": "DGA Testing",
          "type": "text",
          "required": false
        },
        {
          "id": "dtx_dga_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "DGA Testing"
        },
        {
          "id": "dtx_notes",
          "label": "Dtx notes",
          "type": "textarea",
          "required": false,
          "rows": 3
        }
      ]
    }
  ]
};
})();
