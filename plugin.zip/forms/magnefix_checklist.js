(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.magnefix_checklist = {
  "id": "magnefix_checklist",
  "title": "MAGNEFIX MAINTENANCE CHECKLIST",
  "sections": [
    {
      "title": "MAGNEFIX MAINTENANCE CHECKLIST",
      "fields": [
        {
          "id": "mfx_asset_num",
          "label": "Asset Number",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_project_no",
          "label": "Project No.",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_location",
          "label": "Location",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_feeder",
          "label": "Feeder",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_manufacturer",
          "label": "Manufacturer",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_model",
          "label": "Model",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_serial_no",
          "label": "Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_voltage",
          "label": "Voltage",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_test_equip",
          "label": "Test Equipment/Tools Used",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_test_asset_no",
          "label": "Asset No.",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_calib_date",
          "label": "Test/Calibration Date",
          "type": "date",
          "required": false
        },
        {
          "id": "mfx_expiry_date",
          "label": "Expiry Date",
          "type": "date",
          "required": false
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "mfx_task1_status",
          "label": "CLEAN all debris/dust off the main resin body, links and fuse holders using a lint\u2011free cloth and white spirit.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "mfx_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "CLEAN all debris/dust off the main resin body, links and fuse holders using a lint\u2011free cloth and white spirit."
        },
        {
          "id": "mfx_task2_status",
          "label": "REMOVE any tracking marks.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "mfx_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "REMOVE any tracking marks."
        },
        {
          "id": "mfx_task3_status",
          "label": "APPLY a thin layer of contact grease to the contacts of all links and fuses.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "mfx_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "APPLY a thin layer of contact grease to the contacts of all links and fuses."
        },
        {
          "id": "mfx_task4_status",
          "label": "POLISH the main resin body, links, and fuse holders to obtain a moisture\u2011repellent finish.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "mfx_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "POLISH the main resin body, links, and fuse holders to obtain a moisture\u2011repellent finish."
        }
      ]
    },
    {
      "title": "Test Completed",
      "fields": [
        {
          "id": "mfx_test_equip_used",
          "label": "Test Equipment Used",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_test_equip_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "mfx_test_comments",
          "label": "Mfx test comments",
          "type": "textarea",
          "required": false,
          "rows": 3
        },
        {
          "id": "mfx_pd_reading",
          "label": "Perform PD testing and record dB reading.",
          "type": "text",
          "required": false
        },
        {
          "id": "mfx_pd_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Perform PD testing and record dB reading."
        },
        {
          "id": "mfx_notes",
          "label": "Notes",
          "type": "textarea",
          "required": false,
          "rows": 3
        }
      ]
    }
  ]
};
})();
