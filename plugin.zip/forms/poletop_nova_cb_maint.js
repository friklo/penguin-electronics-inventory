(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.poletop_nova_cb_maint = {
  "id": "poletop_nova_cb_maint",
  "title": "POLETOP NOVA CB Maintenance Checklist",
  "sections": [
    {
      "title": "Asset & Site",
      "fields": [
        {
          "id": "asset_number",
          "label": "ASSET NUMBER",
          "type": "text",
          "required": false
        },
        {
          "id": "project_no",
          "label": "PROJECT NO.",
          "type": "text",
          "required": false
        },
        {
          "id": "location",
          "label": "LOCATION",
          "type": "text",
          "required": false
        },
        {
          "id": "feeder",
          "label": "FEEDER",
          "type": "text",
          "required": false
        }
      ]
    },
    {
      "title": "Equipment",
      "fields": [
        {
          "id": "manufacturer",
          "label": "MANUFACTURER",
          "type": "text",
          "required": false
        },
        {
          "id": "model",
          "label": "MODEL",
          "type": "text",
          "required": false
        },
        {
          "id": "serial_no",
          "label": "SERIAL NO.",
          "type": "text",
          "required": false
        },
        {
          "id": "voltage",
          "label": "VOLTAGE",
          "type": "text",
          "required": false
        }
      ]
    },
    {
      "title": "Inspection",
      "fields": [
        {
          "id": "inspection_type",
          "label": "INSPECTION TYPE",
          "type": "text",
          "required": false
        },
        {
          "id": "test_tools",
          "label": "TEST EQUIPMENT / TOOLS USED",
          "type": "text",
          "required": false
        },
        {
          "id": "test_asset_no",
          "label": "ASSET NO.",
          "type": "text",
          "required": false
        },
        {
          "id": "calib_date",
          "label": "TEST / CALIBRATION DATE",
          "type": "date",
          "required": false
        },
        {
          "id": "expiry_date",
          "label": "EXPIRY DATE",
          "type": "date",
          "required": false
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "cond_1",
          "label": "SAFETY AND HAZARD ASSESSMENT OF THE WORKS",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_1",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "SAFETY AND HAZARD ASSESSMENT OF THE WORKS"
        },
        {
          "id": "cond_2",
          "label": "VERIFY LABELS AND EQUIPMENT IDENTIFIERS ARE INSTALLED",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_2",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "VERIFY LABELS AND EQUIPMENT IDENTIFIERS ARE INSTALLED"
        },
        {
          "id": "cond_3",
          "label": "THERMAL INSPECTION OF ALL HT EQUIPMENT.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_3",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "THERMAL INSPECTION OF ALL HT EQUIPMENT."
        },
        {
          "id": "cond_4",
          "label": "INSPECTION OF AND OPERATION OF BYPASS SWITCHES.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_4",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "INSPECTION OF AND OPERATION OF BYPASS SWITCHES."
        },
        {
          "id": "cond_5",
          "label": "INSPECTION OF ISOLATION LINKS FOR DAMAGE OR CORROSION.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_5",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "INSPECTION OF ISOLATION LINKS FOR DAMAGE OR CORROSION."
        },
        {
          "id": "cond_6",
          "label": "VISUAL INSPECTION OF LIGHTENING ARRESTERS, LOCAL SERVICE TRANSFORMER, AND MOUNTING BRACKETS CONDITION.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_6",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "VISUAL INSPECTION OF LIGHTENING ARRESTERS, LOCAL SERVICE TRANSFORMER, AND MOUNTING BRACKETS CONDITION."
        },
        {
          "id": "cond_7",
          "label": "VERIFY ALL FASTENINGS ARE TIGHT.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_7",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "VERIFY ALL FASTENINGS ARE TIGHT."
        },
        {
          "id": "cond_8",
          "label": "CHECK CONTROL BOX FOR DAMAGE, ANTS, AND WEATHER TIGHTNESS.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_8",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "CHECK CONTROL BOX FOR DAMAGE, ANTS, AND WEATHER TIGHTNESS."
        },
        {
          "id": "cond_9",
          "label": "REPLACE COMMUNICATIONS BATTERY.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_9",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "REPLACE COMMUNICATIONS BATTERY."
        },
        {
          "id": "cond_10",
          "label": "VERIFY COMMUNICATION WITH SCADA AND REMOTELY OPERATE OPEN AND CLOSE FROM SCADA.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_10",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "VERIFY COMMUNICATION WITH SCADA AND REMOTELY OPERATE OPEN AND CLOSE FROM SCADA."
        },
        {
          "id": "cond_11",
          "label": "INSPECTION OF RADIO ANTENNA AND CABLES.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_11",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "INSPECTION OF RADIO ANTENNA AND CABLES."
        },
        {
          "id": "cond_12",
          "label": "VERIFY AND RECORD COMMUNICATION RADIO TX POWER AND RX LEVELS.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_12",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "VERIFY AND RECORD COMMUNICATION RADIO TX POWER AND RX LEVELS."
        },
        {
          "id": "cond_13",
          "label": "APPLY ANY VENDOR REQUIRED MODIFICATIONS INCLUDING CONTROL FIRMWARE AS REQUIRED.",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "comm_13",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "APPLY ANY VENDOR REQUIRED MODIFICATIONS INCLUDING CONTROL FIRMWARE AS REQUIRED."
        }
      ]
    },
    {
      "title": "Tests",
      "fields": [
        {
          "id": "t1_equipment",
          "label": "TEST MANUAL OPEN CONTROLS",
          "type": "text",
          "required": false
        },
        {
          "id": "t1_serial",
          "label": "TEST MANUAL OPEN CONTROLS",
          "type": "text",
          "required": false
        },
        {
          "id": "t1_result",
          "label": "TEST MANUAL OPEN CONTROLS",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "t1_comments",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "TEST MANUAL OPEN CONTROLS"
        },
        {
          "id": "t2_equipment",
          "label": "TEST NOVA PROTECTION BATTERY.",
          "type": "text",
          "required": false
        },
        {
          "id": "t2_serial",
          "label": "TEST NOVA PROTECTION BATTERY.",
          "type": "text",
          "required": false
        },
        {
          "id": "t2_result",
          "label": "TEST NOVA PROTECTION BATTERY.",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "t2_comments",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "TEST NOVA PROTECTION BATTERY."
        },
        {
          "id": "t3_equipment",
          "label": "TEST BATTERY CHARGER FLOAT VOLTAGE.",
          "type": "text",
          "required": false
        },
        {
          "id": "t3_serial",
          "label": "TEST BATTERY CHARGER FLOAT VOLTAGE.",
          "type": "text",
          "required": false
        },
        {
          "id": "t3_result",
          "label": "TEST BATTERY CHARGER FLOAT VOLTAGE.",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "t3_comments",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "TEST BATTERY CHARGER FLOAT VOLTAGE."
        },
        {
          "id": "t4_equipment",
          "label": "HI POT TEST AS REQUIRED",
          "type": "text",
          "required": false
        },
        {
          "id": "t4_serial",
          "label": "HI POT TEST AS REQUIRED",
          "type": "text",
          "required": false
        },
        {
          "id": "t4_result",
          "label": "HI POT TEST AS REQUIRED",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "t4_comments",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "HI POT TEST AS REQUIRED"
        }
      ]
    },
    {
      "title": "Notes",
      "fields": [
        {
          "id": "notes",
          "label": "EXPIRY DATE",
          "type": "textarea",
          "required": false,
          "rows": 3
        }
      ]
    }
  ]
};
})();
