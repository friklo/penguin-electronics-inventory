(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.ahi_pole = {
  "id": "ahi_pole",
  "title": "Asset Health Index - INSP - Pole",
  "sections": [
    {
      "title": "General",
      "fields": [
        {
          "id": "xa_ws_i_access",
          "label": "Can you access the asset for inspection (including at a distance)? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Yes - Proceed",
      "fields": [
        {
          "id": "xa_ws_i_location",
          "label": "Is the asset located in any of the following regions? *",
          "type": "select",
          "options": [
            "NA",
            "Crowded area",
            "Drain/Culvert",
            "Driveway",
            "Pedestrian pathway",
            "Private"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_bowing",
          "label": "Is the pole bowing in any direction? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_heg_suff",
          "label": "Is the height of the pole insufficient for hosting the present assets on it? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_detero_4",
          "label": "Determine the level of degradation of the pole *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_stay_wire",
          "label": "Is there a stay wire present for the pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_stay_cnd_1",
          "label": "If Rusty/Corroded or Broken, Determine the level of the damage. *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_stay_wire",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Concrete",
      "fields": [
        {
          "id": "xa_ws_ahiip_11",
          "label": "Select the Pole type manufacturer *",
          "type": "select",
          "options": [
            "BOPE",
            "BUSCK",
            "FIRTH",
            "OPEN BAY",
            "OTHER",
            "RIVERRUN",
            "STAHLTON",
            "STRESS CRETE"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_con_cnd_2",
          "label": "Determine the level of spalling or cracks *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_con_cnd_1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_con_cnd_4",
          "label": "Determine the level of steel core exposure *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_corro_damg",
          "label": "Determine the level of steel core damage or corrosion *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    }
  ]
};
})();
