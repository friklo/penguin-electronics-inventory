(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.rmu_gas_checklist = {
  "id": "rmu_gas_checklist",
  "title": "RMU \u2013 GAS MAINTENANCE CHECKLIST",
  "sections": [
    {
      "title": "RMU \u2013 GAS MAINTENANCE CHECKLIST",
      "fields": [
        {
          "id": "rmug_asset_num",
          "label": "Asset Number",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_project_no",
          "label": "Project No.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_location",
          "label": "Location",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_feeder",
          "label": "Feeder",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_manufacturer",
          "label": "Manufacturer",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_model",
          "label": "Model",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_serial_no",
          "label": "Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_voltage",
          "label": "Voltage",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_test_equip",
          "label": "Test Equipment/Tools Used",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_test_asset_no",
          "label": "Asset No.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_calib_date",
          "label": "Test/Calibration Date",
          "type": "date",
          "required": false
        },
        {
          "id": "rmug_expiry_date",
          "label": "Expiry Date",
          "type": "date",
          "required": false
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "rmug_task1_status",
          "label": "Check for signs of imminent failure such as odours or unusual noises.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check for signs of imminent failure such as odours or unusual noises."
        },
        {
          "id": "rmug_task2_status",
          "label": "Check all required tools are on hand and have a valid calibration certificate (if required).",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check all required tools are on hand and have a valid calibration certificate (if required)."
        },
        {
          "id": "rmug_task3_status",
          "label": "Check all appropriate hazard & equipment ID is present and in good legible condition.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check all appropriate hazard & equipment ID is present and in good legible condition."
        },
        {
          "id": "rmug_task4_status",
          "label": "Check all locks are present and in good working condition.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check all locks are present and in good working condition."
        },
        {
          "id": "rmug_task5_status",
          "label": "Check voltage indicators (if fitted) are working and showing voltage.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check voltage indicators (if fitted) are working and showing voltage."
        },
        {
          "id": "rmug_task6_status",
          "label": "Clean & spray all vegetation build up, weeds, dust and debris away from the asset.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Clean & spray all vegetation build up, weeds, dust and debris away from the asset."
        },
        {
          "id": "rmug_task7_status",
          "label": "Check external surface is free from corrosion, electrical discharge/tracking and graffiti.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check external surface is free from corrosion, electrical discharge/tracking and graffiti."
        },
        {
          "id": "rmug_task8_status",
          "label": "Check any external visible earth is attached to the unit and not broken or disconnected.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task8_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check any external visible earth is attached to the unit and not broken or disconnected."
        },
        {
          "id": "rmug_task9_status",
          "label": "Check the correct fuse size is installed if fuse switches are in use and is graded appropriately.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task9_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check the correct fuse size is installed if fuse switches are in use and is graded appropriately."
        },
        {
          "id": "rmug_task10_status",
          "label": "Earth conductor is attached (if visible).",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task10_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Earth conductor is attached (if visible)."
        },
        {
          "id": "rmug_task11_status",
          "label": "Cables wiped, cleaned and there is no scoring or damage to the outer cable sheath.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_task11_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Cables wiped, cleaned and there is no scoring or damage to the outer cable sheath."
        }
      ]
    },
    {
      "title": "Test Completed",
      "fields": [
        {
          "id": "rmug_test_equip_used",
          "label": "Test Equipment Used",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_test_equip_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_test_comments",
          "label": "Rmug test comments",
          "type": "textarea",
          "required": false,
          "rows": 3
        },
        {
          "id": "rmug_pd_result",
          "label": "Perform PD testing & ensure unit is safe to remove from service.",
          "type": "number",
          "required": false,
          "min": 0,
          "max": 999,
          "step": 1
        },
        {
          "id": "rmug_pd_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Perform PD testing & ensure unit is safe to remove from service."
        },
        {
          "id": "rmug_notes",
          "label": "Notes",
          "type": "textarea",
          "required": false,
          "rows": 3
        }
      ]
    },
    {
      "title": "Gas RMU \u2013 Specific Tasks",
      "fields": [
        {
          "id": "rmug_gas_task1_status",
          "label": "Gas levels \u2013 confirm indicator is in the green before servicing.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_gas_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Gas levels \u2013 confirm indicator is in the green before servicing."
        },
        {
          "id": "rmug_gas_task2_status",
          "label": "Verify correct fuse size installed (if fuse switches are used) and grading is appropriate.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_gas_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Verify correct fuse size installed (if fuse switches are used) and grading is appropriate."
        },
        {
          "id": "rmug_gas_task3_status",
          "label": "If unit is corroded, carry out rust\u2011prevention maintenance and repaint as required.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_gas_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "If unit is corroded, carry out rust\u2011prevention maintenance and repaint as required."
        }
      ]
    },
    {
      "title": "Gas RMU \u2013 Specific Tests",
      "fields": [
        {
          "id": "rmug_gas_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_gas_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "rmug_gas_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "rmug_gas_pd_reading",
          "label": "Perform PD testing and record dB reading.",
          "type": "number",
          "required": false,
          "min": 0,
          "max": 999,
          "step": 1
        },
        {
          "id": "rmug_gas_pd_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Perform PD testing and record dB reading."
        }
      ]
    }
  ]
};
})();
