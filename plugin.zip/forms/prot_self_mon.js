(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.prot_self_mon = {
  "id": "prot_self_mon",
  "title": "PROTECTION SYSTEMS MAINTENANCE (SELF MONITORING) MAINTENANCE CHECKLIST",
  "sections": [
    {
      "title": "General",
      "fields": [
        {
          "id": "psysm_asset_num",
          "label": "Asset Number",
          "type": "text",
          "required": false
        },
        {
          "id": "psysm_project_no",
          "label": "Project No.",
          "type": "text",
          "required": false
        },
        {
          "id": "psysm_location",
          "label": "Location",
          "type": "text",
          "required": false
        },
        {
          "id": "psysm_feeder",
          "label": "Feeder",
          "type": "text",
          "required": false
        },
        {
          "id": "psysm_manufacturer",
          "label": "Manufacturer",
          "type": "text",
          "required": false
        },
        {
          "id": "psysm_model",
          "label": "Model",
          "type": "text",
          "required": false
        },
        {
          "id": "psysm_serial_no",
          "label": "Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "psysm_voltage",
          "label": "Voltage",
          "type": "text",
          "required": false
        },
        {
          "id": "psysm_test_equip",
          "label": "Test Equipment/Tools Used",
          "type": "text",
          "required": false
        },
        {
          "id": "psysm_test_asset_no",
          "label": "Asset No.",
          "type": "text",
          "required": false
        },
        {
          "id": "psysm_calib_date",
          "label": "Test/Calibration Date",
          "type": "date",
          "required": false
        },
        {
          "id": "psysm_expiry_date",
          "label": "Expiry Date",
          "type": "date",
          "required": false
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "psysm_task1_status",
          "label": "Inspect for damage, wear and tear.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Inspect for damage, wear and tear."
        },
        {
          "id": "psysm_task2_status",
          "label": "Test block current shorting contacts operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Test block current shorting contacts operate correctly."
        },
        {
          "id": "psysm_task3_status",
          "label": "Test block trip isolating mechanism operates correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Test block trip isolating mechanism operates correctly."
        },
        {
          "id": "psysm_task4_status",
          "label": "No loose nuts, screws and components.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "No loose nuts, screws and components."
        },
        {
          "id": "psysm_task5_status",
          "label": "Contacts operate the correct equipment.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Contacts operate the correct equipment."
        },
        {
          "id": "psysm_task6_status",
          "label": "Inputs from other equipment operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Inputs from other equipment operate correctly."
        },
        {
          "id": "psysm_task7_status",
          "label": "Pickup and/or drop-off values of elements correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Pickup and/or drop-off values of elements correct and within tolerance."
        },
        {
          "id": "psysm_task8_status",
          "label": "Operate time delay values correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_task8_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Operate time delay values correct and within tolerance."
        },
        {
          "id": "psysm_task9_status",
          "label": "Block functions and other logic operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_task9_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Block functions and other logic operate correctly."
        },
        {
          "id": "psysm_task10_status",
          "label": "Case and cover clean and free from damage.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_task10_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Case and cover clean and free from damage."
        }
      ]
    },
    {
      "title": "Indications Maintenance Tasks",
      "fields": [
        {
          "id": "psysm_ind_task1_status",
          "label": "Alarms, flags and LEDs operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_ind_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Alarms, flags and LEDs operate correctly."
        },
        {
          "id": "psysm_ind_task2_status",
          "label": "Alarms indication correct locally and remotely.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_ind_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Alarms indication correct locally and remotely."
        },
        {
          "id": "psysm_ind_task3_status",
          "label": "Alarms, flags and LEDs are reset.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_ind_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Alarms, flags and LEDs are reset."
        }
      ]
    },
    {
      "title": "Test Block Maintenance Tasks",
      "fields": [
        {
          "id": "psysm_tb_task1_status",
          "label": "Clean, free from dust and foreign materials.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_tb_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Clean, free from dust and foreign materials."
        },
        {
          "id": "psysm_tb_task2_status",
          "label": "Connections tight and secure.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_tb_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Connections tight and secure."
        },
        {
          "id": "psysm_tb_task3_status",
          "label": "Make and break action of contacts operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_tb_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Make and break action of contacts operate correctly."
        },
        {
          "id": "psysm_tb_task4_status",
          "label": "Covers (where applicable) are fitted.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "psysm_tb_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Covers (where applicable) are fitted."
        }
      ]
    }
  ]
};
})();
