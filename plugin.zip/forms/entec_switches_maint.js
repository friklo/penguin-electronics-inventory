(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.entec_switches_maint = {
  "id": "entec_switches_maint",
  "title": "ENTEC ENCLOSED SWITCHES MAINTENANCE CHECKLIST",
  "sections": [
    {
      "title": "General",
      "fields": [
        {
          "id": "entec_asset_num",
          "label": "Asset Number",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_project_no",
          "label": "Project No.",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_location",
          "label": "Location",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_feeder",
          "label": "Feeder",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_manufacturer",
          "label": "Manufacturer",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_model",
          "label": "Model",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_serial_no",
          "label": "Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_voltage",
          "label": "Voltage",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_test_equip",
          "label": "Test Equipment/Tools Used",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_test_asset_no",
          "label": "Asset No.",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_calib_date",
          "label": "Test/Calibration Date",
          "type": "date",
          "required": false
        },
        {
          "id": "entec_expiry_date",
          "label": "Expiry Date",
          "type": "date",
          "required": false
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "entec_task1_status",
          "label": "Check for signs of imminent failure such as odours or unusual noises.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "entec_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check for signs of imminent failure such as odours or unusual noises."
        },
        {
          "id": "entec_task2_status",
          "label": "Check all appropriate hazard & equipment ID is present and in good legible condition.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "entec_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check all appropriate hazard & equipment ID is present and in good legible condition."
        },
        {
          "id": "entec_task3_status",
          "label": "Check any external visible earth is attached to the unit and not broken or disconnected.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "entec_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check any external visible earth is attached to the unit and not broken or disconnected."
        },
        {
          "id": "entec_task4_status",
          "label": "Check all surge arrester earthing is intact and surge arresters are visually in good condition.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "entec_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check all surge arrester earthing is intact and surge arresters are visually in good condition."
        },
        {
          "id": "entec_task5_status",
          "label": "Check gas is at the correct level as per the manufacturer\u2019s specification.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "entec_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check gas is at the correct level as per the manufacturer\u2019s specification."
        },
        {
          "id": "entec_task6_status",
          "label": "Visually inspect unit for rust, debris or other signs of distress or damage.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "entec_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Visually inspect unit for rust, debris or other signs of distress or damage."
        },
        {
          "id": "entec_task7_status",
          "label": "Check links are in good condition and have earthing spigots attached.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "entec_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": false,
          "rows": 3,
          "help": "Check links are in good condition and have earthing spigots attached."
        }
      ]
    },
    {
      "title": "Test Completed",
      "fields": [
        {
          "id": "entec_test_equip_used",
          "label": "Test Equipment Used",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_test_equip_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": false
        },
        {
          "id": "entec_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": false
        },
        {
          "id": "entec_test_comments",
          "label": "Entec test comments",
          "type": "textarea",
          "required": false,
          "rows": 3
        },
        {
          "id": "entec_notes",
          "label": "Notes",
          "type": "textarea",
          "required": false,
          "rows": 3
        }
      ]
    }
  ]
};
})();
