(function () {
  "use strict";

  var STORAGE_KEY = "ofs_data";
  var debounceTimer = null;

  function loadLocal() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  function saveLocal(formData) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(function () {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
    }, 400);
  }

  function saveToActivity(formData) {
    window.parent.postMessage({
      apiVersion: 1,
      method: "update",
      activity: {
        customProperties: {
          xa_worksheet_data: JSON.stringify(formData)
        }
      }
    }, "*");
  }

  function loadFromActivity(activity) {
    var cp = activity && activity.customProperties;
    var raw = cp && cp.xa_worksheet_data;
    if (!raw) return {};
    try {
      return JSON.parse(raw);
    } catch (e) {
      return {};
    }
  }

  window.StorageManager = {
    loadLocal: loadLocal,
    saveLocal: saveLocal,
    saveToActivity: saveToActivity,
    loadFromActivity: loadFromActivity
  };
})();
