(function () {
  "use strict";

  function esc(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function renderField(formId, field, value) {
    var id = "f_" + formId + "_" + field.id;
    var label = field.label || field.id;
    var required = field.required ? '<span class="text-danger">*</span>' : "";
    var help = field.help ? '<div class="field-help mt-1">' + esc(field.help) + "</div>" : "";
    var v = value == null ? "" : value;
    var showIfAttr = field.showIf ? " data-show-if='" + JSON.stringify(field.showIf).replace(/'/g, "&apos;") + "'" : "";
    var parentFieldAttr = "";
    if (field.showIf && field.showIf.length === 1 && field.showIf[0] && field.showIf[0].field) {
      parentFieldAttr = ' data-parent-field="' + esc(field.showIf[0].field) + '"';
    }
    var reqAttr = field.required ? ' data-required="true"' : "";
    var fid = String(field.id || "");
    var flabel = String(field.label || "").toLowerCase();
    var isGpsField =
      fid === "gps_location" ||
      fid === "xa_ws_gps_location" ||
      fid === "gps_coordinates" ||
      fid === "xa_ws_dc_1" ||
      fid.toLowerCase().indexOf("gps") >= 0 ||
      flabel.indexOf("gps") >= 0;
    var roAttr = (field.readonly || isGpsField) ? ' readonly="readonly"' : "";
    var isCommentField = /(?:^comm_\d+$|_comm(?:ents)?(?:_\d+)?$|comments?$)/i.test(fid);
    var isStatusField = /(?:^cond_\d+$|^status_\d+$|_status(?:_\d+)?$|_cond(?:_\d+)?$|_result(?:_\d+)?$)/i.test(fid);
    var wrapClass = "mb-3";
    if (isCommentField) wrapClass += " field-comment";
    if (isStatusField) wrapClass += " field-status";

    if (field.type === "textarea") {
      return '' +
        '<div class="' + wrapClass + '" data-field-wrap="' + field.id + '"' + showIfAttr + parentFieldAttr + reqAttr + ">" +
        '<label class="form-label" for="' + id + '">' + esc(label) + " " + required + "</label>" +
        '<textarea class="form-control" id="' + id + '" data-field-id="' + field.id + '" rows="' + (field.rows || 3) + '"' + roAttr + '>' + esc(v) + "</textarea>" +
        help +
        "</div>";
    }

    if (field.type === "select") {
      var isMulti = !!field.multiple;
      var selectedValues = Array.isArray(v) ? v.map(String) : (v == null || v === "" ? [] : [String(v)]);
      var emptySelected = selectedValues.length === 0 ? " selected" : "";
      var placeholder = isMulti ? "" : ('<option value=""' + emptySelected + ">Select...</option>");
      var opts = (field.options || []).map(function (opt) {
        var ov = typeof opt === "string" ? opt : opt.value;
        var ol = typeof opt === "string" ? opt : (opt.label || opt.value);
        var selected = selectedValues.indexOf(String(ov)) >= 0 ? " selected" : "";
        return '<option value="' + esc(ov) + '"' + selected + ">" + esc(ol) + "</option>";
      }).join("");
      var multipleAttr = isMulti ? " multiple" : "";
      return '' +
        '<div class="' + wrapClass + '" data-field-wrap="' + field.id + '"' + showIfAttr + parentFieldAttr + reqAttr + ">" +
        '<label class="form-label" for="' + id + '">' + esc(label) + " " + required + "</label>" +
        '<select class="form-select" id="' + id + '" data-field-id="' + field.id + '"' + multipleAttr + '>' + placeholder + opts + "</select>" +
        help +
        "</div>";
    }

    if (field.type === "radio") {
      var radios = (field.options || []).map(function (opt, idx) {
        var ov = typeof opt === "string" ? opt : opt.value;
        var ol = typeof opt === "string" ? opt : (opt.label || opt.value);
        var rid = id + "_" + idx;
        var checked = String(v) === String(ov) ? " checked" : "";
        return (
          '<div class="form-check form-check-inline">' +
          '<input class="form-check-input" type="radio" name="' + id + '_group" id="' + rid + '" data-field-id="' + field.id + '" value="' + esc(ov) + '"' + checked + ">" +
          '<label class="form-check-label" for="' + rid + '">' + esc(ol) + "</label>" +
          "</div>"
        );
      }).join("");
      return '' +
        '<div class="' + wrapClass + '" data-field-wrap="' + field.id + '"' + showIfAttr + parentFieldAttr + reqAttr + ">" +
        '<div class="form-label mb-1">' + esc(label) + " " + required + "</div>" +
        radios +
        help +
        "</div>";
    }

    if (field.type === "checkbox") {
      var checked = v ? " checked" : "";
      return '' +
        '<div class="' + wrapClass + ' form-check" data-field-wrap="' + field.id + '"' + showIfAttr + parentFieldAttr + reqAttr + ">" +
        '<input class="form-check-input" type="checkbox" id="' + id + '" data-field-id="' + field.id + '"' + checked + ">" +
        '<label class="form-check-label" for="' + id + '">' + esc(label) + " " + required + "</label>" +
        help +
        "</div>";
    }

    var minAttr = field.min != null ? ' min="' + esc(field.min) + '"' : "";
    var maxAttr = field.max != null ? ' max="' + esc(field.max) + '"' : "";
    var stepAttr = field.step != null ? ' step="' + esc(field.step) + '"' : "";
    return '' +
      '<div class="' + wrapClass + '" data-field-wrap="' + field.id + '"' + showIfAttr + parentFieldAttr + reqAttr + ">" +
      '<label class="form-label" for="' + id + '">' + esc(label) + " " + required + "</label>" +
      '<input class="form-control" type="' + (field.type || "text") + '" id="' + id + '" data-field-id="' + field.id + '" value="' + esc(v) + '"' + minAttr + maxAttr + stepAttr + roAttr + '>' +
      help +
      "</div>";
  }

  function renderForm(formConfig, formData) {
    var sections = (formConfig.sections || []).map(function (sec) {
      var fieldsHtml = (sec.fields || []).map(function (f) {
        return renderField(formConfig.id, f, formData ? formData[f.id] : "");
      }).join("");
      return '' +
        '<section class="mb-4" data-form-section="true">' +
        '<h3 class="h6 border-bottom pb-2 mb-3">' + esc(sec.title || "Section") + "</h3>" +
        fieldsHtml +
        "</section>";
    }).join("");

    return '' +
      '<div class="card form-card mb-3">' +
      '<div class="card-body">' +
      '<h2 class="h5 mb-3">' + esc(formConfig.title) + "</h2>" +
      sections +
      "</div>" +
      "</div>";
  }

  function collectFormValues(formRoot) {
    var values = {};
    formRoot.querySelectorAll("[data-field-id]").forEach(function (el) {
      var key = el.getAttribute("data-field-id");
      if (!key) return;
      if (el.type === "radio") {
        if (el.checked) values[key] = el.value;
      } else if (el.tagName === "SELECT" && el.multiple) {
        values[key] = Array.prototype.slice.call(el.selectedOptions).map(function (o) { return o.value; });
      } else if (el.type === "checkbox") {
        values[key] = !!el.checked;
      } else {
        values[key] = el.value;
      }
    });
    return values;
  }

  function evaluateShowIf(showIf, values) {
    if (!showIf || !showIf.length) return true;
    return showIf.every(function (rule) {
      var current = values[rule.field];
      var options = rule.values || [];
      if (Array.isArray(current)) {
        return current.some(function (v) { return options.indexOf(String(v)) >= 0; });
      }
      return options.indexOf(String(current == null ? "" : current)) >= 0;
    });
  }

  function applyVisibility(formRoot, values) {
    formRoot.querySelectorAll("[data-field-wrap]").forEach(function (wrap) {
      var showIfRaw = wrap.getAttribute("data-show-if");
      if (!showIfRaw) {
        wrap.classList.remove("d-none");
        return;
      }
      var showIf;
      try {
        showIf = JSON.parse(showIfRaw.replace(/&apos;/g, "'"));
      } catch (e) {
        showIf = null;
      }
      var visible = evaluateShowIf(showIf, values || {});
      wrap.classList.toggle("d-none", !visible);
      wrap.querySelectorAll("[data-field-id]").forEach(function (el) {
        if (!visible) {
          el.removeAttribute("required");
        } else if (wrap.getAttribute("data-required") === "true" && el.type !== "radio" && el.type !== "checkbox") {
          el.setAttribute("required", "");
        }
      });
    });

    // Hide empty sections so conditionally-gated groups don't show blank headers.
    formRoot.querySelectorAll("[data-form-section='true']").forEach(function (section) {
      var visibleFields = section.querySelectorAll("[data-field-wrap]:not(.d-none)");
      section.classList.toggle("d-none", visibleFields.length === 0);

      // Pair status+comment blocks without relying on CSS :has support.
      var wraps = Array.prototype.slice.call(section.querySelectorAll("[data-field-wrap]"));
      wraps.forEach(function (w) {
        w.classList.remove("paired-with-next", "paired-with-prev", "followup-with-prev");
      });
      for (var i = 0; i < wraps.length - 1; i++) {
        var current = wraps[i];
        var next = wraps[i + 1];
        if (current.classList.contains("d-none") || next.classList.contains("d-none")) continue;
        if (current.classList.contains("field-status") && next.classList.contains("field-comment")) {
          current.classList.add("paired-with-next");
          next.classList.add("paired-with-prev");
        }
        var parentField = next.getAttribute("data-parent-field");
        var currentField = current.getAttribute("data-field-wrap");
        if (parentField && currentField && parentField === currentField) {
          next.classList.add("followup-with-prev");
          current.classList.add("paired-with-next");
        }
      }
    });
  }

  window.SchemaRenderer = {
    renderForm: renderForm,
    collectFormValues: collectFormValues,
    applyVisibility: applyVisibility
  };
})();
