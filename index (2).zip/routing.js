(function() {
  /**
   * Work type (activity.aworktype) -> plugin content URL.
   * Keys are matched case-insensitively. Add OFSC aliases here as needed.
   */
  var WORK_TYPE_PATHS = {
    /* HSL Maintenance - unified asset + comms + defect create */
    "HSL Maintenance": "html/maintenance/index.html",
    HSL_maintenance: "html/maintenance/index.html",
    HSL_asset_maintenance: "html/maintenance/index.html",
    HSL_comms_maintenance: "html/maintenance/index.html",
    /* HSL Inspect - Asset Health Index checklists only */
    "HSL Inspect Asset": "html/inspect_asset/index.html?forms=ahi",
    HSL_inspect_asset: "html/inspect_asset/index.html?forms=ahi",
    /* HEDL Inspect - same AHI set */
    "HEDL Inspect Asset": "html/inspect_asset/index.html?forms=ahi",
    HEDL_inspect_Asset: "html/inspect_asset/index.html?forms=ahi",
    /* Defect Create only */
    "HSL Unproductive": "html/defect_create/Defect Create.html",
    HSL_unproductive: "html/defect_create/Defect Create.html",
    "HSL Asset Works": "html/defect_create/Defect Create.html",
    HSL_asset_Works: "html/defect_create/Defect Create.html",
    "HSL Auxillary": "html/defect_create/Defect Create.html",
    HSL_auxillary: "html/defect_create/Defect Create.html",
    "HSL Auxiliary": "html/defect_create/Defect Create.html",
    HSL_auxiliary: "html/defect_create/Defect Create.html",
    "HSL Vegetation": "html/defect_create/Defect Create.html",
    HSL_vegetation: "html/defect_create/Defect Create.html",
    "HSL Streetlight": "html/defect_create/Defect Create.html",
    HSL_streetlight: "html/defect_create/Defect Create.html",
    "HSL Streetlight Fault": "html/defect_create/Defect Create.html",
    HSL_streetlight_fault: "html/defect_create/Defect Create.html",
    "HEDL Verify Information": "html/defect_create/Defect Create.html",
    HEDL_verify_information: "html/defect_create/Defect Create.html",
    "HEDL Conductor Clearance Check": "html/defect_create/Defect Create.html",
    HEDL_conductor_clearance_ceck: "html/defect_create/Defect Create.html",
    "HEDL Cable Locate": "html/defect_create/Defect Create.html",
    HEDL_cable_locate: "html/defect_create/Defect Create.html",
    /* Fault */
    "HSL Fault": "html/Fault_response/index.html",
    HSL_Fault: "html/Fault_response/index.html",
    HSL_fault_response: "html/Fault_response/index.html",
    /* Earth bank / conduct test */
    "HEDL Earth Bank Test": "html/Conduct_test/index.html",
    HEDL_earth_bank_test: "html/Conduct_test/index.html",
    HSL_conduct_test: "html/Conduct_test/index.html"
  };

  window.showWorkTypeContent = function(aworktype, activity) {
    var frame = document.getElementById("content-frame");
    var unknown = document.getElementById("unknown-worktype");
    if (!frame || !unknown) return;

    var path = null;
    if (aworktype) {
      path = WORK_TYPE_PATHS[aworktype];
      if (!path) {
        var key = Object.keys(WORK_TYPE_PATHS).filter(function(k) { return k.toLowerCase() === String(aworktype).toLowerCase(); })[0];
        if (key) path = WORK_TYPE_PATHS[key];
      }
    }
    if (!path) {
      frame.style.display = "none";
      frame.src = "about:blank";
      unknown.style.display = "block";
      var header = document.getElementById("plugin-header");
      if (header) header.style.display = "none";
      return;
    }

    unknown.style.display = "none";
    frame.style.display = "block";
    var header = document.getElementById("plugin-header");
    if (header) header.style.display = "flex";
    var singleFormPrefill = {
      "html/Fault_response/index.html": { formId: "fault_response", formTitle: "Fault Script with Work Order Creation" },
      "html/Conduct_test/index.html": { formId: "conduct_test", formTitle: "Earthing test for all Asset types" }
    };
    var pathForLoad = path;
    var activityForLoad = activity;
    frame.onload = function() {
      try {
        var plugin = window.ofscPlugin;
        if (frame.contentWindow && activityForLoad) {
          // Send activity data and prefill data to iframe
          var prefillData = (plugin && typeof plugin.getPrefillDataForForm === "function") ? plugin.getPrefillDataForForm() : [];
          frame.contentWindow.postMessage({ type: "OPEN_DATA", activity: activityForLoad, prefillData: prefillData }, "*");

          // Also send ACTIVITY_PREFILL message for forms that listen for it
          if (prefillData && prefillData.length > 0) {
            frame.contentWindow.postMessage({ type: "ACTIVITY_PREFILL", formData: prefillData, readOnly: false }, "*");
          }

          var pathKey = pathForLoad.split("?")[0];
          var prefillInfo = singleFormPrefill[pathKey];
          if (prefillInfo && plugin && typeof plugin.getSubmittedFormIdsFromAttachments === "function") {
            plugin.getSubmittedFormIdsFromAttachments(activityForLoad, [{ formId: prefillInfo.formId, formTitle: prefillInfo.formTitle }]).then(function(submittedIds) {
              if (submittedIds && submittedIds.indexOf(prefillInfo.formId) >= 0 && typeof plugin.fetchSubmittedFormData === "function") {
                return plugin.fetchSubmittedFormData(prefillInfo.formId, prefillInfo.formTitle);
              }
              return [];
            }).then(function(formData) {
              try {
                if (frame.contentWindow && Array.isArray(formData) && formData.length > 0) {
                  frame.contentWindow.postMessage({ type: "FORM_PREFILL", formData: formData, readOnly: true }, "*");
                }
              } catch (e) { console.warn("FORM_PREFILL postMessage failed", e); }
            });
          }
        }
      } catch (e) { console.warn("OPEN_DATA postMessage failed", e); }
    };
    frame.src = path;
  };

  document.addEventListener("DOMContentLoaded", function() {
    var btn = document.getElementById("close-btn");
    if (btn) {
      btn.addEventListener("click", function() {
        if (window.ofscPlugin) {
          window.ofscPlugin.sendPostMessageData({ apiVersion: 1, method: "close" });
        }
      });
    }
  });
})();
