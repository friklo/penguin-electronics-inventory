/**
 * Listens for FORM_PREFILL and ACTIVITY_PREFILL messages from parent and fills form fields by name.
 * ACTIVITY_PREFILL: Prefills from activity/asset data (editable)
 * FORM_PREFILL: Prefills from previously submitted form (read-only)
 * When readOnly is true, disables all inputs and submit so the form is view-only.
 */
(function() {
  /**
   * Fill form fields with provided data
   * @param {Array} formData - Array of {fieldName, value} objects
   * @param {boolean} overwriteExisting - If false, only fill empty fields
   */
  /** Keys appended to SCM CSV for context — do not map onto form controls. */
  var CSV_ATTACHMENT_META_KEYS = {
    activity_id: 1, work_type: 1, work_order_id: 1, appt_number: 1,
    customer_address: 1, customer_city: 1, customer_state: 1, customer_zip: 1,
    latitude: 1, longitude: 1, gps_coordinates: 1, asset_number: 1, feeder: 1,
    voltage_level: 1, nav_wip: 1, nav_build_job_number: 1, resource_id: 1,
    submission_timestamp: 1, completed_by: 1, completed_by_login: 1
  };

  /**
   * @param {Array} formData
   * @param {boolean} overwriteExisting
   * @param {boolean} [skipGpsFields] - when true, do not apply prefill to GPS controls (device capture fills them).
   */
  function fillFormWithData(formData, overwriteExisting, skipGpsFields) {
    if (!formData || !Array.isArray(formData)) return;
    formData.forEach(function(row) {
      var name = row.fieldName || row.fieldId;
      if (!name) return;
      if (skipGpsFields && isGpsFieldName(name)) return;
      if (CSV_ATTACHMENT_META_KEYS[String(name).toLowerCase()]) return;
      var els = document.querySelectorAll('[name="' + name + '"], [id="' + name + '"]');
      if (els.length === 0) return;
      var value = row.value;
      if (value === null || value === undefined || value === '') return;

      els.forEach(function(el) {
        var type = (el.type || '').toLowerCase();
        var tag = (el.tagName || '').toLowerCase();

        // Skip if field already has value and we don't want to overwrite
        if (!overwriteExisting) {
          if (type === 'checkbox' || type === 'radio') {
            // For checkboxes/radios, check if any in the group is checked
            var groupName = el.name;
            if (groupName) {
              var anyChecked = document.querySelector('[name="' + groupName + '"]:checked');
              if (anyChecked) return;
            }
          } else if (el.value && el.value.trim() !== '') {
            return;
          }
        }

        if (type === 'checkbox') {
          el.checked = value === true || value === 'true' || value === '1' || String(value).toLowerCase() === 'yes';
        } else if (type === 'radio') {
          if (String(el.value).toLowerCase() === String(value).toLowerCase()) el.checked = true;
        } else if (tag === 'select') {
          // For select, try to match option value (case-insensitive)
          var options = el.options;
          var valueLower = String(value).toLowerCase();
          for (var i = 0; i < options.length; i++) {
            if (options[i].value.toLowerCase() === valueLower || options[i].text.toLowerCase() === valueLower) {
              el.selectedIndex = i;
              break;
            }
          }
        } else if (type === 'date') {
          // Ensure date is in YYYY-MM-DD format
          var dateVal = String(value);
          if (dateVal.indexOf('T') > 0) dateVal = dateVal.split('T')[0];
          el.value = dateVal;
        } else {
          el.value = value != null ? String(value) : '';
        }

        // Trigger change event for toggle controls
        if (el.classList.contains('toggle-control')) {
          try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
        }
      });
    });
  }

  function isGpsFieldName(name) {
    if (!name) return false;
    var lower = String(name).toLowerCase();
    return lower === 'latitude' ||
      lower === 'lat' ||
      lower === 'longitude' ||
      lower === 'lng' ||
      lower === 'lon' ||
      lower === 'gps_location' ||
      lower === 'gps_coordinates' ||
      lower === 'xa_ws_dc_1' ||
      lower === 'xa_ws_gps_location' ||
      lower === 'xa_ws_etfaat_5';
  }

  var gpsReadonlyStyleInjected = false;
  function ensureGpsReadonlyStyle() {
    if (gpsReadonlyStyleInjected) return;
    gpsReadonlyStyleInjected = true;
    var st = document.createElement('style');
    st.textContent =
      'input.gps-readonly, textarea.gps-readonly { background-color: #f0f0f0 !important; color: #333 !important; cursor: not-allowed !important; }';
    document.head.appendChild(st);
  }

  function lockGpsFields() {
    ensureGpsReadonlyStyle();
    document.querySelectorAll('input[name], textarea[name], input[id], textarea[id]').forEach(function(el) {
      var name = el.name || el.id;
      if (!isGpsFieldName(name)) return;
      if (!el.value || !String(el.value).trim()) return;
      el.readOnly = true;
      el.setAttribute('readonly', 'readonly');
      el.setAttribute('aria-readonly', 'true');
      el.setAttribute('title', 'Location captured from this device (read-only)');
      el.classList.add('gps-readonly');
    });
  }

  function formatCoordPair(lat, lng) {
    return Number(lat).toFixed(6) + ',' + Number(lng).toFixed(6);
  }

  function coordsFromActivity(activity) {
    if (!activity) return null;
    var lat = activity.latitude != null ? parseFloat(String(activity.latitude).replace(/,/g, '')) : NaN;
    var lng = activity.longitude != null ? parseFloat(String(activity.longitude).replace(/,/g, '')) : NaN;
    if (isFinite(lat) && isFinite(lng)) return { lat: lat, lng: lng };
    var gc = activity.gps_coordinates || activity.gpsCoordinates || activity.gps_location;
    if (gc != null) {
      var s = String(gc).trim();
      var idx = s.indexOf(',');
      if (idx > 0) {
        var la = parseFloat(s.substring(0, idx).replace(/,/g, ''));
        var lo = parseFloat(s.substring(idx + 1).replace(/,/g, ''));
        if (isFinite(la) && isFinite(lo)) return { lat: la, lng: lo };
      }
    }
    return null;
  }

  var gpsCaptureInFlight = false;
  var gpsCaptureCompleted = false;

  /** Fill known GPS text fields and lock; prefers phone geolocation, else OFSC activity coordinates. */
  function applyDeviceGeolocation(activity) {
    if (gpsCaptureInFlight || gpsCaptureCompleted) return;
    gpsCaptureInFlight = true;
    function finishCapture() {
      gpsCaptureInFlight = false;
      gpsCaptureCompleted = true;
    }
    function applyCoords(lat, lng) {
      var coordsStr = formatCoordPair(lat, lng);
      document.querySelectorAll('input, textarea').forEach(function(el) {
        var typ = (el.type || '').toLowerCase();
        if (typ === 'hidden' || typ === 'file' || typ === 'checkbox' || typ === 'radio' || typ === 'submit' || typ === 'button') return;
        var n = el.name || el.id;
        if (!isGpsFieldName(n)) return;
        el.value = coordsStr;
        el.readOnly = true;
        el.setAttribute('readonly', 'readonly');
        el.setAttribute('aria-readonly', 'true');
        el.setAttribute('autocomplete', 'off');
        el.setAttribute('title', 'Location captured from this device (read-only)');
        el.classList.add('gps-readonly');
        try {
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
        } catch (e) {}
      });
      lockGpsFields();
      finishCapture();
    }
    function fallbackActivity() {
      var p = coordsFromActivity(activity);
      if (p) applyCoords(p.lat, p.lng);
      else {
        lockGpsFields();
        finishCapture();
      }
    }
    if (navigator.geolocation && typeof navigator.geolocation.getCurrentPosition === 'function') {
      navigator.geolocation.getCurrentPosition(
        function(pos) {
          applyCoords(pos.coords.latitude, pos.coords.longitude);
        },
        function() {
          fallbackActivity();
        },
        { enableHighAccuracy: true, maximumAge: 0, timeout: 25000 }
      );
    } else {
      fallbackActivity();
    }
  }

  function setFormReadOnly(readOnly) {
    if (!readOnly) return;
    var style = document.createElement('style');
    style.textContent = 'input:disabled, select:disabled, textarea:disabled { background-color: #e9e9e9 !important; color: #555 !important; cursor: not-allowed; }';
    document.head.appendChild(style);
    document.querySelectorAll('input, select, textarea, button').forEach(function(el) {
      var tag = (el.tagName || '').toLowerCase();
      if (tag === 'button' && (el.type || '').toLowerCase() === 'submit') {
        el.disabled = true;
        el.style.opacity = '0.6';
      } else if (tag !== 'button') {
        el.readOnly = true;
        el.disabled = true;
      }
    });
  }

  window.addEventListener('message', function(event) {
    var raw = event.data;
    var data = typeof raw === 'string' ? (function() { try { return JSON.parse(raw); } catch (x) { return null; } })() : raw;
    if (!data) return;

    // ACTIVITY_PREFILL / OPEN_DATA: prefill non-GPS from activity; GPS comes from device (or activity fallback).
    if (data.type === 'ACTIVITY_PREFILL' || data.type === 'OPEN_DATA') {
      var activity = data.activity;
      var prefillData = data.prefillData || data.formData;
      var shouldOverwrite = data.overwriteExisting === true;
      setTimeout(function() {
        if (Array.isArray(prefillData) && prefillData.length > 0) {
          fillFormWithData(prefillData, shouldOverwrite, true);
        }
        applyDeviceGeolocation(activity);
      }, 100);
    }

    // FORM_PREFILL: Prefill from previously submitted form (read-only, overwrite all)
    if (data.type === 'FORM_PREFILL' || data.type === 'MARK_FORM_SUBMITTED') {
      var formData = data.formData;
      if (Array.isArray(formData)) fillFormWithData(formData, true, false);
      lockGpsFields();
      if (data.readOnly !== false) setFormReadOnly(true);
    }
  });

  /** Strip noise from heading / label text for CSV export. */
  function cleanExportText(t) {
    if (t == null) return '';
    var s = String(t).replace(/<span[^>]*class="[^"]*required[^"]*"[^>]*>[\s\S]*?<\/span>/gi, '').replace(/\s+/g, ' ').trim();
    return s.replace(/\s*[*:]+\s*$/g, '').trim();
  }

  function escapeAttrSelector(val) {
    if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(String(val));
    return String(val).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
  }

  function countElementsWithId(formRoot, id) {
    if (!id || !formRoot) return 0;
    try {
      return formRoot.querySelectorAll('[id="' + String(id).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"]').length;
    } catch (e) {
      return 0;
    }
  }

  function textFromAriaLabelledby(el, formRoot) {
    var raw = el.getAttribute('aria-labelledby');
    if (!raw || !formRoot) return '';
    var parts = raw.split(/\s+/).filter(Boolean);
    var chunks = [];
    for (var i = 0; i < parts.length; i++) {
      var ref = formRoot.getElementById(parts[i]) || document.getElementById(parts[i]);
      if (ref) chunks.push(cleanExportText(ref.textContent));
    }
    return cleanExportText(chunks.join(' '));
  }

  /** First table cell text in the same row (task / prompt), when control is not in that cell. */
  function getTableRowDescriptor(el) {
    var tr = el.closest && el.closest('tr');
    if (!tr || !tr.cells || !tr.cells.length) return '';
    var ownCell = el.closest('td, th');
    var idx = ownCell ? ownCell.cellIndex : -1;
    if (idx <= 0) return '';
    var first = tr.cells[0];
    if (!first || first.contains(el)) return '';
    return cleanExportText(first.textContent);
  }

  /** Matching thead th text for this column (e.g. Comments). */
  function getTableColumnHeader(el) {
    var table = el.closest && el.closest('table');
    var ownCell = el.closest && el.closest('td, th');
    if (!table || !ownCell) return '';
    var thead = table.querySelector('thead tr');
    if (!thead || !thead.cells || ownCell.cellIndex < 0) return '';
    var th = thead.cells[ownCell.cellIndex];
    if (!th) return '';
    return cleanExportText(th.textContent);
  }

  /** Label as previous sibling in a .field wrapper (label then control). */
  function getLabelFromFieldWrapper(el) {
    var p = el.parentElement;
    if (!p || !p.children || p.children.length < 2) return '';
    if (!p.className || String(p.className).indexOf('field') < 0) return '';
    var first = p.children[0];
    var second = p.children[1];
    if (first && first.tagName === 'LABEL' && second === el) return cleanExportText(first.textContent);
    return '';
  }

  /** Walk previousElementSibling chain; skip same-group radios. */
  function findPrecedingSiblingLabel(el) {
    var typ = (el.type || '').toLowerCase();
    var n = el.previousElementSibling;
    var hops = 0;
    while (n && hops++ < 40) {
      var tag = (n.tagName || '').toLowerCase();
      if (tag === 'label') return cleanExportText(n.textContent);
      if (typ === 'radio' && tag === 'input' && (n.type || '').toLowerCase() === 'radio' && n.name === el.name) {
        n = n.previousElementSibling;
        continue;
      }
      if (tag === 'input' || tag === 'select' || tag === 'textarea') break;
      n = n.previousElementSibling;
    }
    return '';
  }

  /**
   * Resolved human-readable caption for a control (CSV "Question" column source).
   * Order: data-export-label, aria-*, unique id+for, wrapping label, .field layout, preceding label, table row + column, placeholder, title, name.
   */
  window.getResolvedFieldLabel = function(el, formRoot) {
    if (!el) return '';
    var dl = el.getAttribute('data-export-label');
    if (dl) return cleanExportText(dl);
    var al = el.getAttribute('aria-label');
    if (al) return cleanExportText(al);
    var alby = textFromAriaLabelledby(el, formRoot || el.form || document);
    if (alby) return alby;

    var fid = el.id;
    var form = formRoot || (el.form || document);
    if (fid && countElementsWithId(form, fid) === 1) {
      var le = form.querySelector('label[for="' + escapeAttrSelector(fid) + '"]');
      if (le) return cleanExportText(le.textContent);
    }

    var wrap = el.closest('label');
    if (wrap) {
      var inner = cleanExportText(wrap.textContent);
      if (inner) return inner;
    }

    var fieldLab = getLabelFromFieldWrapper(el);
    if (fieldLab) return fieldLab;

    var prevLab = findPrecedingSiblingLabel(el);
    if (prevLab) return prevLab;

    var rowDesc = getTableRowDescriptor(el);
    var colHead = getTableColumnHeader(el);
    var shortBits = [];
    if (wrap) shortBits.push(cleanExportText(wrap.textContent));
    if (!shortBits.length && colHead) shortBits.push(colHead);
    if (rowDesc) {
      if (shortBits.length) return rowDesc + ' — ' + shortBits.join(' — ');
      return rowDesc;
    }

    var ph = (el.getAttribute('placeholder') || '').trim();
    if (ph.length >= 3 && ph.toLowerCase() !== 'notes...' && ph.toLowerCase() !== 'select...') return cleanExportText(ph);
    var ti = (el.getAttribute('title') || '').trim();
    if (ti) return cleanExportText(ti);

    return el.name ? String(el.name) : '';
  };

  /**
   * Build a hierarchy path (e.g. "GENERAL INFORMATION > Site access") for a field from surrounding headings.
   * Works with .form-section h2, h2/h3/h4.section-title, fieldset legend, table caption, and table section titles.
   */
  window.getFormFieldHierarchy = function(el, formRoot) {
    if (!el || !formRoot) return '';
    var segments = [];
    var node = el;
    while (node && node !== formRoot) {
      var sib = node.previousElementSibling;
      while (sib) {
        if (sib.matches && sib.matches('section.form-section')) {
          var h2 = sib.querySelector(':scope > h2');
          var h3 = sib.querySelector(':scope > h3');
          if (h2) segments.unshift(cleanExportText(h2.textContent));
          else if (h3) segments.unshift(cleanExportText(h3.textContent));
        } else if (sib.matches && sib.matches('h2.section-title, h3.section-title, h4.section-title')) {
          segments.unshift(cleanExportText(sib.textContent));
        } else if (sib.matches && sib.matches('fieldset')) {
          var leg = sib.querySelector('legend');
          if (leg) segments.unshift(cleanExportText(leg.textContent));
        }
        sib = sib.previousElementSibling;
      }
      node = node.parentElement;
    }
    var table = el.closest && el.closest('table');
    if (table && formRoot.contains(table)) {
      var cap = table.querySelector('caption');
      if (cap) {
        var capT = cleanExportText(cap.textContent);
        if (capT) segments.unshift(capT);
      }
      var p = table.previousElementSibling;
      while (p) {
        if (p.matches && p.matches('h2.section-title, h3.section-title, h3, h4.section-title, h4')) {
          segments.unshift(cleanExportText(p.textContent));
          break;
        }
        p = p.previousElementSibling;
      }
    }
    var out = [];
    for (var i = 0; i < segments.length; i++) {
      if (segments[i] && out.indexOf(segments[i]) < 0) out.push(segments[i]);
    }
    return out.join(' > ');
  };

  /**
   * Collect all named fields for SCM export with labels and heading hierarchy (same-origin forms only).
   */
  window.collectFormRowsWithHierarchy = function(form) {
    if (!form) return [];
    var rows = [];
    var checkboxGroupDone = Object.create(null);
    var els = form.querySelectorAll('input, select, textarea');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      var name = el.name;
      if (!name) continue;
      var tag = (el.tagName || '').toLowerCase();
      var typ = (el.type || '').toLowerCase();
      if (typ === 'submit' || typ === 'button' || typ === 'reset') continue;
      if (typ === 'radio' && !el.checked) continue;
      var cbsAll = typ === 'checkbox'
        ? [].slice.call(form.querySelectorAll('input[type="checkbox"]')).filter(function(c) { return c.name === name; })
        : [];
      if (typ === 'checkbox' && cbsAll.length > 1) {
        if (checkboxGroupDone[name]) continue;
        checkboxGroupDone[name] = true;
      }

      var label = typeof window.getResolvedFieldLabel === 'function' ? window.getResolvedFieldLabel(el, form) : '';
      if (!label) label = name;

      var val;
      if (tag === 'select') {
        val = el.multiple ? [].map.call(el.selectedOptions, function(o) { return o.value; }) : el.value;
      } else if (typ === 'checkbox') {
        val = cbsAll.length > 1 ? cbsAll.filter(function(c) { return c.checked; }).map(function(c) { return c.value; }) : (el.checked ? (el.value || true) : false);
      } else if (typ === 'radio') {
        val = el.value;
      } else if (typ === 'file') {
        val = el.files && el.files.length ? [].map.call(el.files, function(f) { return f.name; }) : null;
      } else {
        val = el.value;
      }

      var hierarchy = typeof window.getFormFieldHierarchy === 'function' ? window.getFormFieldHierarchy(el, form) : '';
      var taskContext = getTableRowDescriptor(el);

      rows.push({
        fieldId: name,
        fieldName: label,
        value: val,
        hierarchy: hierarchy,
        taskContext: taskContext
      });
    }
    return rows;
  };

  document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
      var anyGps = false;
      var anyFilled = false;
      document.querySelectorAll('input, textarea').forEach(function(el) {
        var n = el.name || el.id;
        if (!isGpsFieldName(n)) return;
        anyGps = true;
        if (el.value && String(el.value).trim()) anyFilled = true;
      });
      if (anyGps && !anyFilled && !gpsCaptureCompleted) applyDeviceGeolocation(null);
    }, 2000);
  });
})();
