/**
 * Merged HSL plugin: routes by activity.aworktype to work-type-specific content.
 * Single plugin entry point; form content in asset_maintenance, comms_maintenance, Conduct_test, Fault_response, inspect_asset.
 */

"use strict";
(function () {
  window.OfscPlugin = function () {
    this.jwtCallerId = "";
    this.jwtToken;
    this.geolocationCoordinates = "";
    this.init = function (pluginName) {
      this.tag = pluginName;
      window.addEventListener("message", this._messageListener.bind(this), false);
      this.sendPostMessageData({
        apiVersion: 1,
        method: "ready",
        sendInitData: true,
        showHeader: true,
        enableBackButton: true,
      });
    };
    this.getOrigin = function (url) {
      if (url != "") {
        if (url.indexOf("://") > -1) {
          return "https://" + url.split("/")[2];
        } else {
          return "https://" + url.split("/")[0];
        }
      }
      return "";
    };

    this.getMetaAttributes = function (data) {
      if (data) {
        const json = JSON.parse(data);
        this.XA_DISCREPANCY_REASON_ATTRIBUTES = json["XA_DISCREPANCY_REASON_ATTRIBUTES"]["enum"];
        const reason_code = document.getElementById("reason_code");
        if (reason_code) {
          for (const [key, value] of Object.entries(this.XA_DISCREPANCY_REASON_ATTRIBUTES)) {
            const option = document.createElement("option");
            option.value = key;
            option.text = value.text;
            reason_code.appendChild(option);
          }
        }
      }
    };

    this.searchPart = function () {
      this.sendPostMessageData({
        apiVersion: 1,
        callId: this.generateCallId(),
        method: "callProcedure",
        procedure: "getPartsCatalogsStructure",
      });
    };

    this.countrylist = function (url, userId, passworf) {
      fetch(url, {
        method: "GET",
        headers: { "Content-Type": "application/json" },
      })
        .then((response) => response.json())
        .then((data) => {
          const country = document.getElementById("country");
          if (country) {
            for (const [key, value] of Object.entries(data)) {
              const option = document.createElement("option");
              option.value = key;
              option.text = value.name.official;
              country.appendChild(option);
            }
          }
        });
    };

    this.getGeoLocation = function () {
      return new Promise(function (resolve, reject) {
        navigator.geolocation.getCurrentPosition(
          (pos) => resolve(pos.coords.latitude + "," + pos.coords.longitude),
          (error) => reject(error)
        );
      });
    };


    this.open = function (data) {
      let activity = data.activity;
      let securedData = data.securedData;
      this.currentActivity = activity;
      this.openData = data;
      this.formSubmissions = new Map();
      
      // User/Resource fields
      this.completedBy = (data.user && data.user.uname) ? data.user.uname : "";
      this.completedByLogin = (data.user && data.user.ulogin) ? data.user.ulogin : "";
      this.resourceId = (data.user && data.user.main_resource_id) ? data.user.main_resource_id : "";
      
      // Activity fields (high priority)
      this.activityId = (activity && activity.aid) ? activity.aid : "";
      this.workType = (activity && activity.aworktype) ? activity.aworktype : "";
      this.workOrderId = (activity && activity.mwo_workorder_id) ? activity.mwo_workorder_id : "";
      this.apptNumber = (activity && activity.appt_number) ? activity.appt_number : "";
      this.customerAddress = (activity && activity.caddress) ? activity.caddress : "";
      this.customerCity = (activity && activity.ccity) ? activity.ccity : "";
      this.customerState = (activity && activity.cstate) ? activity.cstate : "";
      this.customerZip = (activity && activity.czip) ? activity.czip : "";
      this.latitude = (activity && activity.latitude) ? activity.latitude : "";
      this.longitude = (activity && activity.longitude) ? activity.longitude : "";
      
      // Build GPS coordinates string
      this.gpsCoordinates = "";
      if (this.latitude && this.longitude) {
        this.gpsCoordinates = this.latitude + "," + this.longitude;
      }
      
      // Build full address string
      this.fullAddress = "";
      var addressParts = [this.customerAddress, this.customerCity, this.customerState, this.customerZip].filter(Boolean);
      if (addressParts.length > 0) this.fullAddress = addressParts.join(", ");
      
      // Asset fields from activity (ast_* fields)
      this.assetNumber = (activity && (activity.ast_ellipseEquipNumber || activity.asset_number || activity.ast_assetNumber)) || "";
      this.navWip = (activity && activity.ast_navWip) || "";
      this.navBuildJobNumber = (activity && activity.ast_navBuildJobNumber) || "";
      this.hvFeeder = (activity && activity.ast_hvFeeder) || "";
      this.lvFeeder = (activity && activity.ast_lvFeeder) || "";
      this.ehvFeeder = (activity && activity.ast_ehvFeeder) || "";
      this.feeder = this.hvFeeder || this.lvFeeder || this.ehvFeeder || "";
      this.voltageLevel = (activity && (activity.ast_voltageLevel || activity.ast_operatingVoltage)) || "";
      this.xCoord = (activity && activity.ast_xCoord) || "";
      this.yCoord = (activity && activity.ast_yCoord) || "";
      
      // Transformer fields
      this.txManufacturer = (activity && activity.ast_txManufacturer) || "";
      this.txModelType = (activity && activity.ast_txModelType) || "";
      this.txKvaRating = (activity && activity.ast_txKvaRating) || "";
      this.txTapSetting = (activity && activity.ast_txTapSetting) || "";
      this.txPrimaryVoltage = (activity && activity.ast_txPrimaryVoltage) || "";
      this.txSecondaryVolt = (activity && activity.ast_txSecondaryVolt) || "";
      this.txNumber = (activity && activity.ast_txNumber) || "";
      
      // RMU fields
      this.rmuManufacturer = (activity && activity.ast_rmuManufacturer) || "";
      this.rmuModel = (activity && activity.ast_rmuModel) || "";
      this.rmuName = (activity && activity.ast_rmuName) || "";
      this.rmuRating = (activity && activity.ast_rmuRating) || "";
      
      // Pole fields
      this.poleManufacturer = (activity && activity.ast_poleManufacturer) || "";
      this.poleMaterial = (activity && activity.ast_poleMaterial) || "";
      this.poleType = (activity && activity.ast_poleType) || "";
      this.poleLength = (activity && activity.ast_poleLength) || "";
      
      // Protection Relay fields
      this.protectionRelayManufacturer = (activity && activity.ast_protectionRelayManufacturer) || "";
      this.protectionRelayModelType = (activity && activity.ast_protectionRelayModelType) || "";
      this.protectionRelaySupplyVoltage = (activity && activity.ast_protectionRelaySupplyVoltage) || "";
      
      // Switch/Breaker fields
      this.switchManufacturer = (activity && activity.ast_switchManufacturer) || "";
      this.switchModel = (activity && activity.ast_switchModel) || "";
      this.breakerManufacturer = (activity && activity.ast_breakerManufacturer) || "";
      this.breakerType = (activity && activity.ast_breakerType) || "";
      this.breakerVoltage = (activity && activity.ast_breakerVoltage) || "";
      
      // Date fields
      this.dateCommissioned = (activity && activity.ast_dateCommissioned) || "";
      this.dateInstalled = (activity && activity.ast_dateInstalled) || "";
      
      // Build prefill data object for forms
      this.prefillData = this.buildPrefillData();
      
      var scmFromData = (securedData && securedData.scm) ? securedData.scm : (data.scm || {});
      this.scmConfig = (scmFromData && scmFromData.baseUrl) ? scmFromData : {
        baseUrl: "https://iaawnf-dev1.fa.ocs.oraclecloud.com",
        categoryName: "MISC",
        auth: {
          type: "basic",
          username: "paras.d.jain@capgemini.com",
          password: "namespace@123",
        },
      };

      if (typeof window.showWorkTypeContent === "function") {
        window.showWorkTypeContent(activity.aworktype, activity);
        return;
      }

      if (typeof window.applySubmittedFormsStatus === "function") {
        window.applySubmittedFormsStatus(activity.xa_form_Status || "");
      }

      const submit = document.getElementById("SubmitBtnId");
      var self = this;
      if (!!submit) {
        submit.addEventListener("click", async () => {
          const fields = {};
          const elements = Array.from(document.querySelectorAll('input[name], textarea[name], select[name]'));
          elements.forEach((el) => {
            const name = el.name;
            if (!name) return;
            const tag = el.tagName.toLowerCase();
            if (tag === 'select') {
              fields[name] = el.multiple ? Array.from(el.selectedOptions).map((o) => o.value) : el.value;
            } else if (el.type === 'checkbox') {
              const checkboxes = document.querySelectorAll(`input[type="checkbox"][name="${name}"]`);
              fields[name] = checkboxes.length > 1 ? Array.from(checkboxes).filter(c => c.checked).map(c => c.value) : (el.checked ? (el.value || true) : false);
            } else if (el.type === 'radio') {
              const checked = document.querySelector(`input[type="radio"][name="${name}"]:checked`);
              fields[name] = checked ? checked.value : null;
            } else if (el.type === 'file') {
              fields[name] = el.files ? Array.from(el.files).map(f => f.name) : null;
            } else {
              fields[name] = el.value;
            }
          });
          const escapeCsv = (v) => {
            const s = String(v == null ? "" : Array.isArray(v) ? v.join("; ") : v);
            return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
          };
          var csv = "\uFEFFField,Value\r\n" + Object.entries(fields).map(([k, v]) => escapeCsv(k) + "," + escapeCsv(v)).join("\r\n");
          // Activity/Work Order fields
          csv += "\r\n" + escapeCsv("activity_id") + "," + escapeCsv(self.activityId || "");
          csv += "\r\n" + escapeCsv("work_type") + "," + escapeCsv(self.workType || "");
          csv += "\r\n" + escapeCsv("work_order_id") + "," + escapeCsv(self.workOrderId || "");
          csv += "\r\n" + escapeCsv("appt_number") + "," + escapeCsv(self.apptNumber || "");
          // Location fields
          csv += "\r\n" + escapeCsv("customer_address") + "," + escapeCsv(self.customerAddress || "");
          csv += "\r\n" + escapeCsv("customer_city") + "," + escapeCsv(self.customerCity || "");
          csv += "\r\n" + escapeCsv("customer_state") + "," + escapeCsv(self.customerState || "");
          csv += "\r\n" + escapeCsv("customer_zip") + "," + escapeCsv(self.customerZip || "");
          csv += "\r\n" + escapeCsv("latitude") + "," + escapeCsv(self.latitude || "");
          csv += "\r\n" + escapeCsv("longitude") + "," + escapeCsv(self.longitude || "");
          csv += "\r\n" + escapeCsv("gps_coordinates") + "," + escapeCsv(self.gpsCoordinates || "");
          // Asset fields
          csv += "\r\n" + escapeCsv("asset_number") + "," + escapeCsv(self.assetNumber || "");
          csv += "\r\n" + escapeCsv("feeder") + "," + escapeCsv(self.feeder || "");
          csv += "\r\n" + escapeCsv("voltage_level") + "," + escapeCsv(self.voltageLevel || "");
          csv += "\r\n" + escapeCsv("nav_wip") + "," + escapeCsv(self.navWip || "");
          csv += "\r\n" + escapeCsv("nav_build_job_number") + "," + escapeCsv(self.navBuildJobNumber || "");
          // Submission metadata
          csv += "\r\n" + escapeCsv("resource_id") + "," + escapeCsv(self.resourceId || "");
          csv += "\r\n" + escapeCsv("submission_timestamp") + "," + escapeCsv(new Date().toISOString());
          csv += "\r\n" + escapeCsv("completed_by") + "," + escapeCsv(self.completedBy || "");
          csv += "\r\n" + escapeCsv("completed_by_login") + "," + escapeCsv(self.completedByLogin || "");
          const csvBlob = new Blob([csv], { type: "text/csv;charset=utf-8" });
          parent.postMessage({ apiVersion: 1, method: "close", activity: { aid: activity.aid, wo_attachment: { fileName: "form_data.csv", fileContents: csvBlob } } }, self.getOrigin(document.referrer));
        });
      }
      const CancelBtnId = document.getElementById("CancelBtnId");
      if (!!CancelBtnId) {
        CancelBtnId.addEventListener("click", () => this.sendPostMessageData({ apiVersion: 1, method: "close" }));
      }
    };

    this.sanitizeFileName = function (name) {
      return String(name || "form").replace(/[<>:"/\\|?*\x00-\x1f]/g, "").replace(/\s+/g, "_").trim() || "form";
    };

    /**
     * Build prefill data object mapping form field names to values from activity/asset data.
     * This object is passed to forms for auto-populating fields.
     */
    this.buildPrefillData = function () {
      var prefill = {};
      var self = this;
      
      // Helper to set value if not empty
      var setIfPresent = function (keys, value) {
        if (!value) return;
        keys.forEach(function (key) { prefill[key] = value; });
      };
      
      // High priority: Activity/Appointment fields
      setIfPresent(["appt_number", "project_no", "ptx_project_no", "rmug_project_no", "rmuo_project_no", "dtx_project_no", "pssm_project_no", "psns_project_no", "rmmc_project_no", "psysm_project_no", "psmnsm_project_no", "pszsrc_project_no", "entec_project_no"], self.apptNumber);
      setIfPresent(["caddress", "address", "site_address", "xa_ws_description", "xa_ws_dc_5"], self.customerAddress);
      setIfPresent(["full_address", "location_address"], self.fullAddress);
      setIfPresent(["ccity", "city"], self.customerCity);
      setIfPresent(["cstate", "state"], self.customerState);
      setIfPresent(["czip", "zip", "postal_code"], self.customerZip);
      setIfPresent(["latitude", "lat"], self.latitude);
      setIfPresent(["longitude", "lng", "lon"], self.longitude);
      setIfPresent(["gps_location", "gps_coordinates", "xa_ws_dc_1", "xa_ws_gps_location", "xa_ws_etfaat_5"], self.gpsCoordinates);
      setIfPresent(["mwo_workorder_id", "work_order_id", "workorder_id"], self.workOrderId);
      
      // Asset identification fields
      setIfPresent([
        "asset_number", "asset_num", "asset_id",
        "ptx_asset_num", "rmug_asset_num", "rmuo_asset_num", "dtx_asset_num", "pssm_asset_num", "psns_asset_num", "rmmc_asset_num", "psysm_asset_num", "psmnsm_asset_num", "pszsrc_asset_num", "entec_asset_num",
        "xa_ws_g_asset_id", "xa_ws_fswwoc_30", "xa_ws_asset_tag_number"
      ], self.assetNumber);
      setIfPresent(["nav_wip", "wip_number", "xa_ws_etfaat_6"], self.navWip);
      setIfPresent(["nav_number", "nav_build_job_number", "xa_ws_g_nav_num"], self.navBuildJobNumber);
      
      // Feeder and Voltage fields
      setIfPresent([
        "feeder", "hv_feeder", "lv_feeder",
        "ptx_feeder", "rmug_feeder", "rmuo_feeder", "dtx_feeder", "pssm_feeder", "psns_feeder", "rmmc_feeder", "psysm_feeder", "psmnsm_feeder", "pszsrc_feeder", "entec_feeder"
      ], self.feeder);
      setIfPresent([
        "voltage", "voltage_level", "operating_voltage",
        "ptx_voltage", "rmug_voltage", "rmuo_voltage", "dtx_voltage", "pssm_voltage", "psns_voltage", "rmmc_voltage", "psysm_voltage", "psmnsm_voltage", "pszsrc_voltage", "entec_voltage",
        "xa_ws_fswwoc_fault_voltage"
      ], self.voltageLevel);
      
      // Location fields (using coordinates if address not available)
      setIfPresent([
        "location", "ptx_location", "rmug_location", "rmuo_location", "dtx_location", "pssm_location", "psns_location", "rmmc_location", "psysm_location", "psmnsm_location", "pszsrc_location", "entec_location"
      ], self.fullAddress || self.customerAddress || self.rmuName);
      
      // Transformer fields
      setIfPresent(["manufacturer", "ptx_manufacturer", "dtx_manufacturer", "tx_manufacturer", "entec_manufacturer", "rmmc_manufacturer"], self.txManufacturer);
      setIfPresent(["model", "ptx_model", "dtx_model", "tx_model", "entec_model", "rmmc_model"], self.txModelType);
      setIfPresent(["kva_rating", "tx_kva_rating"], self.txKvaRating);
      setIfPresent(["tap_setting", "xa_ws_n_tab"], self.txTapSetting);
      setIfPresent(["primary_voltage", "tx_primary_voltage"], self.txPrimaryVoltage);
      setIfPresent(["secondary_voltage", "tx_secondary_volt"], self.txSecondaryVolt);
      
      // RMU fields (override manufacturer/model if RMU-specific)
      if (self.rmuManufacturer) {
        setIfPresent(["rmug_manufacturer", "rmuo_manufacturer", "rmu_manufacturer"], self.rmuManufacturer);
      }
      if (self.rmuModel) {
        setIfPresent(["rmug_model", "rmuo_model", "rmu_model"], self.rmuModel);
      }
      setIfPresent(["rmu_name"], self.rmuName);
      setIfPresent(["rmu_rating"], self.rmuRating);
      
      // Pole fields
      setIfPresent(["pole_manufacturer", "xa_ws_ahiip_11"], self.poleManufacturer);
      setIfPresent(["pole_material", "xa_ws_ahiip_20"], self.poleMaterial);
      setIfPresent(["pole_type"], self.poleType);
      setIfPresent(["pole_length"], self.poleLength);
      
      // Protection Relay fields
      if (self.protectionRelayManufacturer) {
        setIfPresent(["pssm_manufacturer", "psns_manufacturer", "psysm_manufacturer", "psmnsm_manufacturer", "pszsrc_manufacturer", "protection_relay_manufacturer"], self.protectionRelayManufacturer);
      }
      if (self.protectionRelayModelType) {
        setIfPresent(["pssm_model", "psns_model", "psysm_model", "psmnsm_model", "pszsrc_model", "protection_relay_model"], self.protectionRelayModelType);
      }
      if (self.protectionRelaySupplyVoltage) {
        setIfPresent(["pssm_voltage", "psns_voltage"], self.protectionRelaySupplyVoltage);
      }
      
      // Switch/Breaker fields
      setIfPresent(["switch_manufacturer", "breaker_manufacturer"], self.switchManufacturer || self.breakerManufacturer);
      setIfPresent(["switch_model", "breaker_type"], self.switchModel || self.breakerType);
      setIfPresent(["breaker_voltage"], self.breakerVoltage);
      
      // Date fields
      setIfPresent(["date_commissioned"], self.dateCommissioned);
      setIfPresent(["date_installed"], self.dateInstalled);
      
      // Staff/User fields
      setIfPresent(["staff_name", "xa_ws_g_staff_name", "xa_ws_general_information", "completed_by"], self.completedBy);
      
      // Current date for inspection date fields
      var today = new Date().toISOString().split("T")[0];
      setIfPresent(["inspection_date", "xa_ws_g_insp_date", "xa_ws_date", "xa_ws_etfaat_4"], today);
      
      return prefill;
    };

    /**
     * Get prefill data for a specific form, returns array of {fieldName, value} objects
     */
    this.getPrefillDataForForm = function () {
      var prefill = this.prefillData || {};
      var result = [];
      for (var key in prefill) {
        if (prefill.hasOwnProperty(key) && prefill[key]) {
          result.push({ fieldName: key, value: prefill[key] });
        }
      }
      return result;
    };

    this.blobToBase64 = function (blob) {
      return new Promise(function (resolve, reject) {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = reader.result;
          resolve((typeof base64 === "string" && base64.indexOf(",") >= 0 ? base64.split(",")[1] : base64) || "");
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    };

    this.uploadAttachmentToOracleSCM = function (workOrderId, fileName, fileBlob) {
      const scm = this.scmConfig;
      if (!scm || !scm.baseUrl) return Promise.reject(new Error("Oracle SCM config missing: baseUrl required"));
      const activity = this.currentActivity;
      const woId = workOrderId != null ? workOrderId : (scm.workOrderId || (activity && (activity.mwo_workorder_id != null ? activity.mwo_workorder_id : activity.workOrderId)));
      if (woId == null) return Promise.reject(new Error("Work order ID required for SCM attachment"));
      const url = scm.baseUrl.replace(/\/$/, "") + "/fscmRestApi/resources/11.13.18.05/maintenanceWorkOrders/" + woId + "/child/attachments";
      const headers = { "Content-Type": "application/json" };
      if (scm.auth) {
        if (scm.auth.type === "basic" && scm.auth.username != null) headers["Authorization"] = "Basic " + btoa((scm.auth.username || "") + ":" + (scm.auth.password || ""));
        else if ((scm.auth.type === "bearer" || scm.auth.type === "jwt") && scm.auth.token) headers["Authorization"] = "Bearer " + scm.auth.token;
      }
      return this.blobToBase64(fileBlob).then((base64Contents) =>
        fetch(url, { method: "POST", headers, body: JSON.stringify({ DatatypeCode: "FILE", CategoryName: scm.categoryName != null ? scm.categoryName : "MISC", Title: fileName, Description: "Uploaded via OFSC plugin", FileContents: base64Contents }) })
      ).then((response) => {
        if (!response.ok) return response.text().then((t) => { throw new Error("SCM attachment upload failed: " + response.status + " " + t); });
        return response.json();
      });
    };

    this.getScmAuthHeaders = function () {
      var scm = this.scmConfig;
      if (!scm || !scm.auth) return {};
      if (scm.auth.type === "basic" && scm.auth.username != null) return { Authorization: "Basic " + btoa((scm.auth.username || "") + ":" + (scm.auth.password || "")) };
      if ((scm.auth.type === "bearer" || scm.auth.type === "jwt") && scm.auth.token) return { Authorization: "Bearer " + scm.auth.token };
      return {};
    };

    this.getAttachmentsList = function (workOrderId) {
      var scm = this.scmConfig;
      if (!scm || !scm.baseUrl) return Promise.reject(new Error("Oracle SCM config missing"));
      var woId = workOrderId != null ? workOrderId : (this.currentActivity && (this.currentActivity.mwo_workorder_id != null ? this.currentActivity.mwo_workorder_id : this.currentActivity.workOrderId));
      if (woId == null) return Promise.reject(new Error("Work order ID required"));
      var url = scm.baseUrl.replace(/\/$/, "") + "/fscmRestApi/resources/11.13.18.05/maintenanceWorkOrders/" + woId + "/child/attachments";
      return fetch(url, { method: "GET", headers: this.getScmAuthHeaders() }).then(function (res) {
        if (!res.ok) return res.text().then(function (t) { throw new Error("Get attachments failed: " + res.status + " " + t); });
        return res.json();
      });
    };

    this.getAttachmentFileContents = function (enclosureUrl) {
      return fetch(enclosureUrl, { method: "GET", headers: this.getScmAuthHeaders() }).then(function (res) {
        if (!res.ok) return res.text().then(function (t) { throw new Error("Get file contents failed: " + res.status); });
        var ct = (res.headers.get("Content-Type") || "").toLowerCase();
        if (ct.indexOf("application/json") >= 0) return res.json();
        return res.text();
      });
    };

    this.parseCsvToFormData = function (csvText) {
      var raw = csvText;
      if (raw != null && typeof raw === "object") {
        if (typeof raw.FileContents === "string") {
          raw = raw.FileContents;
          try { if (/^[A-Za-z0-9+/=]+$/.test(raw)) raw = decodeURIComponent(escape(atob(raw))); } catch (e) {}
        } else { raw = JSON.stringify(raw); }
      }
      var str = (raw != null && typeof raw !== "string") ? String(raw) : (raw || "");
      var lines = str.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n").filter(Boolean);
      if (lines.length < 2) return [];
      var out = [];
      for (var i = 1; i < lines.length; i++) {
        var line = lines[i], idx = 0;
        function parseField() {
          if (idx >= line.length) return "";
          if (line[idx] === '"') {
            idx++;
            var s = "";
            while (idx < line.length && (line[idx] !== '"' || line[idx + 1] === '"')) { s += line[idx] === '"' && line[idx + 1] === '"' ? '"' : line[idx]; idx += line[idx] === '"' && line[idx + 1] === '"' ? 2 : 1; }
            if (line[idx] === '"') idx++;
            if (line[idx] === ",") idx++;
            return s;
          }
          var comma = line.indexOf(",", idx);
          if (comma < 0) { var r = line.substring(idx).trim(); idx = line.length; return r; }
          var r = line.substring(idx, comma).trim(); idx = comma + 1; return r;
        }
        out.push({ fieldName: parseField(), value: idx < line.length ? parseField() : "" });
      }
      return out;
    };

    /**
     * Determine which forms have a submitted attachment by listing SCM attachments and matching by file name (aid_formTitle.csv).
     * @param {Object} activity - activity with aid (used for expected file name)
     * @param {Array<{formId: string, formTitle: string}>} formEntries - list of { formId, formTitle }
     * @returns {Promise<string[]>} formIds that have a matching attachment
     */
    this.getSubmittedFormIdsFromAttachments = function (activity, formEntries) {
      var self = this;
      var aid = activity && activity.aid;
      if (!formEntries || !formEntries.length) return Promise.resolve([]);
      return this.getAttachmentsList(null).then(function (body) {
        var items = (body && body.items) ? body.items : [];
        var titlesLower = items.map(function (it) { return ((it.Title || it.FileName || "").toLowerCase()); });
        return formEntries.filter(function (entry) {
          var expected = (self.getScmAttachmentFileName(aid, entry.formTitle) || "").toLowerCase();
          return titlesLower.indexOf(expected) >= 0;
        }).map(function (entry) { return entry.formId; });
      }).catch(function (err) {
        console.error(self.tag + " getSubmittedFormIdsFromAttachments error>>", err);
        return [];
      });
    };

    this.fetchSubmittedFormData = function (formId, formTitle) {
      var self = this, activity = this.currentActivity, aid = activity && activity.aid;
      var expectedTitle = this.getScmAttachmentFileName(aid, formTitle);
      return this.getAttachmentsList(null).then(function (body) {
        var items = (body && body.items) ? body.items : [];
        var expectedLower = (expectedTitle || "").toLowerCase();
        var item = items.filter(function (it) { return ((it.Title || it.FileName || "").toLowerCase()) === expectedLower; })[0];
        if (!item || !item.links) return [];
        var enclosure = item.links.filter(function (l) { return l.rel === "enclosure" && (l.name || "") === "FileContents"; })[0];
        if (!enclosure || !enclosure.href) return [];
        return self.getAttachmentFileContents(enclosure.href);
      }).then(function (csvText) { return self.parseCsvToFormData(csvText); }).catch(function (err) { console.error(self.tag + " fetchSubmittedFormData error>>", err); return []; });
    };

    this.getScmAttachmentFileName = function (aid, formTitle) {
      return (aid != null ? String(aid) : "") + "_" + this.sanitizeFileName(formTitle || "form") + ".csv";
    };

    this.buildSingleFormCsv = function (formTitle, formData) {
      var escapeCsv = function (v) { var s = String(v == null ? "" : (Array.isArray(v) ? v.join("; ") : v)); return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
      var rows = Array.isArray(formData) ? formData : [];
      var csvContent = "\uFEFFField,Value\r\n" + rows.map(function (row) { return escapeCsv(row.fieldId || row.fieldName || "") + "," + escapeCsv(row.value); }).join("\r\n");
      
      // Activity/Work Order fields
      csvContent += "\r\n" + escapeCsv("activity_id") + "," + escapeCsv(this.activityId || "");
      csvContent += "\r\n" + escapeCsv("work_type") + "," + escapeCsv(this.workType || "");
      csvContent += "\r\n" + escapeCsv("work_order_id") + "," + escapeCsv(this.workOrderId || "");
      csvContent += "\r\n" + escapeCsv("appt_number") + "," + escapeCsv(this.apptNumber || "");
      
      // Location fields
      csvContent += "\r\n" + escapeCsv("customer_address") + "," + escapeCsv(this.customerAddress || "");
      csvContent += "\r\n" + escapeCsv("customer_city") + "," + escapeCsv(this.customerCity || "");
      csvContent += "\r\n" + escapeCsv("customer_state") + "," + escapeCsv(this.customerState || "");
      csvContent += "\r\n" + escapeCsv("customer_zip") + "," + escapeCsv(this.customerZip || "");
      csvContent += "\r\n" + escapeCsv("latitude") + "," + escapeCsv(this.latitude || "");
      csvContent += "\r\n" + escapeCsv("longitude") + "," + escapeCsv(this.longitude || "");
      csvContent += "\r\n" + escapeCsv("gps_coordinates") + "," + escapeCsv(this.gpsCoordinates || "");
      
      // Asset fields
      csvContent += "\r\n" + escapeCsv("asset_number") + "," + escapeCsv(this.assetNumber || "");
      csvContent += "\r\n" + escapeCsv("feeder") + "," + escapeCsv(this.feeder || "");
      csvContent += "\r\n" + escapeCsv("voltage_level") + "," + escapeCsv(this.voltageLevel || "");
      csvContent += "\r\n" + escapeCsv("nav_wip") + "," + escapeCsv(this.navWip || "");
      csvContent += "\r\n" + escapeCsv("nav_build_job_number") + "," + escapeCsv(this.navBuildJobNumber || "");
      
      // Submission metadata
      csvContent += "\r\n" + escapeCsv("resource_id") + "," + escapeCsv(this.resourceId || "");
      csvContent += "\r\n" + escapeCsv("submission_timestamp") + "," + escapeCsv(new Date().toISOString());
      csvContent += "\r\n" + escapeCsv("completed_by") + "," + escapeCsv(this.completedBy || "");
      csvContent += "\r\n" + escapeCsv("completed_by_login") + "," + escapeCsv(this.completedByLogin || "");
      return csvContent;
    };

    this.handleFormSubmitFromIframe = function (data) {
      var formId = data.formId || data.formTitle || "form_" + Date.now();
      var formTitle = data.formTitle || formId;
      var formData = Array.isArray(data.formData) ? data.formData : [];
      var closeAfterSubmit = !!data.closeAfterSubmit;
      this.formSubmissions.set(formId, { formTitle: formTitle, formData: formData });
      var fileName = this.getScmAttachmentFileName(this.currentActivity && this.currentActivity.aid, formTitle);
      var csvBlob = new Blob([this.buildSingleFormCsv(formTitle, formData)], { type: "text/csv;charset=utf-8" });
      var self = this;
      this.uploadAttachmentToOracleSCM(null, fileName, csvBlob).then(function () {
        var currentStatus = (self.currentActivity && self.currentActivity.xa_form_Status) ? String(self.currentActivity.xa_form_Status).trim() : "";
        var newStatus = currentStatus ? (currentStatus + "," + formId) : formId;
        self.sendPostMessageData({ apiVersion: 1, method: "update", activity: { aid: self.currentActivity.aid, xa_form_Status: newStatus } });
        if (self.currentActivity) self.currentActivity.xa_form_Status = newStatus;
        if (typeof window.markFormAsSubmitted === "function") window.markFormAsSubmitted(formId);
        var frame = document.getElementById && document.getElementById("content-frame");
        if (frame && frame.contentWindow) {
          try {
            frame.contentWindow.postMessage(JSON.stringify({ type: "MARK_FORM_SUBMITTED", formId: formId, formData: formData }), "*");
          } catch (e) {}
        }
        if (closeAfterSubmit) {
          self.sendPostMessageData({ apiVersion: 1, method: "close" });
        } else {
          window.alert('Form "' + formTitle + '" uploaded successfully.');
        }
      }).catch(function (err) {
        console.error(self.tag + " SCM upload error>>", err);
        window.alert("Attachment upload to Oracle SCM failed: " + (err.message || err));
      });
    };

    this.sendPostMessageData = function (data) {
      console.error(this.tag + " Sent>>", JSON.stringify(data, undefined, "\t"));
      parent.postMessage(JSON.stringify(data), this.getOrigin(document.referrer));
    };
    this.generateCallId = function () {
      return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
    };
    this.getJWTTokens = function () {
      var jwtToken = window.localStorage.getItem(this.tag + "_applictaion");
      if (jwtToken) {
        jwtToken = JSON.parse(jwtToken);
        this.jwtCallerId = this.generateCallId();
        for (var key in jwtToken) {
          if (jwtToken[key].type === "ofs") {
            this.sendPostMessageData({ apiVersion: 1, method: "callProcedure", callId: this.jwtCallerId, procedure: "getAccessToken", params: { applicationKey: key } });
            break;
          }
        }
      }
    };

    this._messageListener = function (event) {
      var data = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
      if (!data) return;
      if (data.type === "FORM_SUBMIT") { this.handleFormSubmitFromIframe(data); return; }
      if (data.type === "SUBMIT_AND_CLOSE_DONE" || data.type === "CLOSE_PLUGIN") {
        this.sendPostMessageData({ apiVersion: 1, method: "close" });
        return;
      }
      console.error(this.tag + " Received>>", JSON.stringify(data, undefined, "\t"));
      switch (data.method) {
        case "init":
          window.localStorage.setItem(this.tag + "_applictaion", JSON.stringify(data.applications));
          this.sendPostMessageData({ apiVersion: 1, method: "initEnd" });
          break;
        case "open":
          this.getJWTTokens();
          this.open(data);
          break;
        case "callProcedureResult":
          if (data.callId === this.jwtCallerId) this.jwtToken = data.resultData.token;
          break;
        case "updateResult": break;
        case "error":
          confirm(JSON.stringify(data.error));
          break;
        case "close":
          this.sendPostMessageData({ apiVersion: 1, method: "close" });
          break;
      }
    };
  };

  window.addEventListener("load", function () {
    var plugin = new OfscPlugin();
    plugin.init("HSL Plugin");
    window.ofscPlugin = plugin;
  });
})();
