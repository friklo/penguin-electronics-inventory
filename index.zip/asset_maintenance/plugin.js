/**

 *
 * This script defines a plugin for the Oracle Field Service Cloud (OFSC) application.
 * It initializes the plugin, handles messages, and populates discrepancy reason attributes.
 *
 * Functions:
 * - init: Initializes the plugin and sets up the message listener.
 * - getOrigin: Extracts the origin from a given URL.
 * - getMetaAttributes: Parses and populates discrepancy reason attributes from provided data.
 * - generateCallId: Generates a unique call ID.
 * - searchPart: Searches for parts catalog structures.
 * - countrylist: Fetches and populates the country list.
 * - open: Initializes the plugin UI.
 * - sendPostMessageData: Sends data to the parent window.
 * - _messageListener: Handles messages from the parent window.
 * @version 0.1.0
 * @since 0.1.0
 * @param {void}
 * @returns {void}
 * @throws {Error} - If there is an error
 *
 */

"use strict";
(function () {
  window.OfscPlugin = function () {
    this.jwtCallerId = "";
    this.jwtToken;
    this.geolocationCoordinates = "";
    this.init = function (pluginName) {
      this.tag = pluginName;
      window.addEventListener("message", this._messageListener.bind(this), false);
      this.sendPostMessageData({
        apiVersion: 1,
        method: "ready",
        sendInitData: true,
        showHeader: true,
        enableBackButton: true,
      });
    };
    this.getOrigin = function (url) {
      if (url != "") {
        if (url.indexOf("://") > -1) {
          return "https://" + url.split("/")[2];
        } else {
          return "https://" + url.split("/")[0];
        }
      }
      return "";
    };

    // Sample code for populating dropdwon using Metadata
    this.getMetaAttributes = function (data) {
      if (data) {
        const json = JSON.parse(data);
        this.XA_DISCREPANCY_REASON_ATTRIBUTES = json["XA_DISCREPANCY_REASON_ATTRIBUTES"]["enum"];

        const reason_code = document.getElementById("reason_code");
        for (const [key, value] of Object.entries(this.XA_DISCREPANCY_REASON_ATTRIBUTES)) {
          const option = document.createElement("option");
          option.value = key;
          option.text = value.text;
          reason_code.appendChild(option);
        }
      }
    };

    this.searchPart = function () {
      this.sendPostMessageData({
        apiVersion: 1,
        callId: this.generateCallId(),
        method: "callProcedure",
        procedure: "getPartsCatalogsStructure",
      });
    };

    // External API in plugin
    this.countrylist = function (url, userId, passworf) {
      fetch(url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })
        .then((response) => response.json())
        .then((data) => {
          const country = document.getElementById("country");
          for (const [key, value] of Object.entries(data)) {
            const option = document.createElement("option");
            option.value = key;
            option.text = value.name.official;
            country.appendChild(option);
          }
        });
    };

    this.getGeoLocation = function () {
      return new Promise(function (resolve, reject) {
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            const crd = pos.coords;
            console.error("Coordinates>>", crd.latitude + "," + crd.longitude);

            resolve(crd.latitude + "," + crd.longitude);
          },
          (error) => {
            console.error("Error", error);
            reject(error);
          }
        );
      });
    };

    this.open = function (data) {
      let activity = data.activity;
      let securedData = data.securedData;
      this.currentActivity = activity;
      this.formSubmissions = new Map();
      // Oracle SCM attachment API config: use secured data or hardcoded defaults (Basic auth)
      var scmFromData = (securedData && securedData.scm) ? securedData.scm : (data.scm || {});
      this.scmConfig = (scmFromData && scmFromData.baseUrl) ? scmFromData : {
        baseUrl: "https://iaawnf-dev1.fa.ocs.oraclecloud.com",
        categoryName: "MISC",
        auth: {
          type: "basic",
          username: "paras.d.jain@capgemini.com",
          password: "namespace@123",
        },
      };

      // Merged plugin: route by activity.aworktype to work-type-specific iframe
      if (typeof window.showWorkTypeContent === "function") {
        window.showWorkTypeContent(activity.aworktype, activity);
        return;
      }

      // Apply xa_form_Status: grey out and disable forms already submitted
      if (typeof window.applySubmittedFormsStatus === "function") {
        window.applySubmittedFormsStatus(activity.xa_form_Status || "");
      }

      const submit = document.getElementById("SubmitBtnId");
      if (!!submit) {
        submit.addEventListener("click", async () => {
         // this.geolocationCoordinates = await this.getGeoLocation();
         // alert("Exact Location>>" + this.geolocationCoordinates);
          // collect all form elements with a name and build a payload of their values
          const fields = {};
          const elements = Array.from(document.querySelectorAll('input[name], textarea[name], select[name]'));
          elements.forEach((el) => {
            const name = el.name;
            if (!name) return;
            const tag = el.tagName.toLowerCase();
            if (tag === 'select') {
              if (el.multiple) {
                fields[name] = Array.from(el.selectedOptions).map((o) => o.value);
              } else {
                fields[name] = el.value;
              }
            } else if (el.type === 'checkbox') {
              const checkboxes = document.querySelectorAll(`input[type="checkbox"][name="${name}"]`);
              if (checkboxes.length > 1) {
                fields[name] = Array.from(checkboxes).filter(c => c.checked).map(c => c.value);
              } else {
                fields[name] = el.checked ? (el.value || true) : false;
              }
            } else if (el.type === 'radio') {
              const checked = document.querySelector(`input[type="radio"][name="${name}"]:checked`);
              fields[name] = checked ? checked.value : null;
            } else if (el.type === 'file') {
              fields[name] = el.files ? Array.from(el.files).map(f => f.name) : null;
            } else {
              fields[name] = el.value;
            }
          });

          // convert fields to CSV and attach as file (OFSC close with file property)
          const escapeCsv = (v) => {
            const s = String(v == null ? "" : Array.isArray(v) ? v.join("; ") : v);
            if (/[",\r\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
            return s;
          };
          const header = "Field,Value";
          const rows = Object.entries(fields).map(([k, v]) => escapeCsv(k) + "," + escapeCsv(v));
          const csv = "\uFEFF" + header + "\r\n" + rows.join("\r\n");
          const csvBlob = new Blob([csv], { type: "text/csv;charset=utf-8" });

          const closePayload = {
            apiVersion: 1,
            method: "close",
            activity: {
              aid: activity.aid,
              wo_attachment: { fileName: "form_data.csv", fileContents: csvBlob },
            },
          };
          console.error(`${this.tag} Sent>>`, "(close with CSV file)");
          parent.postMessage(closePayload, this.getOrigin(document.referrer));
        });
      }

      // cancel Button
      const CancelBtnId = document.getElementById("CancelBtnId");
      if (!!CancelBtnId) {
        CancelBtnId.addEventListener("click", () => {
          this.sendPostMessageData({
            apiVersion: 1,
            method: "close",
          });
        });
      }

      // Open --end
    };

    this.sanitizeFileName = function (name) {
      return String(name || "form")
        .replace(/[<>:"/\\|?*\x00-\x1f]/g, "")
        .replace(/\s+/g, "_")
        .trim() || "form";
    };

    /** Convert Blob to base64 string for Oracle SCM FileContents */
    this.blobToBase64 = function (blob) {
      return new Promise(function (resolve, reject) {
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = reader.result;
          const base64Data = typeof base64 === "string" && base64.indexOf(",") >= 0
            ? base64.split(",")[1] : base64;
          resolve(base64Data || "");
        };
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    };

    /**
     * Upload attachment to Oracle SCM Maintenance Work Order Attachments API.
     * Requires this.scmConfig: { baseUrl, workOrderId, auth }
     * auth: { type: 'basic', username, password } | { type: 'bearer'|'jwt', token }
     * Oracle SCM JWT expected shape: header {"x5t":"...","kid":"trustservice","typ":"JWT","alg":"RS256"},
     * payload {"sub":"user@domain","iss":"www.oracle.com","exp":...,"prn":"user@domain","iat":...}
     * @see https://docs.oracle.com/en/cloud/saas/supply-chain-and-manufacturing/25b/fasrp/op-maintenanceworkorders-workorderid-child-attachments-post.html
     */
    this.uploadAttachmentToOracleSCM = function (workOrderId, fileName, fileBlob) {
      const scm = this.scmConfig;
      if (!scm || !scm.baseUrl) {
        return Promise.reject(new Error("Oracle SCM config missing: baseUrl required"));
      }
      const activity = this.currentActivity;
      const woId = workOrderId != null ? workOrderId : (scm.workOrderId || (activity && (activity.mwo_workorder_id != null ? activity.mwo_workorder_id : activity.workOrderId)));
      if (woId == null) {
        return Promise.reject(new Error("Work order ID required for SCM attachment (set scm.workOrderId or activity.mwo_workorder_id)"));
      }
      const url = scm.baseUrl.replace(/\/$/, "") + "/fscmRestApi/resources/11.13.18.05/maintenanceWorkOrders/" + woId + "/child/attachments";
      const headers = { "Content-Type": "application/json" };
      if (scm.auth) {
        if (scm.auth.type === "basic" && scm.auth.username != null) {
          headers["Authorization"] = "Basic " + btoa((scm.auth.username || "") + ":" + (scm.auth.password || ""));
        } else if ((scm.auth.type === "bearer" || scm.auth.type === "jwt") && scm.auth.token) {
          headers["Authorization"] = "Bearer " + scm.auth.token;
        }
      }
      return this.blobToBase64(fileBlob).then((base64Contents) => {
        const body = {
          DatatypeCode: "FILE",
          CategoryName: (scm.categoryName != null) ? scm.categoryName : "MISC",
          Title: fileName,
          Description: "Uploaded via OFSC plugin",
          FileContents: base64Contents,
        };
        return fetch(url, { method: "POST", headers: headers, body: JSON.stringify(body) });
      }).then((response) => {
        if (!response.ok) {
          return response.text().then((t) => { throw new Error("SCM attachment upload failed: " + response.status + " " + response.statusText + " " + t); });
        }
        return response.json();
      });
    };

    /** Same auth headers used for GET (attachments list, enclosure). */
    this.getScmAuthHeaders = function () {
      var scm = this.scmConfig;
      if (!scm || !scm.auth) return {};
      if (scm.auth.type === "basic" && scm.auth.username != null) {
        return { Authorization: "Basic " + btoa((scm.auth.username || "") + ":" + (scm.auth.password || "")) };
      }
      if ((scm.auth.type === "bearer" || scm.auth.type === "jwt") && scm.auth.token) {
        return { Authorization: "Bearer " + scm.auth.token };
      }
      return {};
    };

    /**
     * GET all attachments for a work order.
     * @see https://docs.oracle.com/en/cloud/saas/supply-chain-and-manufacturing/26a/fasrp/op-maintenanceworkorders-workorderid-child-attachments-get.html
     */
    this.getAttachmentsList = function (workOrderId) {
      var scm = this.scmConfig;
      if (!scm || !scm.baseUrl) return Promise.reject(new Error("Oracle SCM config missing"));
      var woId = workOrderId != null ? workOrderId : (scm.workOrderId || (this.currentActivity && (this.currentActivity.mwo_workorder_id != null ? this.currentActivity.mwo_workorder_id : this.currentActivity.workOrderId)));
      if (woId == null) return Promise.reject(new Error("Work order ID required"));
      var url = scm.baseUrl.replace(/\/$/, "") + "/fscmRestApi/resources/11.13.18.05/maintenanceWorkOrders/" + woId + "/child/attachments";
      return fetch(url, { method: "GET", headers: this.getScmAuthHeaders() }).then(function (res) {
        if (!res.ok) return res.text().then(function (t) { throw new Error("Get attachments failed: " + res.status + " " + t); });
        return res.json();
      });
    };

    /** GET attachment file contents from enclosure URL (rel=enclosure, name=FileContents). */
    this.getAttachmentFileContents = function (enclosureUrl) {
      return fetch(enclosureUrl, { method: "GET", headers: this.getScmAuthHeaders() }).then(function (res) {
        if (!res.ok) return res.text().then(function (t) { throw new Error("Get file contents failed: " + res.status + " " + t); });
        var ct = (res.headers.get("Content-Type") || "").toLowerCase();
        if (ct.indexOf("application/json") >= 0) return res.json();
        return res.text();
      });
    };

    /** Parse CSV text (header Field,Value) into array of { fieldName, value }. Handles quoted fields. Accepts string or JSON with FileContents (base64 or string). */
    this.parseCsvToFormData = function (csvText) {
      var raw = csvText;
      if (raw != null && typeof raw === "object") {
        if (typeof raw.FileContents === "string") {
          raw = raw.FileContents;
          try {
            if (/^[A-Za-z0-9+/=]+$/.test(raw)) raw = decodeURIComponent(escape(atob(raw)));
          } catch (e) { /* use as plain string */ }
        } else {
          raw = JSON.stringify(raw);
        }
      }
      var str = (raw != null && typeof raw !== "string") ? String(raw) : (raw || "");
      var lines = str.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n").filter(Boolean);
      if (lines.length < 2) return [];
      var out = [];
      for (var i = 1; i < lines.length; i++) {
        var line = lines[i];
        var idx = 0;
        function parseField() {
          if (idx >= line.length) return "";
          if (line[idx] === '"') {
            idx++;
            var s = "";
            while (idx < line.length && (line[idx] !== '"' || line[idx + 1] === '"')) {
              s += line[idx] === '"' && line[idx + 1] === '"' ? '"' : line[idx];
              idx += line[idx] === '"' && line[idx + 1] === '"' ? 2 : 1;
            }
            if (line[idx] === '"') idx++;
            if (line[idx] === ",") idx++;
            return s;
          }
          var comma = line.indexOf(",", idx);
          if (comma < 0) { var r = line.substring(idx).trim(); idx = line.length; return r; }
          var r = line.substring(idx, comma).trim();
          idx = comma + 1;
          return r;
        }
        var fieldName = parseField();
        var value = idx < line.length ? parseField() : "";
        out.push({ fieldName: fieldName, value: value });
      }
      return out;
    };

    /**
     * Determine which forms have a submitted attachment by listing SCM attachments and matching by file name (aid_formTitle.csv).
     * @param {Object} activity - activity with aid (used for expected file name)
     * @param {Array<{formId: string, formTitle: string}>} formEntries - list of { formId, formTitle }
     * @returns {Promise<string[]>} formIds that have a matching attachment
     */
    this.getSubmittedFormIdsFromAttachments = function (activity, formEntries) {
      var self = this;
      var aid = activity && activity.aid;
      if (!formEntries || !formEntries.length) return Promise.resolve([]);
      return this.getAttachmentsList(null).then(function (body) {
        var items = (body && body.items) ? body.items : [];
        var titlesLower = items.map(function (it) { return ((it.Title || it.FileName || "").toLowerCase()); });
        return formEntries.filter(function (entry) {
          var expected = (self.getScmAttachmentFileName(aid, entry.formTitle) || "").toLowerCase();
          return titlesLower.indexOf(expected) >= 0;
        }).map(function (entry) { return entry.formId; });
      }).catch(function (err) {
        console.error(self.tag + " getSubmittedFormIdsFromAttachments error>>", err);
        return [];
      });
    };

    /**
     * Fetch submitted form data from SCM: get attachments, find by Title (aid_formTitle.csv), get FileContents enclosure, parse CSV, return formData for FORM_PREFILL.
     */
    this.fetchSubmittedFormData = function (formId, formTitle) {
      var self = this;
      var activity = this.currentActivity;
      var aid = activity && activity.aid;
      var expectedTitle = this.getScmAttachmentFileName(aid, formTitle);
      return this.getAttachmentsList(null).then(function (body) {
        var items = (body && body.items) ? body.items : [];
        var expectedLower = (expectedTitle || "").toLowerCase();
        var item = items.filter(function (it) {
          var t = (it.Title || it.FileName || "").toLowerCase();
          return t === expectedLower;
        })[0];
        if (!item || !item.links) return [];
        var enclosure = item.links.filter(function (l) { return l.rel === "enclosure" && (l.name || "") === "FileContents"; })[0];
        if (!enclosure || !enclosure.href) return [];
        return self.getAttachmentFileContents(enclosure.href);
      }).then(function (csvText) {
        return self.parseCsvToFormData(csvText);
      }).catch(function (err) {
        console.error(self.tag + " fetchSubmittedFormData error>>", err);
        return [];
      });
    };

    this.getActiveFormIds = function () {
      const tabs = document.querySelectorAll("#tabsList .tab");
      return Array.from(tabs).map((t) => t.id.replace("tab-", ""));
    };

    /** Unique SCM attachment file name: activity id + form title (so we can find it when loading submitted form). */
    this.getScmAttachmentFileName = function (aid, formTitle) {
      var base = (aid != null ? String(aid) : "") + "_" + this.sanitizeFileName(formTitle || "form");
      return base + ".csv";
    };

    /** Build CSV for a single form (used for per-form upload; file name = form name). */
    this.buildSingleFormCsv = function (formTitle, formData) {
      const escapeCsv = (v) => {
        const s = String(v == null ? "" : (Array.isArray(v) ? v.join("; ") : v));
        if (/[",\r\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
        return s;
      };
      const rows = Array.isArray(formData) ? formData : [];
      const header = "\uFEFFField,Value";
      const lines = [header].concat(rows.map((row) => escapeCsv(row.fieldId || row.fieldName || "") + "," + escapeCsv(row.value)));
      return lines.join("\r\n");
    };

    this.handleFormSubmitFromIframe = function (data) {
      const formId = data.formId || data.formTitle || "form_" + Date.now();
      const formTitle = data.formTitle || formId;
      const formData = Array.isArray(data.formData) ? data.formData : [];
      const submitAndClose = !!data.submitAndClose || !!window._submitAndClosePending;

      this.formSubmissions.set(formId, { formTitle: formTitle, formData: formData });

      var fileName = this.getScmAttachmentFileName(this.currentActivity && this.currentActivity.aid, formTitle);
      var csv = this.buildSingleFormCsv(formTitle, formData);
      var csvBlob = new Blob([csv], { type: "text/csv;charset=utf-8" });
      var self = this;

      this.uploadAttachmentToOracleSCM(null, fileName, csvBlob)
        .then(() => {
          console.error(`${self.tag} SCM upload OK>>`, fileName);
          var currentStatus = (self.currentActivity && self.currentActivity.xa_form_Status) ? String(self.currentActivity.xa_form_Status).trim() : "";
          var newStatus = currentStatus ? (currentStatus + "," + formId) : formId;
          self.sendPostMessageData({
            apiVersion: 1,
            method: "update",
            activity: {
              aid: self.currentActivity.aid,
              xa_form_Status: newStatus,
            },
          });
          if (self.currentActivity) self.currentActivity.xa_form_Status = newStatus;
          if (typeof window.markFormAsSubmitted === "function") window.markFormAsSubmitted(formId);
          if (submitAndClose) {
            window._submitAndClosePending = false;
            try { window.parent.postMessage(JSON.stringify({ type: "CLOSE_PLUGIN" }), "*"); } catch (err) {}
          } else {
            window.alert('Form "' + formTitle + '" uploaded successfully.');
          }
        })
        .catch((err) => {
          console.error(`${this.tag} SCM upload error>>`, err);
          window.alert("Attachment upload to Oracle SCM failed: " + (err.message || err));
        });
    };

    this.getLoginDetails = function () {
      let url = "/rest/ofscCore/v1/users/admin?fields=login";
      fetch(url, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.jwtToken}`,
        },
      })
        .then((response) => response.json())
        .then((data) => {
          console.error("User Details>>", data);
        });
    };

    this.sendPostMessageData = function (data) {
      console.error(`${this.tag} Sent>>`, JSON.stringify(data, undefined, "\t"));
      parent.postMessage(JSON.stringify(data), this.getOrigin(document.referrer));
    };
    this.generateCallId = function () {
      return btoa(String.fromCharCode.apply(null, window.crypto.getRandomValues(new Uint8Array(16))));
    };

    this.getJWTTokens = function () {
      //{
      // "KEY": {
      // "type": "ofs",
      // "resourceUrl": "https://*** */.test.fs.ocs.oraclecloud.com"
      // }
      // }}
      let jwtToken = window.localStorage.getItem(`${this.tag}_applictaion`);
      if (jwtToken) {
        jwtToken = JSON.parse(jwtToken);
        this.jwtCallerId = this.generateCallId();
        for (let key in jwtToken) {
          let value = jwtToken[key];
          if (value.type === "ofs") {
            this.sendPostMessageData({
              apiVersion: 1,
              method: "callProcedure",
              callId: this.jwtCallerId,
              procedure: "getAccessToken",
              params: {
                applicationKey: key,
              },
            });
          }
        }
      }
    };

    // Data recieved from OFSC to Plugin or from iframe (FORM_SUBMIT)
    this._messageListener = function (event) {
      const data = typeof event.data === "string" ? JSON.parse(event.data) : event.data;
      if (!data) return;
      if (data.type === "FORM_SUBMIT") {
        this.handleFormSubmitFromIframe(data);
        return;
      }
      console.error(`${this.tag} Received>>`, JSON.stringify(data, undefined, "\t"));
      switch (data.method) {
        case "init":
          window.localStorage.setItem(`${this.tag}_applictaion`, JSON.stringify(data.applications));
          this.sendPostMessageData({
            apiVersion: 1,
            method: "initEnd",
          });
          break;
        case "open":
          this.getJWTTokens();
          this.open(data);
          break;
        case "callProcedureResult":
          let callId = data.callId;
          if (callId === this.jwtCallerId) {
            this.jwtToken = data.resultData.token;
            console.error("JWT Token>>", this.jwtToken);
          }
          break;
        case "updateResult":
          break;
        case "error":
          confirm(JSON.stringify(data.error));
          break;
        case "close":
          this.sendPostMessageData({
            apiVersion: 1,
            method: "close",
          });
          break;
      }
    };
  };

  window.addEventListener("load", function () {
    console.error("Plugin is loading");
    const plugin = new OfscPlugin();
    plugin.init("Demo Plugin");
    window.ofscPlugin = plugin;
  });
})();

