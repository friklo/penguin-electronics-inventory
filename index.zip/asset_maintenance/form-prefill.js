/**
 * Listens for FORM_PREFILL and ACTIVITY_PREFILL messages from parent and fills form fields by name.
 * ACTIVITY_PREFILL: Prefills from activity/asset data (editable)
 * FORM_PREFILL: Prefills from previously submitted form (read-only)
 * When readOnly is true, disables all inputs and submit so the form is view-only.
 */
(function() {
  /**
   * Fill form fields with provided data
   * @param {Array} formData - Array of {fieldName, value} objects
   * @param {boolean} overwriteExisting - If false, only fill empty fields
   */
  function fillFormWithData(formData, overwriteExisting) {
    if (!formData || !Array.isArray(formData)) return;
    formData.forEach(function(row) {
      var name = row.fieldName || row.fieldId;
      if (!name) return;
      var els = document.querySelectorAll('[name="' + name + '"], [id="' + name + '"]');
      if (els.length === 0) return;
      var value = row.value;
      if (value === null || value === undefined || value === '') return;
      
      els.forEach(function(el) {
        var type = (el.type || '').toLowerCase();
        var tag = (el.tagName || '').toLowerCase();
        
        // Skip if field already has value and we don't want to overwrite
        if (!overwriteExisting) {
          if (type === 'checkbox' || type === 'radio') {
            // For checkboxes/radios, check if any in the group is checked
            var groupName = el.name;
            if (groupName) {
              var anyChecked = document.querySelector('[name="' + groupName + '"]:checked');
              if (anyChecked) return;
            }
          } else if (el.value && el.value.trim() !== '') {
            return;
          }
        }
        
        if (type === 'checkbox') {
          el.checked = value === true || value === 'true' || value === '1' || String(value).toLowerCase() === 'yes';
        } else if (type === 'radio') {
          if (String(el.value).toLowerCase() === String(value).toLowerCase()) el.checked = true;
        } else if (tag === 'select') {
          // For select, try to match option value (case-insensitive)
          var options = el.options;
          var valueLower = String(value).toLowerCase();
          for (var i = 0; i < options.length; i++) {
            if (options[i].value.toLowerCase() === valueLower || options[i].text.toLowerCase() === valueLower) {
              el.selectedIndex = i;
              break;
            }
          }
        } else if (type === 'date') {
          // Ensure date is in YYYY-MM-DD format
          var dateVal = String(value);
          if (dateVal.indexOf('T') > 0) dateVal = dateVal.split('T')[0];
          el.value = dateVal;
        } else {
          el.value = value != null ? String(value) : '';
        }
        
        // Trigger change event for toggle controls
        if (el.classList.contains('toggle-control')) {
          try { el.dispatchEvent(new Event('change', { bubbles: true })); } catch (e) {}
        }
      });
    });
  }

  function isGpsFieldName(name) {
    if (!name) return false;
    var lower = String(name).toLowerCase();
    return lower === 'latitude' ||
      lower === 'lat' ||
      lower === 'longitude' ||
      lower === 'lng' ||
      lower === 'lon' ||
      lower === 'gps_location' ||
      lower === 'gps_coordinates' ||
      lower === 'xa_ws_dc_1' ||
      lower === 'xa_ws_gps_location' ||
      lower === 'xa_ws_etfaat_5';
  }

  function lockGpsFields() {
    document.querySelectorAll('input[name], textarea[name], input[id], textarea[id]').forEach(function(el) {
      var name = el.name || el.id;
      if (!isGpsFieldName(name)) return;
      el.readOnly = true;
      el.setAttribute('aria-readonly', 'true');
      el.classList.add('gps-readonly');
    });
  }
  
  function setFormReadOnly(readOnly) {
    if (!readOnly) return;
    var style = document.createElement('style');
    style.textContent = 'input:disabled, select:disabled, textarea:disabled { background-color: #e9e9e9 !important; color: #555 !important; cursor: not-allowed; }';
    document.head.appendChild(style);
    document.querySelectorAll('input, select, textarea, button').forEach(function(el) {
      var tag = (el.tagName || '').toLowerCase();
      if (tag === 'button' && (el.type || '').toLowerCase() === 'submit') {
        el.disabled = true;
        el.style.opacity = '0.6';
      } else if (tag !== 'button') {
        el.readOnly = true;
        el.disabled = true;
      }
    });
  }
  
  window.addEventListener('message', function(event) {
    var raw = event.data;
    var data = typeof raw === 'string' ? (function() { try { return JSON.parse(raw); } catch (x) { return null; } })() : raw;
    if (!data) return;
    
    // ACTIVITY_PREFILL: Prefill from activity/asset data (editable, don't overwrite existing values)
    if (data.type === 'ACTIVITY_PREFILL' || data.type === 'OPEN_DATA') {
      var prefillData = data.prefillData || data.formData;
      if (Array.isArray(prefillData) && prefillData.length > 0) {
        var shouldOverwrite = data.overwriteExisting === true;
        // Delay slightly to ensure form is fully rendered
        setTimeout(function() {
          fillFormWithData(prefillData, shouldOverwrite);
          lockGpsFields();
        }, 100);
      }
    }
    
    // FORM_PREFILL: Prefill from previously submitted form (read-only, overwrite all)
    if (data.type === 'FORM_PREFILL' || data.type === 'MARK_FORM_SUBMITTED') {
      var formData = data.formData;
      if (Array.isArray(formData)) fillFormWithData(formData, true);
      lockGpsFields();
      if (data.readOnly !== false) setFormReadOnly(true);
    }
  });
})();
