(function () {
  "use strict";

  function esc(value) {
    return String(value == null ? "" : value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  /**
   * ITEM.ILEVEL-style nesting (1 = top, 2+ = indented under parent flow).
   */
  function fieldLevelMarkup(field) {
    var raw = field.level;
    var ilevel = raw != null && raw !== "" ? parseInt(String(raw), 10) : 1;
    if (isNaN(ilevel) || ilevel < 1) ilevel = 1;
    if (ilevel > 12) ilevel = 12;
    var dataAttr = ' data-field-level="' + ilevel + '"';
    if (ilevel <= 1) {
      return { dataAttr: dataAttr, extraClass: "", boxStyle: "" };
    }
    var rem = (ilevel - 1) * 0.75;
    var boxStyle =
      ' style="margin-left:' + rem + 'rem;padding-left:0.5rem;border-left:3px solid #ced4da;border-radius:0.15rem"';
    return { dataAttr: dataAttr, extraClass: " field-ilevel-nested", boxStyle: boxStyle };
  }

  /**
   * Map OFSC/store values to YES/NO/NA: bare strings, equivalents (YES-101), Excel 0/1, booleans.
   */
  function coerceYesNoNa(stored) {
    if (stored === true) return "YES";
    if (stored === false) return "NO";
    if (typeof stored === "number" && stored === stored && (stored === 0 || stored === 1))
      return stored === 1 ? "YES" : "NO";

    var s = String(stored == null ? "" : stored).trim();
    if (!s) return null;
    var su = s.toUpperCase();
    if (su === "N/A") return "NA";

    function fromPrefix(word) {
      if (su === word) return word;
      if (su.indexOf(word) !== 0) return null;
      if (su.length === word.length) return word;
      var next = su.charAt(word.length);
      if (next === "-" || next === "_" || next === " " || (next >= "0" && next <= "9")) return word;
      return null;
    }

    var w = fromPrefix("YES");
    if (w) return "YES";
    w = fromPrefix("NO");
    if (w) return "NO";
    w = fromPrefix("NA");
    if (w) return "NA";
    if (su === "TRUE" || su === "1" || su === "Y") return "YES";
    if (su === "FALSE" || su === "0") return "NO";
    return null;
  }

  /** Rule option matches stored value (strict for normal options; YES/NO/NA use coercion). */
  function storedChoiceMatchesOption(stored, option) {
    var oCanon = coerceYesNoNa(option);
    var sCanon = coerceYesNoNa(stored);
    if (oCanon != null && sCanon != null) return oCanon === sCanon;

    var s = String(stored == null ? "" : stored).trim();
    var o = String(option == null ? "" : option).trim();
    if (!o || !s) return false;
    if (s === o) return true;
    return s.toUpperCase() === o.toUpperCase();
  }

  function renderField(formId, field, value) {
    var id = "f_" + formId + "_" + field.id;
    var label = field.label || field.id;
    var lvlMk = fieldLevelMarkup(field);
    var required = field.required ? '<span class="text-danger">*</span>' : "";
    var help = field.help ? '<div class="field-help mt-1">' + esc(field.help) + "</div>" : "";
    var v = value == null ? "" : value;
    var showIfAttr = field.showIf ? " data-show-if='" + JSON.stringify(field.showIf).replace(/'/g, "&apos;") + "'" : "";
    var parentFieldAttr = "";
    if (field.showIf && field.showIf.length === 1 && field.showIf[0] && field.showIf[0].field) {
      parentFieldAttr = ' data-parent-field="' + esc(field.showIf[0].field) + '"';
    }
    var reqAttr = field.required ? ' data-required="true"' : "";
    var fid = String(field.id || "");
    var flabel = String(field.label || "").toLowerCase();
    var isGpsField =
      fid === "gps_location" ||
      fid === "xa_ws_gps_location" ||
      fid === "gps_coordinates" ||
      fid === "xa_ws_dc_1" ||
      fid.toLowerCase().indexOf("gps") >= 0 ||
      flabel.indexOf("gps") >= 0;
    var roAttr = (field.readonly || isGpsField) ? ' readonly="readonly"' : "";
    var isCommentField = /(?:^comm_\d+$|_comm(?:ents)?(?:_\d+)?$|comments?$)/i.test(fid);
    var isStatusField = /(?:^cond_\d+$|^status_\d+$|_status(?:_\d+)?$|_cond(?:_\d+)?$|_result(?:_\d+)?$)/i.test(fid);
    var wrapClass = "mb-3";
    if (isCommentField) wrapClass += " field-comment";
    if (isStatusField) wrapClass += " field-status";
    if (lvlMk.extraClass) wrapClass += lvlMk.extraClass;

    var wrapOpenCore =
      'data-field-wrap="' +
      esc(field.id) +
      '"' +
      lvlMk.dataAttr +
      showIfAttr +
      parentFieldAttr +
      reqAttr +
      lvlMk.boxStyle;

    if (field.type === "textarea") {
      return '' +
        '<div class="' + wrapClass + '" ' + wrapOpenCore + ">" +
        '<label class="form-label" for="' + id + '">' + esc(label) + " " + required + "</label>" +
        '<textarea class="form-control" id="' + id + '" data-field-id="' + field.id + '" rows="' + (field.rows || 3) + '"' + roAttr + '>' + esc(v) + "</textarea>" +
        help +
        "</div>";
    }

    if (field.type === "select") {
      var isMulti = !!field.multiple;
      var selectedValues = Array.isArray(v) ? v.map(String) : (v == null || v === "" ? [] : [String(v)]);
      var emptySelected = selectedValues.length === 0 ? " selected" : "";
      var placeholder = isMulti ? "" : ('<option value=""' + emptySelected + ">Select...</option>");
      var opts = (field.options || []).map(function (opt) {
        var ov = typeof opt === "string" ? opt : opt.value;
        var ol = typeof opt === "string" ? opt : (opt.label || opt.value);
        var selected =
          selectedValues.some(function (sv) {
            return storedChoiceMatchesOption(sv, ov);
          })
            ? " selected"
            : "";
        return '<option value="' + esc(ov) + '"' + selected + ">" + esc(ol) + "</option>";
      }).join("");
      var multipleAttr = isMulti ? " multiple" : "";
      return '' +
        '<div class="' + wrapClass + '" ' + wrapOpenCore + ">" +
        '<label class="form-label" for="' + id + '">' + esc(label) + " " + required + "</label>" +
        '<select class="form-select" id="' + id + '" data-field-id="' + field.id + '"' + multipleAttr + '>' + placeholder + opts + "</select>" +
        help +
        "</div>";
    }

    if (field.type === "radio") {
      var radios = (field.options || []).map(function (opt, idx) {
        var ov = typeof opt === "string" ? opt : opt.value;
        var ol = typeof opt === "string" ? opt : (opt.label || opt.value);
        var rid = id + "_" + idx;
        var checked = storedChoiceMatchesOption(v, ov) ? " checked" : "";
        return (
          '<div class="form-check form-check-inline">' +
          '<input class="form-check-input" type="radio" name="' + id + '_group" id="' + rid + '" data-field-id="' + field.id + '" value="' + esc(ov) + '"' + checked + ">" +
          '<label class="form-check-label" for="' + rid + '">' + esc(ol) + "</label>" +
          "</div>"
        );
      }).join("");
      return '' +
        '<div class="' + wrapClass + '" ' + wrapOpenCore + ">" +
        '<div class="form-label mb-1">' + esc(label) + " " + required + "</div>" +
        radios +
        help +
        "</div>";
    }

    if (field.type === "checkbox") {
      var checked = v ? " checked" : "";
      return '' +
        '<div class="' + wrapClass + ' form-check" ' + wrapOpenCore + ">" +
        '<input class="form-check-input" type="checkbox" id="' + id + '" data-field-id="' + field.id + '"' + checked + ">" +
        '<label class="form-check-label" for="' + id + '">' + esc(label) + " " + required + "</label>" +
        help +
        "</div>";
    }

    var minAttr = field.min != null ? ' min="' + esc(field.min) + '"' : "";
    var maxAttr = field.max != null ? ' max="' + esc(field.max) + '"' : "";
    var stepAttr = field.step != null ? ' step="' + esc(field.step) + '"' : "";
    return '' +
      '<div class="' + wrapClass + '" ' + wrapOpenCore + ">" +
      '<label class="form-label" for="' + id + '">' + esc(label) + " " + required + "</label>" +
      '<input class="form-control" type="' + (field.type || "text") + '" id="' + id + '" data-field-id="' + field.id + '" value="' + esc(v) + '"' + minAttr + maxAttr + stepAttr + roAttr + '>' +
      help +
      "</div>";
  }

  function renderForm(formConfig, formData) {
    var sections = (formConfig.sections || []).map(function (sec) {
      var fieldsHtml = (sec.fields || []).map(function (f) {
        return renderField(formConfig.id, f, formData ? formData[f.id] : "");
      }).join("");
      var secRaw = sec.level;
      var secLevel = secRaw != null && secRaw !== "" ? parseInt(String(secRaw), 10) : 1;
      if (isNaN(secLevel) || secLevel < 1) secLevel = 1;
      if (secLevel > 12) secLevel = 12;
      var secLevelAttr = ' data-section-level="' + secLevel + '"';
      var secStyle = "";
      if (secLevel > 1) {
        var srem = (secLevel - 1) * 0.6;
        secStyle =
          ' style="margin-left:' + srem + 'rem;padding-left:0.5rem;border-left:3px solid #dee2e6;border-radius:0.15rem"';
      }
      return '' +
        '<section class="mb-4"' + secLevelAttr + secStyle + ' data-form-section="true">' +
        '<h3 class="h6 border-bottom pb-2 mb-3">' + esc(sec.title || "Section") + "</h3>" +
        fieldsHtml +
        "</section>";
    }).join("");

    return '' +
      '<div class="card form-card mb-3">' +
      '<div class="card-body">' +
      '<h2 class="h5 mb-3">' + esc(formConfig.title) + "</h2>" +
      sections +
      "</div>" +
      "</div>";
  }

  function collectFormValues(formRoot) {
    var values = {};
    var radioKeys = {};

    formRoot.querySelectorAll("input[type=\"radio\"][data-field-id]").forEach(function (el) {
      radioKeys[el.getAttribute("data-field-id")] = true;
    });

    Object.keys(radioKeys).forEach(function (key) {
      var checked = formRoot.querySelector(
        'input[type="radio"][data-field-id="' + key.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"]:checked'
      );
      if (checked) values[key] = checked.value;
    });

    formRoot.querySelectorAll("[data-field-id]").forEach(function (el) {
      var key = el.getAttribute("data-field-id");
      if (!key) return;
      if (el.tagName === "INPUT" && el.type === "radio") return;

      if (el.tagName === "SELECT" && el.multiple) {
        values[key] = Array.prototype.slice.call(el.selectedOptions).map(function (o) { return o.value; });
      } else if (el.type === "checkbox") {
        values[key] = !!el.checked;
      } else {
        values[key] = el.value;
      }
    });
    return values;
  }

  function evaluateShowIf(showIf, values) {
    if (!showIf || !showIf.length) return true;
    return showIf.every(function (rule) {
      var current = values[rule.field];
      var options = rule.values || [];
      if (!options.length) return false;
      if (Array.isArray(current)) {
        return current.some(function (v) {
          return options.some(function (opt) {
            return storedChoiceMatchesOption(v, opt);
          });
        });
      }
      return options.some(function (opt) {
        return storedChoiceMatchesOption(current, opt);
      });
    });
  }

  function applyVisibility(formRoot, values) {
    formRoot.querySelectorAll("[data-field-wrap]").forEach(function (wrap) {
      var showIfRaw = wrap.getAttribute("data-show-if");
      if (!showIfRaw) {
        wrap.classList.remove("d-none");
        return;
      }
      var showIf;
      try {
        showIf = JSON.parse(showIfRaw.replace(/&apos;/g, "'"));
      } catch (e) {
        showIf = null;
      }
      var visible = evaluateShowIf(showIf, values || {});
      wrap.classList.toggle("d-none", !visible);
      wrap.querySelectorAll("[data-field-id]").forEach(function (el) {
        if (!visible) {
          el.removeAttribute("required");
        } else if (wrap.getAttribute("data-required") === "true" && el.type !== "radio" && el.type !== "checkbox") {
          el.setAttribute("required", "");
        }
      });
    });

    // Hide empty sections so conditionally-gated groups don't show blank headers.
    formRoot.querySelectorAll("[data-form-section='true']").forEach(function (section) {
      var visibleFields = section.querySelectorAll("[data-field-wrap]:not(.d-none)");
      section.classList.toggle("d-none", visibleFields.length === 0);

      // Pair status+comment blocks without relying on CSS :has support.
      var wraps = Array.prototype.slice.call(section.querySelectorAll("[data-field-wrap]"));
      wraps.forEach(function (w) {
        w.classList.remove("paired-with-next", "paired-with-prev", "followup-with-prev");
      });
      for (var i = 0; i < wraps.length - 1; i++) {
        var current = wraps[i];
        var next = wraps[i + 1];
        if (current.classList.contains("d-none") || next.classList.contains("d-none")) continue;
        if (current.classList.contains("field-status") && next.classList.contains("field-comment")) {
          current.classList.add("paired-with-next");
          next.classList.add("paired-with-prev");
        }
        var parentField = next.getAttribute("data-parent-field");
        var currentField = current.getAttribute("data-field-wrap");
        if (parentField && currentField && parentField === currentField) {
          next.classList.add("followup-with-prev");
          current.classList.add("paired-with-next");
        }
      }
    });
  }

  window.SchemaRenderer = {
    renderForm: renderForm,
    collectFormValues: collectFormValues,
    applyVisibility: applyVisibility
  };
})();
