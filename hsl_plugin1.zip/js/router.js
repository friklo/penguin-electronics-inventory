(function () {
  "use strict";

  var ROUTE_CONFIG = {
    groups: {
      earth_bank: {
        id: "earth_bank",
        title: "Earth Bank Testing",
        forms: ["conduct_test"]
      },
      maintenance: {
        id: "maintenance",
        title: "Maintenance",
        forms: [
          "distribution_tx_checklist",
          "entec_switches_maint",
          "magnefix_checklist",
          "poletop_nova_cb_maint",
          "power_tx_checklist",
          "reclosers_sectionalisers",
          "rmu_gas_checklist",
          "rmu_oil_checklist",
          "zone_sub_90d_report",
          "prot_non_self_mon",
          "prot_nsm_checklist",
          "prot_self_mon",
          "prot_sm_checklist",
          "prot_zar_checklist",
          "prot_zs_recloser_ctrl",
          "rmu_comms_checklist",
          "rmu_maint_comms",
          "defect_create"
        ]
      },
      all: {
        id: "all",
        title: "All",
        forms: ["conduct_test",
          "distribution_tx_checklist",
          "entec_switches_maint",
          "magnefix_checklist",
          "poletop_nova_cb_maint",
          "power_tx_checklist",
          "reclosers_sectionalisers",
          "rmu_gas_checklist",
          "rmu_oil_checklist",
          "zone_sub_90d_report",
          "prot_non_self_mon",
          "prot_nsm_checklist",
          "prot_self_mon",
          "prot_sm_checklist",
          "prot_zar_checklist",
          "prot_zs_recloser_ctrl",
          "rmu_comms_checklist",
          "rmu_maint_comms",
          "defect_create",
          "ahi_transformer_gen",
          "ahi_rmcs_rmus",
          "ahi_pole",
          "ahi_oh_switches",
          "ahi_crossarms_ins_pins",
          "fault_response",
          "defect_create"
          
        ]
      },
      inspect_asset: {
        id: "inspect_asset",
        title: "Asset Inspection",
        forms: [
          "ahi_transformer_gen",
          "ahi_rmcs_rmus",
          "ahi_pole",
          "ahi_oh_switches",
          "ahi_crossarms_ins_pins"
        ]
      },
      defect_only: {
        id: "defect_only",
        title: "Defect",
        forms: ["defect_create"]
      },
      fault_only: {
        id: "fault_only",
        title: "Fault",
        forms: ["fault_response"]
      },
      default_group: {
        id: "default_group",
        title: "General Forms",
        forms: []
      }
    },
    activityTypeToGroup: {
      "HEDL Earth Bank Test": "earth_bank",
      HEDL_earth_bank_test: "earth_bank",
      HSL_conduct_test: "earth_bank",
      "HSL Maintenance": "maintenance",
      HSL_maintenance: "maintenance",
      ORA_PLANNED: "maintenance",
      HSL_asset_maintenance: "maintenance",
      HSL_comms_maintenance: "maintenance",
      "HSL Inspect Asset": "inspect_asset",
      HSL_inspect_asset: "all",
      "HEDL Inspect Asset": "inspect_asset",
      HEDL_inspect_Asset: "inspect_asset",
      "HSL Unproductive": "defect_only",
      HSL_unproductive: "defect_only",
      "HSL Asset Works": "defect_only",
      HSL_asset_Works: "defect_only",
      "HSL Auxillary": "defect_only",
      HSL_auxillary: "defect_only",
      "HSL Auxiliary": "defect_only",
      HSL_auxiliary: "defect_only",
      "HSL Vegetation": "defect_only",
      HSL_vegetation: "defect_only",
      "HSL Streetlight": "defect_only",
      HSL_streetlight: "defect_only",
      "HSL Streetlight Fault": "defect_only",
      HSL_streetlight_fault: "defect_only",
      "HEDL Verify Information": "defect_only",
      HEDL_verify_information: "defect_only",
      "HEDL Conductor Clearance Check": "defect_only",
      HEDL_conductor_clearance_ceck: "defect_only",
      "HEDL Cable Locate": "defect_only",
      HEDL_cable_locate: "defect_only",
      "HSL Fault": "fault_only",
      HSL_Fault: "fault_only",
      HSL_fault_response: "fault_only"
    },
    defaultGroup: "default_group"
  };

  function getGroupByActivityType(activityType) {
    var key = String(activityType || "");
    if (ROUTE_CONFIG.activityTypeToGroup[key]) return ROUTE_CONFIG.activityTypeToGroup[key];
    var found = Object.keys(ROUTE_CONFIG.activityTypeToGroup).find(function (k) {
      return k.toLowerCase() === key.toLowerCase();
    });
    return found ? ROUTE_CONFIG.activityTypeToGroup[found] : ROUTE_CONFIG.defaultGroup;
  }

  window.Router = {
    config: ROUTE_CONFIG,
    getGroupByActivityType: getGroupByActivityType,
    getFormsForGroup: function (groupId) {
      var g = ROUTE_CONFIG.groups[groupId] || ROUTE_CONFIG.groups[ROUTE_CONFIG.defaultGroup];
      if (!g) return [];
      if (g.id === ROUTE_CONFIG.defaultGroup && (!g.forms || !g.forms.length)) {
        return (window.FormManifest || []).slice();
      }
      return (g.forms || []).slice();
    }
  };
})();
