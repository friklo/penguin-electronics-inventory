(function () {
  "use strict";

  /** Sentinel tab/panel id for worksheet selection UI (never a real form id). */
  var PICKER_TAB = "__workspace_picker__";

  var AppState = {
    activity: null,
    activityType: "",
    selectedFormIds: [],
    activeFormId: "",
    activeTabId: "",
    formData: {},
    allowedForms: []
  };

  function byId(id) {
    return document.getElementById(id);
  }

  function formatDateTime(isoOrDate) {
    var d = isoOrDate instanceof Date ? isoOrDate : new Date(isoOrDate);
    if (isNaN(d.getTime())) return "-";
    return d.toLocaleString();
  }

  function refreshSheetDateTime() {
    var nowEl = byId("sheetDateTime");
    if (nowEl) nowEl.textContent = formatDateTime(new Date());
  }

  function setLastSaveTime(isoString) {
    var lastEl = byId("sheetLastSave");
    if (!lastEl) return;
    lastEl.textContent = formatDateTime(isoString || new Date());
  }

  function getFormCompletion(formId) {
    var panel = document.querySelector('[data-panel="' + formId + '"]');
    if (!panel) return { complete: false, missing: 0, required: 0, answered: 0, started: false };
    var missing = 0;
    var required = 0;
    var answered = 0;
    panel.querySelectorAll("[data-field-wrap]").forEach(function (wrap) {
      if (wrap.classList.contains("d-none")) return;
      var controls = wrap.querySelectorAll("[data-field-id]");
      if (!controls.length) return;
      var first = controls[0];
      var valid = true;
      if (first.type === "radio") {
        valid = Array.prototype.some.call(controls, function (el) { return !!el.checked; });
      } else if (first.tagName === "SELECT" && first.multiple) {
        valid = (first.selectedOptions || []).length > 0;
      } else if (first.type === "checkbox") {
        valid = !!first.checked;
      } else {
        valid = String(first.value || "").trim() !== "";
      }
      if (valid) answered += 1;
      if (wrap.getAttribute("data-required") !== "true") return;
      required += 1;
      if (!valid) missing += 1;
    });
    var started = answered > 0;
    var complete = required > 0 ? missing === 0 : started;
    return { complete: complete, missing: missing, required: required, answered: answered, started: started };
  }

  function getOverallCompletion() {
    var totalMissing = 0;
    var byForm = {};
    AppState.selectedFormIds.forEach(function (id) {
      var result = getFormCompletion(id);
      byForm[id] = result;
      totalMissing += result.missing;
    });
    return { byForm: byForm, totalMissing: totalMissing };
  }

  function refreshTabStatuses() {
    var tabs = byId("formTabs");
    if (!tabs) return;
    tabs.querySelectorAll("[data-tab]").forEach(function (btn) {
      var formId = btn.getAttribute("data-tab");
      if (!formId || formId === PICKER_TAB) {
        btn.textContent = "Select forms";
        return;
      }
      var cfg = window.FormConfigs[formId];
      if (!cfg) return;
      var c = getFormCompletion(formId);
      var badge = "";
      if (!c.started) {
        badge = ' <span class="badge text-bg-secondary ms-1">Not started</span>';
      } else if (c.complete) {
        badge = ' <span class="badge text-bg-success ms-1">Complete</span>';
      } else {
        badge = ' <span class="badge text-bg-warning ms-1">Missing ' + c.missing + "</span>";
      }
      btn.innerHTML = cfg.title + badge;
    });
  }

  function setStatus(msg, type) {
    var el = byId("statusBar");
    if (!el) return;
    el.className = "alert py-2 px-3 small mb-3 alert-" + (type || "secondary");
    el.textContent = msg;
  }

  function getAllowedFormsForActivity(activityType) {
    var groupId = window.Router.getGroupByActivityType(activityType);
    return window.Router.getFormsForGroup(groupId);
  }

  function hydrateState(activity) {
    AppState.activity = activity || {};
    AppState.activityType = (activity && activity.aworktype) || "";

    var fromActivity = window.StorageManager.loadFromActivity(activity);
    var fromLocal = window.StorageManager.loadLocal();
    var base = Object.assign({}, fromLocal, fromActivity);

    AppState.formData = base.formData || {};
    AppState.selectedFormIds = base.selectedFormIds || [];
    AppState.activeFormId = base.activeFormId || "";
    AppState.activeTabId = "";
  }

  function collectGpsFieldIds(formConfig) {
    var ids = [];
    (formConfig.sections || []).forEach(function (sec) {
      (sec.fields || []).forEach(function (f) {
        var fid = String(f.id || "").toLowerCase();
        var flabel = String(f.label || "").toLowerCase();
        if (!fid) return;
        if (
          fid === "gps_location" ||
          fid === "xa_ws_gps_location" ||
          fid === "gps_coordinates" ||
          fid === "xa_ws_dc_1" ||
          fid.indexOf("gps") >= 0 ||
          flabel.indexOf("gps") >= 0
        ) {
          ids.push(f.id);
        }
      });
    });
    return ids;
  }

  function prefillGpsFromBrowser() {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(function (pos) {
      var lat = pos && pos.coords ? pos.coords.latitude : null;
      var lon = pos && pos.coords ? pos.coords.longitude : null;
      if (lat == null || lon == null) return;
      var gpsValue = String(lat) + "," + String(lon);
      var changed = false;

      AppState.selectedFormIds.forEach(function (formId) {
        var cfg = window.FormConfigs[formId];
        if (!cfg) return;
        var gpsIds = collectGpsFieldIds(cfg);
        if (!gpsIds.length) return;
        if (!AppState.formData[formId]) AppState.formData[formId] = {};
        gpsIds.forEach(function (fid) {
          var current = AppState.formData[formId][fid];
          if (!current) {
            AppState.formData[formId][fid] = gpsValue;
            changed = true;
          }
        });
      });

      if (changed) {
        ensureActiveTabId();
        renderTabs();
        persist(false);
        setStatus("GPS auto-filled from browser location", "info");
      }
    }, function () {
      // User denied or browser blocked location; keep silent fallback.
    }, {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 60000
    });
  }

  function persist(syncToActivity) {
    refreshTabStatuses();
    refreshSheetDateTime();
    var completion = getOverallCompletion();
    var nowIso = new Date().toISOString();
    var payload = {
      activityId: AppState.activity && AppState.activity.aid ? AppState.activity.aid : "",
      activityType: AppState.activityType,
      selectedFormIds: AppState.selectedFormIds,
      activeFormId: AppState.activeFormId,
      formData: AppState.formData,
      savedAt: nowIso,
      completion: completion
    };
    window.StorageManager.saveLocal(payload);
    setLastSaveTime(nowIso);
    if (syncToActivity) {
      if (completion.totalMissing > 0) {
        setStatus("Cannot save yet: " + completion.totalMissing + " mandatory question(s) missing.", "warning");
        return;
      }
      window.StorageManager.saveToActivity(payload);
      setStatus("Saved to activity custom property xa_worksheet_data", "success");
    } else {
      setStatus("Autosaved locally", "secondary");
    }
  }

  function ensureActiveTabId() {
    if (AppState.activeTabId === PICKER_TAB) return;
    if (AppState.activeTabId && AppState.selectedFormIds.indexOf(AppState.activeTabId) >= 0) return;
    if (AppState.activeFormId && AppState.selectedFormIds.indexOf(AppState.activeFormId) >= 0) {
      AppState.activeTabId = AppState.activeFormId;
      return;
    }
    AppState.activeTabId = AppState.selectedFormIds[0] || PICKER_TAB;
  }

  function renderTabs() {
    var tabsEl = byId("formTabs");
    var panels = byId("formPanels");
    var canvas = byId("formCanvas");
    if (!tabsEl || !panels || !canvas) return;

    canvas.classList.remove("d-none");

    var pickerGrid = AppState.allowedForms.map(function (formId) {
      var cfg = window.FormConfigs[formId];
      if (!cfg) return "";
      var selected = AppState.selectedFormIds.indexOf(formId) >= 0;
      var checked = selected ? "checked" : "";
      var itemClass = selected ? "picker-item picker-item-selected" : "picker-item";
      return (
        '<label class="' +
        itemClass +
        '">' +
        '<input class="picker-checkbox" type="checkbox" data-form-check="' +
        formId +
        '" ' +
        checked +
        ">" +
        '<span class="picker-item-label">' +
        cfg.title +
        "</span>" +
        "</label>"
      );
    }).join("");

    var pickerActive = AppState.activeTabId === PICKER_TAB ? "active" : "";
    var pickerHidden = AppState.activeTabId === PICKER_TAB ? "" : "d-none";

    var tabsHtml =
      '<li class="nav-item" role="presentation">' +
      '<button type="button" class="nav-link form-tab-btn ' +
      pickerActive +
      '" role="tab" data-tab="' +
      PICKER_TAB +
      '">Select forms</button>' +
      "</li>";

    tabsHtml += AppState.selectedFormIds.map(function (id) {
      var active = id === AppState.activeTabId ? "active" : "";
      return (
        '<li class="nav-item" role="presentation">' +
        '<button type="button" class="nav-link form-tab-btn ' +
        active +
        '" role="tab" data-tab="' +
        id +
        '"></button>' +
        "</li>"
      );
    }).join("");

    tabsEl.innerHTML = tabsHtml;

    var pickerPanel =
      '<div class="form-panel form-panel-picker ' +
      pickerHidden +
      '" data-panel="' +
      PICKER_TAB +
      '">' +
      '<p class="form-picker-intro text-muted small mb-2 mb-md-3">Tap the worksheets you need below. Selected sheets appear as tabs.</p>' +
      '<div class="form-picker-scroll">' +
      '<div class="picker-grid">' +
      pickerGrid +
      "</div></div></div>";

    var formPanelsHtml = AppState.selectedFormIds.map(function (id) {
      var cfg = window.FormConfigs[id];
      var visible = id === AppState.activeTabId ? "" : "d-none";
      var html = window.SchemaRenderer.renderForm(cfg, AppState.formData[id] || {});
      return '<div class="form-panel ' + visible + '" data-panel="' + id + '">' + html + "</div>";
    }).join("");

    panels.innerHTML = pickerPanel + formPanelsHtml;
    refreshTabStatuses();
    refreshVisibility();
  }

  function refreshVisibility() {
    AppState.selectedFormIds.forEach(function (id) {
      var panel = document.querySelector('[data-panel="' + id + '"]');
      if (!panel) return;
      var values = window.SchemaRenderer.collectFormValues(panel);
      window.SchemaRenderer.applyVisibility(panel, values);
    });
  }

  function sanitizeSelection() {
    AppState.selectedFormIds = AppState.selectedFormIds.filter(function (f) {
      return AppState.allowedForms.indexOf(f) >= 0;
    });
    if (AppState.selectedFormIds.indexOf(AppState.activeFormId) < 0) {
      AppState.activeFormId = AppState.selectedFormIds[0] || "";
    }
  }

  function onRootChange(e) {
    var check = e.target.closest("[data-form-check]");
    if (check) {
      var id = check.getAttribute("data-form-check");
      if (check.checked) {
        if (AppState.selectedFormIds.indexOf(id) < 0) AppState.selectedFormIds.push(id);
        AppState.activeFormId = id;
        AppState.activeTabId = id;
      } else {
        AppState.selectedFormIds = AppState.selectedFormIds.filter(function (f) { return f !== id; });
        if (AppState.activeFormId === id) AppState.activeFormId = AppState.selectedFormIds[0] || "";
        if (AppState.activeTabId === id) AppState.activeTabId = PICKER_TAB;
      }
      ensureActiveTabId();
      renderTabs();
      persist(false);
      return;
    }

    var panel = e.target.closest("[data-panel]");
    if (!panel) return;
    var formId = panel.getAttribute("data-panel");
    if (!formId || formId === PICKER_TAB) return;
    if (e.type === "input") {
      var tg = e.target;
      if (!tg || tg.tagName !== "INPUT" || (tg.type !== "radio" && tg.type !== "checkbox")) return;
    }
    if (!AppState.formData[formId]) AppState.formData[formId] = {};
    window.requestAnimationFrame(function () {
      refreshVisibility();
      AppState.formData[formId] = window.SchemaRenderer.collectFormValues(panel);
      persist(false);
    });
  }

  function onRootClick(e) {
    var tab = e.target.closest("[data-tab]");
    if (tab) {
      var tid = tab.getAttribute("data-tab");
      AppState.activeTabId = tid || AppState.activeFormId;
      if (tid && tid !== PICKER_TAB) AppState.activeFormId = tid;
      renderTabs();
      persist(false);
    }
  }

  function consumeQueuedPrefillIntoFormData() {
    var rows = window.__ofsQueuedPrefill;
    if (!rows || !rows.length) return;
    delete window.__ofsQueuedPrefill;
    var targets = [];
    AppState.selectedFormIds.forEach(function (id) { if (targets.indexOf(id) < 0) targets.push(id); });
    AppState.allowedForms.forEach(function (id) { if (targets.indexOf(id) < 0) targets.push(id); });
    targets.forEach(function (fid) {
      if (!fid || !(window.FormConfigs && window.FormConfigs[fid])) return;
      if (!AppState.formData[fid]) AppState.formData[fid] = {};
      rows.forEach(function (row) {
        var k = row.fieldName || row.fieldId;
        if (!k) return;
        var exists = AppState.formData[fid][k];
        if (exists != null && String(exists).trim() !== "") return;
        AppState.formData[fid][k] = row.value;
      });
    });
  }

  function renderForActivity(activity) {
    hydrateState(activity || {});
    AppState.allowedForms = getAllowedFormsForActivity(AppState.activityType);
    sanitizeSelection();
    consumeQueuedPrefillIntoFormData();

    var label = byId("activityLabel");
    if (label) label.textContent = AppState.activityType ? ("Work Type: " + AppState.activityType) : "Unknown work type";

    ensureActiveTabId();
    renderTabs();
    persist(false);
    prefillGpsFromBrowser();
  }

  function handleClose() {
    if (window.ofscPlugin && typeof window.ofscPlugin.sendPostMessageData === "function") {
      window.ofscPlugin.sendPostMessageData({ apiVersion: 1, method: "close" });
    } else {
      window.parent.postMessage({ apiVersion: 1, method: "close" }, "*");
    }
  }

  function initUi() {
    var app = byId("app");
    if (!app) return;
    refreshSheetDateTime();
    setLastSaveTime("");
    setInterval(refreshSheetDateTime, 1000);
    app.addEventListener("change", onRootChange, true);
    app.addEventListener("input", onRootChange, true);
    app.addEventListener("click", onRootClick);
    byId("saveNowBtn").addEventListener("click", function () { persist(true); });
    byId("closeBtn").addEventListener("click", handleClose);
  }

  function loadAllFormConfigs(done) {
    var ids = window.FormManifest || [];
    var i = 0;
    function next() {
      if (i >= ids.length) {
        done();
        return;
      }
      var id = ids[i++];
      if (window.FormConfigs && window.FormConfigs[id]) {
        next();
        return;
      }
      var s = document.createElement("script");
      s.src = "forms/" + id + ".js";
      s.onload = next;
      s.onerror = next;
      document.head.appendChild(s);
    }
    next();
  }

  function getQueryParam(name) {
    try {
      return new URLSearchParams(window.location.search).get(name);
    } catch (e) {
      return null;
    }
  }

  function tryLoadMockActivity() {
    var mockMode = getQueryParam("mock");
    var shouldMock = mockMode === "1" || window.location.protocol === "file:";
    if (!shouldMock) return;

    var inlineMock = {
      activity: {
        aid: "MOCK-ACT-1001",
        aworktype: "HSL_inspect_asset",
        appt_number: "APT-9001",
        caddress: "123 Demo Street",
        ccity: "Auckland",
        cstate: "AKL",
        czip: "1010",
        latitude: "-36.8485",
        longitude: "174.7633",
        customProperties: {
          xa_worksheet_data: "{\"activityId\":\"MOCK-ACT-1001\",\"activityType\":\"HSL_inspect_asset\",\"selectedFormIds\":[\"ahi_pole\"],\"activeFormId\":\"ahi_pole\",\"formData\":{\"ahi_pole\":{\"asset_number\":\"ASSET-123\",\"location\":\"Demo Yard\",\"feeder\":\"FDR-11\"}},\"savedAt\":\"2026-04-29T10:00:00.000Z\"}"
        }
      }
    };

    var candidates = [
      "./mock/ofsc_open_data.json",
      "mock/ofsc_open_data.json",
      "../mock/ofsc_open_data.json"
    ];

    function tryAt(idx) {
      if (idx >= candidates.length) {
        setStatus("Mock file not found/blocked. Using inline mock data.", "warning");
        window.showWorkTypeContent(inlineMock.activity.aworktype, inlineMock.activity);
        return;
      }
      var path = candidates[idx];
      fetch(path)
        .then(function (r) { return r.ok ? r.json() : null; })
        .then(function (data) {
          if (!data || !data.activity) {
            tryAt(idx + 1);
            return;
          }
          setStatus("Running in mock mode using " + path, "warning");
          window.showWorkTypeContent(data.activity.aworktype, data.activity);
        })
        .catch(function () {
          tryAt(idx + 1);
        });
    }

    tryAt(0);
  }

  // Called by plugin.js on OFSC "open".
  window.showWorkTypeContent = function (aworktype, activity) {
    var data = activity || {};
    if (!data.aworktype && aworktype) data.aworktype = aworktype;
    setStatus("Loaded activity. Rendering forms...", "info");
    renderForActivity(data);
  };

  document.addEventListener("DOMContentLoaded", function () {
    loadAllFormConfigs(function () {
      initUi();
      setStatus("Ready. Waiting for activity...", "secondary");
      tryLoadMockActivity();
    });
  });
})();
