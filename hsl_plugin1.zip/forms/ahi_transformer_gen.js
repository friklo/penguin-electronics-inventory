(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.ahi_transformer_gen = {
  "id": "ahi_transformer_gen",
  "title": "Asset Health Index - INSP - Transformer - General",
  "sections": [
    {
      "title": "General",
      "fields": [
        {
          "id": "xa_ws_i_access",
          "level": 1,
          "label": "Can you access the asset for inspection (including at a distance)? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_i_location",
          "level": 2,
          "label": "Is the asset located in any of the following regions? *",
          "type": "select",
          "options": [
            "NA",
            "Crowded area",
            "Drain/Culvert",
            "Driveway",
            "Pedestrian pathway",
            "Private"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Condition",
      "fields": [
        {
          "id": "xa_ws_i_corro_damg",
          "level": 2,
          "label": "Is there any corrosion or damage? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_mech_miss",
          "level": 2,
          "label": "Is there a mechanical part missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_overload",
          "level": 2,
          "label": "Is there any sign of overload? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_oil_leak",
          "level": 2,
          "label": "Is there a sign of Oil leakage? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_oil_leak_1",
          "level": 2,
          "label": "Is there an oil level issue or leaning that requires urgent maintenance? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_earth",
          "level": 2,
          "label": "Is the earthing system intact? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_ahiitg_9",
          "label": "Is this a GM or OH asset? *",
          "type": "select",
          "options": [
            "GM",
            "OH"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_int_dirt",
          "level": 3,
          "label": "Is there internal vegetation, debris, insects or slugs(bugs)? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiitg_9",
              "values": [
                "GM"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_ext_dirt",
          "level": 3,
          "label": "Is there any external obstruction, vegetation, rubbish and raised ground? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiitg_9",
              "values": [
                "GM"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_tab",
          "level": 3,
          "label": "Record the transformer tap *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiitg_9",
              "values": [
                "GM"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_pd_meas",
          "level": 3,
          "label": "Measure and record the Partial Discharge number in dB up to 3 digits *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiitg_9",
              "values": [
                "GM"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_pd_1000",
          "level": 3,
          "label": "Is there a partial discharge bigger than 20dB? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiitg_9",
              "values": [
                "GM"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_cab_vis",
          "level": 2,
          "label": "Are the cables visible? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insul_damg",
          "level": 3,
          "label": "Is there any insulation damage? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_cab_vis",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_pd",
          "level": 3,
          "label": "Is there any sign of partial discharge (PD) either observed or smelt? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_cab_vis",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_pot_head",
          "level": 3,
          "label": "Is there a leakage or degradation from pitch filled pot head? *",
          "type": "select",
          "options": [
            "NA",
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_cab_vis",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_arrest",
          "level": 3,
          "label": "Are the associated arrestors in place and in good condition? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_cab_vis",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_detero",
          "level": 3,
          "label": "Is there a deterioration due to normal aging without any sign of damage? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_cab_vis",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insul_defm",
          "level": 3,
          "label": "Is any of the insulator sheds deformed at a termination? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_cab_vis",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_ahiitg_yes_no_24",
          "label": "Can a thermal scan be performed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_temp1",
          "level": 3,
          "label": "Is the maximum temperature above 50 degrees of Centigrade? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiitg_yes_no_24",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_comment",
          "level": 2,
          "label": "Additional comments (if any): *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insp_ratng",
          "level": 2,
          "label": "Determine the overall Health Index for the Transformer and the setup *",
          "type": "select",
          "options": [
            "H5 - GOOD OR AS NEW CONDITION",
            "H4 - NEAR NEW CONDITION - NOT YET ONSET OF UNRELIABILITY",
            "H3 - NORMAL DETERIORATION - REQUIRE REGULAR MONITORING",
            "H2 - MATERIAL DETERIORATION - INTERVENTION LIKELY WITHIN 3 YEARS",
            "H1 - END OF SERVICEABLE LIFE - IMMEDIATE INTERVENTION REQUIRED"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    }
  ]
};
})();
