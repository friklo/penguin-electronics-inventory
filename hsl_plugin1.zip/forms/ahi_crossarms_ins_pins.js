(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.ahi_crossarms_ins_pins = {
  "id": "ahi_crossarms_ins_pins",
  "title": "Asset Health Index - INSP - Crossarms, insulators,pins",
  "sections": [
    {
      "title": "First set of crossarms or hardware",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_ahiici_yes_no_1",
          "label": "First set of crossarms or hardware *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "First level of crossarms",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_n_xarm_1_vol",
          "level": 2,
          "label": "Determine the voltage of the first level of crossarms. *",
          "type": "select",
          "options": [
            "NA",
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_1_fu",
          "level": 2,
          "label": "Determine the crossarm material *",
          "type": "select",
          "options": [
            "Fibreglass",
            "Hardwood",
            "Other",
            "Steel"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_1_fun",
          "level": 2,
          "label": "Determine the crosssarm function *",
          "type": "select",
          "options": [
            "NA",
            "DDO ARM",
            "DOUBLE PIN",
            "DOUBLE TERMINATION",
            "SINGLE PIN",
            "SINGLE TERMINATION",
            "SUSPENSION",
            "SUSPENSION - ANGLE",
            "TRAINER ARM",
            "TX HANGER ARM"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm1_con1",
          "level": 2,
          "label": "Are there signs of corrosion, damage, bowing, drill holes deterioration? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm1_con2",
          "level": 2,
          "label": "Are the bolts or nuts corroded, damaged or missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Insulators",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_i_insu1_con1",
          "level": 2,
          "label": "Are the insulators and related pins and nuts damaged, corroded, missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu1_con2",
          "level": 2,
          "label": "Are the Insulators and related pins secured in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu1_con3",
          "level": 2,
          "label": "Are the binders ok? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu2_con1",
          "level": 3,
          "label": "Are the insulators and related pins and nuts damaged, corroded, missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu2_con2",
          "level": 3,
          "label": "Are the Insulators and related pins secured in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu2_con3",
          "level": 3,
          "label": "Are the binders ok? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu3_con1",
          "level": 4,
          "label": "Are the insulators and related pins and nuts damaged, corroded, missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu3_con2",
          "level": 4,
          "label": "Are the Insulators and related pins secured in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu3_con3",
          "level": 4,
          "label": "Are the binders ok? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu4_con1",
          "level": 5,
          "label": "Are the insulators and related pins and nuts damaged, corroded, missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu4_con2",
          "level": 5,
          "label": "Are the Insulators and related pins secured in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu4_con3",
          "level": 5,
          "label": "Are the binders ok? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu5_con1",
          "level": 6,
          "label": "Are the insulators and related pins and nuts damaged, corroded, missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu5_con2",
          "level": 6,
          "label": "Are the Insulators and related pins secured in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insu5_con3",
          "level": 6,
          "label": "Are the binders ok? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Armbraces",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_i_armb1_con1",
          "level": 2,
          "label": "Are the armbraces corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb1_con2",
          "level": 2,
          "label": "Are any bolts or nuts missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb1_con3",
          "level": 2,
          "label": "Are the bolts or nuts corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb2_con1",
          "level": 3,
          "label": "Are the armbraces corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb2_con2",
          "level": 3,
          "label": "Are any bolts or nuts missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb2_con3",
          "level": 3,
          "label": "Are the bolts or nuts corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb3_con1",
          "level": 4,
          "label": "Are the armbraces corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb3_con2",
          "level": 4,
          "label": "Are any bolts or nuts missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb3_con3",
          "level": 4,
          "label": "Are the bolts or nuts corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb4_con1",
          "level": 5,
          "label": "Are the armbraces corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb4_con2",
          "level": 5,
          "label": "Are any bolts or nuts missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb4_con3",
          "level": 5,
          "label": "Are the bolts or nuts corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb5_con1",
          "level": 6,
          "label": "Are the armbraces corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb5_con2",
          "level": 6,
          "label": "Are any bolts or nuts missing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_armb5_con3",
          "level": 6,
          "label": "Are the bolts or nuts corroded? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Jumpers and Connectors",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_i_jumper_thermal_scan_1",
          "label": "Can you perform a thermal scan? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_temp50_1",
          "label": "Is the maximum temperature above 50 \u00b0C? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jumper_thermal_scan_1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump1_con1",
          "level": 2,
          "label": "Are there any Jumpers and Connectors installed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump1_con2",
          "level": 3,
          "label": "Are the Jumpers and Connectors corroded or damaged? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jump1_con1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_thermal_scan_2",
          "label": "Can you perform a thermal scan? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_temp50_2",
          "label": "Is the maximum temperature above 50 \u00b0C? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jumper_thermal_scan_2",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump2_con1",
          "level": 3,
          "label": "Are there any Jumpers and Connectors installed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump2_con2",
          "level": 4,
          "label": "Are the Jumpers and Connectors corroded or damaged? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jump2_con1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_thermal_scan_3",
          "label": "Can you perform a thermal scan? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_temp50_3",
          "label": "Is the maximum temperature above 50 \u00b0C? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jumper_thermal_scan_3",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump3_con1",
          "level": 4,
          "label": "Are there any Jumpers and Connectors installed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump3_con2",
          "level": 5,
          "label": "Are the Jumpers and Connectors corroded or damaged? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jump3_con1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_thermal_scan_4",
          "label": "Can you perform a thermal scan? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_temp50_4",
          "label": "Is the maximum temperature above 50 \u00b0C? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jumper_thermal_scan_4",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump4_con1",
          "level": 5,
          "label": "Are there any Jumpers and Connectors installed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump4_con2",
          "level": 6,
          "label": "Are the Jumpers and Connectors corroded or damaged? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jump4_con1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_thermal_scan_5",
          "label": "Can you perform a thermal scan? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jumper_temp50_5",
          "label": "Is the maximum temperature above 50 \u00b0C? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jumper_thermal_scan_5",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump5_con1",
          "level": 6,
          "label": "Are there any Jumpers and Connectors installed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_jump5_con2",
          "level": 7,
          "label": "Are the Jumpers and Connectors corroded or damaged? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_jump5_con1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Second level of crossarms",
      "level": 3,
      "fields": [
        {
          "id": "xa_ws_n_xarm_2_vol",
          "level": 3,
          "label": "Determine the voltage of the second level of crossarms *",
          "type": "select",
          "options": [
            "NA",
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_2_fu",
          "level": 3,
          "label": "Determine the crossarm material *",
          "type": "select",
          "options": [
            "Fibreglass",
            "Hardwood",
            "Other",
            "Steel"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_2_fun",
          "level": 3,
          "label": "Determine the crossarm function *",
          "type": "select",
          "options": [
            "NA",
            "DDO ARM",
            "DOUBLE PIN",
            "DOUBLE TERMINATION",
            "SINGLE PIN",
            "SINGLE TERMINATION",
            "SUSPENSION",
            "SUSPENSION - ANGLE",
            "TRAINER ARM",
            "TX HANGER ARM"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm2_con1",
          "level": 3,
          "label": "Are there signs of corrosion, damage, bowing, drill holes deterioration? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm2_con2",
          "level": 3,
          "label": "Are the bolts or nuts corroded, damaged or missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Third level of crossarms",
      "level": 4,
      "fields": [
        {
          "id": "xa_ws_n_xarm_3_vol",
          "level": 4,
          "label": "Determine the voltage of the third level of crossarms *",
          "type": "select",
          "options": [
            "NA",
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_3_fu",
          "level": 4,
          "label": "Determine the crossarm material *",
          "type": "select",
          "options": [
            "Fibreglass",
            "Hardwood",
            "Other",
            "Steel"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_3_fun",
          "level": 4,
          "label": "Determine the crossarm function *",
          "type": "select",
          "options": [
            "NA",
            "DDO ARM",
            "DOUBLE PIN",
            "DOUBLE TERMINATION",
            "SINGLE PIN",
            "SINGLE TERMINATION",
            "SUSPENSION",
            "SUSPENSION - ANGLE",
            "TRAINER ARM",
            "TX HANGER ARM"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm3_con1",
          "level": 4,
          "label": "Are there signs of corrosion, damage, bowing, drill holes deterioration? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm3_con2",
          "level": 4,
          "label": "Are the bolts or nuts corroded, damaged or missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Fourth level of crossarms",
      "level": 5,
      "fields": [
        {
          "id": "xa_ws_n_xarm_4_vol",
          "level": 5,
          "label": "Determine the voltage of the fourth level of crossarms. *",
          "type": "select",
          "options": [
            "NA",
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_4_fu",
          "level": 5,
          "label": "Determine the crossarm material *",
          "type": "select",
          "options": [
            "Fibreglass",
            "Hardwood",
            "Other",
            "Steel"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_4_fun",
          "level": 5,
          "label": "Determine the crossarm function *",
          "type": "select",
          "options": [
            "NA",
            "DDO ARM",
            "DOUBLE PIN",
            "DOUBLE TERMINATION",
            "SINGLE PIN",
            "SINGLE TERMINATION",
            "SUSPENSION",
            "SUSPENSION - ANGLE",
            "TRAINER ARM",
            "TX HANGER ARM"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm4_con1",
          "level": 5,
          "label": "Are there signs of corrosion, damage, bowing, drill holes deterioration? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm4_con2",
          "level": 5,
          "label": "Are the bolts or nuts corroded, damaged or missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Fifth level of crossarms",
      "level": 6,
      "fields": [
        {
          "id": "xa_ws_n_xarm_5_vol",
          "level": 6,
          "label": "Determine the voltage of the fifth level of crossarms *",
          "type": "select",
          "options": [
            "NA",
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_5_fu",
          "level": 6,
          "label": "Determine the crossarm material *",
          "type": "select",
          "options": [
            "Fibreglass",
            "Hardwood",
            "Other",
            "Steel"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_xarm_5_fun",
          "level": 6,
          "label": "Determine the crossarm function *",
          "type": "select",
          "options": [
            "NA",
            "DDO ARM",
            "DOUBLE PIN",
            "DOUBLE TERMINATION",
            "SINGLE PIN",
            "SINGLE TERMINATION",
            "SUSPENSION",
            "SUSPENSION - ANGLE",
            "TRAINER ARM",
            "TX HANGER ARM"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm5_con1",
          "level": 6,
          "label": "Are there signs of corrosion, damage, bowing, drill holes deterioration? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_xarm5_con2",
          "level": 6,
          "label": "Are the bolts or nuts corroded, damaged or missing? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_1",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Spigotless DDOs",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_ahiici_yes_no_100",
          "label": "Are there any spigotless DDOs on this pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Joints",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_ahiici_yes_no_102",
          "label": "Are there any full-tension joints on spans attached to this pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ahiici_yes_no_100",
              "values": [
                "YES",
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Cables",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_i_pole_cabl",
          "label": "Are cables present on the pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Cable - Inspection",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_i_cab_volt",
          "level": 2,
          "label": "Determine the voltage of the cable *",
          "type": "select",
          "options": [
            "0.4 KV",
            "11 KV",
            "33 KV",
            "> 33 KV"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_i_pole_cabl",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_pd",
          "level": 2,
          "label": "Is there any sign of partial discharge (PD) either observed or smelt? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_pole_cabl",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_pot_head",
          "level": 2,
          "label": "Is there a leakage or degradation from pitch filled pot head? *",
          "type": "select",
          "options": [
            "NA",
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_pole_cabl",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_arrest",
          "level": 2,
          "label": "Are the associated arrestors in place and in good condition? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_pole_cabl",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_detero",
          "level": 2,
          "label": "Is there a deterioration due to normal aging without any sign of damage? *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_pole_cabl",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_insul_defm",
          "level": 2,
          "label": "Is any of the insulator sheds deformed at a termination? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_pole_cabl",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Comments",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_i_com_ph",
          "level": 1,
          "label": "Additional comments (if any): *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_i_desktop",
          "level": 1,
          "label": "Is this a desktop inspection? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Health Index",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_i_insp_ra_ph",
          "level": 1,
          "label": "Determine the overall Health Index for the asset and the setup *",
          "type": "select",
          "options": [
            "H5 - GOOD OR AS NEW CONDITION",
            "H4 - NEAR NEW CONDITION - NOT YET ONSET OF UNRELIABILITY",
            "H3 - NORMAL DETERIORATION - REQUIRE REGULAR MONITORING",
            "H2 - MATERIAL DETERIORATION - INTERVENTION LIKELY WITHIN 3 YEARS",
            "H1 - END OF SERVICEABLE LIFE - IMMEDIATE INTERVENTION REQUIRED"
          ],
          "required": true
        }
      ]
    }
  ]
};
})();
