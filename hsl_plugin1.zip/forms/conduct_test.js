(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.conduct_test = {
  "id": "conduct_test",
  "title": "Earthing test for all Asset types",
  "sections": [
    {
      "title": "GENERAL INFORMATION",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_g_staff_name",
          "level": 1,
          "label": "Staff Name: *",
          "type": "select",
          "options": [
            "BILLH",
            "CARYG",
            "JOEC",
            "MARIUSB",
            "MOT"
          ],
          "required": true
        },
        {
          "id": "xa_ws_g_insp_date",
          "level": 1,
          "label": "Test Date: *",
          "type": "date",
          "required": true
        },
        {
          "id": "xa_ws_etfaat_5",
          "label": "GPS Location: *",
          "type": "text",
          "required": true,
          "readonly": true
        },
        {
          "id": "xa_ws_g_wip",
          "label": "Please provide the WIP number: *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_g_nav_num",
          "level": 1,
          "label": "Please provide the NAV number: *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_g_equip",
          "level": 1,
          "label": "What test equipment will be used? *",
          "type": "select",
          "options": [
            "Megger DET2/3",
            "Megger DET3TD",
            "Megger Det4TCR2",
            "Other",
            "Other-8"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Test Equipment",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_g_equip_othr",
          "level": 2,
          "label": "Please type in the equipment used (Brand - Model) *",
          "type": "text",
          "required": true
        }
      ]
    },
    {
      "title": "SITE ACCESS",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_g_visual_y_n",
          "level": 1,
          "label": "Is it possible to conduct a visual inspection safely? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Terminating the Inspection",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_g_visual_n_r",
          "level": 2,
          "label": "Please select a reason *",
          "type": "select",
          "options": [
            "Electrical failure",
            "Mechanical / Structure failure",
            "Missing earth wire",
            "No access track",
            "Other",
            "Partial discharge",
            "Private property"
          ],
          "required": true
        },
        {
          "id": "xa_ws_g_visual_n",
          "level": 3,
          "label": "Please provide the reason *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_n_r",
              "values": [
                "Other"
              ]
            },
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "NO",
                "NO-13"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_comment_n",
          "level": 2,
          "label": "Additional comments (if any): *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "NO",
                "NO-13"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "VISUAL OBSERVATION AND TESTING",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_g_asset_id",
          "level": 2,
          "label": "Please provide the asset ID: *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_g_asset_typ",
          "level": 2,
          "label": "Please select the mount type of the asset: *",
          "type": "select",
          "options": [
            "GM",
            "OH"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "OH SPECIFIC OBSERVATIONS",
      "level": 3,
      "fields": [
        {
          "id": "xa_ws_g_asset_oh",
          "level": 3,
          "label": "Please select the OH primary asset/s category: *",
          "type": "select",
          "options": [
            "ABS",
            "Cable 11kV",
            "Cable 33kV",
            "Circuit Breaker",
            "DDO",
            "LV line",
            "Lightning Arrester",
            "Recloser",
            "Sectionaliser",
            "Transformer"
          ],
          "required": true,
          "multiple": true
        }
      ]
    },
    {
      "title": "EARTH WIRE CONNECTIONS (OH)",
      "level": 3,
      "fields": [
        {
          "id": "xa_ws_g_ewire_oh",
          "level": 3,
          "label": "Is the earth wire properly connected to the OH asset/s and to the Earthing Plate on the pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_g_ewire_oh_n",
          "level": 4,
          "label": "Is it possible to fix safely on site? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "OH",
                "OH-23"
              ]
            },
            {
              "field": "xa_ws_g_ewire_oh",
              "values": [
                "NO",
                "NO-27"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_ewire_oh_s",
          "level": 5,
          "label": "Please fix and describe *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "OH",
                "OH-23"
              ]
            },
            {
              "field": "xa_ws_g_ewire_oh",
              "values": [
                "NO",
                "NO-27"
              ]
            },
            {
              "field": "xa_ws_g_ewire_oh_n",
              "values": [
                "YES",
                "YES-29"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_etfaat_34",
          "label": "Please describe and raise defect *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "OH",
                "OH-23"
              ]
            },
            {
              "field": "xa_ws_g_ewire_oh",
              "values": [
                "NO",
                "NO-27"
              ]
            },
            {
              "field": "xa_ws_g_ewire_oh_n",
              "values": [
                "NO",
                "NO-32"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "EARTH WIRE (OH)",
      "level": 3,
      "fields": [
        {
          "id": "xa_ws_g_ewire_szoh",
          "level": 3,
          "label": "What is the size of the earth bank conductor in mm? *",
          "type": "select",
          "options": [
            "NA",
            "16",
            "25",
            "35",
            "50",
            "70",
            "90",
            "Other"
          ],
          "required": true
        },
        {
          "id": "xa_ws_g_ew_szoh_ot",
          "level": 4,
          "label": "Please provide the size of the earth bank conductor in mm *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "OH",
                "OH-23"
              ]
            },
            {
              "field": "xa_ws_g_ewire_szoh",
              "values": [
                "Other"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_ewire_insu",
          "level": 3,
          "label": "Is any of the earth wires insulation damaged? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "OH",
                "OH-23"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_etfaat_41",
          "label": "This is a Fail! Please describe and raise defect *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "OH",
                "OH-23"
              ]
            },
            {
              "field": "xa_ws_g_ewire_insu",
              "values": [
                "YES",
                "YES-39"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "GM SPECIFIC OBSERVATIONS",
      "level": 3,
      "fields": [
        {
          "id": "xa_ws_g_asset_gm",
          "level": 3,
          "label": "Please select the GM primary asset/s category: *",
          "type": "select",
          "options": [
            "Cable 11kV",
            "Cable 33kV",
            "RMC/RMU",
            "Transformer"
          ],
          "required": true,
          "multiple": true
        },
        {
          "id": "xa_ws_g_ewire_gm",
          "level": 3,
          "label": "Are the earthing conductors correctly terminated within the asset? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "N/A"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_etfaat_49",
          "label": "Please describe and raise defect *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43"
              ]
            },
            {
              "field": "xa_ws_g_ewire_gm",
              "values": [
                "NO",
                "NO-47"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "EARTHING TEST — SITE READINESS",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_g_etst_pin",
          "level": 2,
          "label": "Can you drive the test pins into the ground for testing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_g_pin_no_ground_mat",
          "label": "What is the ground material? *",
          "type": "select",
          "options": [
            "ASPHALT",
            "CONCRETE",
            "GRAVEL",
            "OTHER"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43",
                "OH",
                "OH-23"
              ]
            },
            {
              "field": "xa_ws_g_etst_pin",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_pin_no_ground_oth",
          "label": "Other: Please specify *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43",
                "OH",
                "OH-23"
              ]
            },
            {
              "field": "xa_ws_g_etst_pin",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_g_pin_no_ground_mat",
              "values": [
                "OTHER"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_pin_no_wet_towel",
          "label": "Can you conduct a test using the wet-towel method? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43",
                "OH",
                "OH-23"
              ]
            },
            {
              "field": "xa_ws_g_etst_pin",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_pin_no_wet_towel_r",
          "label": "Please provide the reason *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43",
                "OH",
                "OH-23"
              ]
            },
            {
              "field": "xa_ws_g_etst_pin",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_g_pin_no_wet_towel",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_etst_dcn",
          "level": 2,
          "label": "Can the Earth bank(s) be disconnected safely for testing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_asset_typ",
              "values": [
                "GM",
                "GM-43",
                "OH",
                "OH-23"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_etst_dcn_n",
          "level": 3,
          "label": "Please provide the reason *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_etst_dcn",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "SOIL RESISTIVITY",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_g_etest_rho",
          "level": 2,
          "label": "Record test result of soil resistivity in Ohm meter - p test",
          "type": "text",
          "required": false
        }
      ]
    },
    {
      "title": "EARTHING TEST",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_g_etest_y_n",
          "level": 2,
          "label": "Is it possible to safely conduct an earthing test? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_g_etest_n",
          "level": 3,
          "label": "Please provide the reason *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_etest_y_n",
              "values": [
                "NO",
                "NO-61"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_etest_typ",
          "level": 3,
          "label": "What type of earthing test will be conducted? *",
          "type": "select",
          "options": [
            "ART",
            "Four terminal - 4P Test",
            "Three terminal - 3P Test",
            "Two terminal - 2P Test",
            "Two clamp stakeless test",
            "Other"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_etest_y_n",
              "values": [
                "YES",
                "YES-64"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_etest_othr",
          "level": 4,
          "label": "Please type in the name of the earthing test: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_etest_y_n",
              "values": [
                "YES",
                "YES-64"
              ]
            },
            {
              "field": "xa_ws_g_etest_typ",
              "values": [
                "Other",
                "Other-70"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "STANDARD EARTHING TEST RESULTS",
      "level": 3,
      "fields": [
        {
          "id": "xa_ws_g_etest_eb1",
          "level": 3,
          "label": "Record test result of bank 1 (R1) in Ohms (Bank 1 is the bank connected to the highest point on the test link) *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_g_etest_eb2",
          "level": 3,
          "label": "Record test result of bank 2 (R2) in Ohms (Bank 2 is the bank connected to the lowest point on the test link)",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_etest_y_n",
              "values": [
                "YES",
                "YES-64"
              ]
            },
            {
              "field": "xa_ws_g_etest_typ",
              "values": [
                "ART",
                "Four terminal - 4P Test",
                "Three terminal - 3P Test",
                "Two terminal - 2P Test",
                "Two clamp stakeless test",
                "ART-66",
                "Other",
                "Other-70"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_etest_eb3",
          "level": 3,
          "label": "Record test result of lightning arrestor bank (R3) in Ohms (Bank 3 is the bank connected to the lightning arrestor or not directly connected to the test link)",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_etest_y_n",
              "values": [
                "YES",
                "YES-64"
              ]
            },
            {
              "field": "xa_ws_g_etest_typ",
              "values": [
                "ART",
                "Four terminal - 4P Test",
                "Three terminal - 3P Test",
                "Two terminal - 2P Test",
                "Two clamp stakeless test",
                "ART-66",
                "Other",
                "Other-70"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_etest_men",
          "level": 3,
          "label": "Record the test result of MEN link in Ohms",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_etest_y_n",
              "values": [
                "YES",
                "YES-64"
              ]
            },
            {
              "field": "xa_ws_g_etest_typ",
              "values": [
                "ART",
                "Four terminal - 4P Test",
                "Three terminal - 3P Test",
                "Two terminal - 2P Test",
                "Two clamp stakeless test",
                "ART-66",
                "Other",
                "Other-70"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_g_etest_com",
          "level": 3,
          "label": "Testing Comments",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_etest_y_n",
              "values": [
                "YES",
                "YES-64"
              ]
            },
            {
              "field": "xa_ws_g_etest_typ",
              "values": [
                "ART",
                "Four terminal - 4P Test",
                "Three terminal - 3P Test",
                "Two terminal - 2P Test",
                "Two clamp stakeless test",
                "ART-66",
                "Other",
                "Other-70"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "TOUCH & STEP POTENTIAL",
      "level": 3,
      "fields": [
        {
          "id": "xa_ws_g_etest_tpon",
          "level": 3,
          "label": "Record test result of touch potential in Ohms - 4P Terminal test",
          "type": "text",
          "required": false
        },
        {
          "id": "xa_ws_g_etest_spon",
          "level": 3,
          "label": "Record test result of step potential in Ohms - 4P Terminal test",
          "type": "text",
          "required": false,
          "showIf": [
            {
              "field": "xa_ws_g_visual_y_n",
              "values": [
                "YES",
                "YES-20"
              ]
            },
            {
              "field": "xa_ws_g_etest_y_n",
              "values": [
                "YES",
                "YES-64"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "COMMENTS",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_g_comment",
          "level": 2,
          "label": "Additional comments (if any):",
          "type": "text",
          "required": false
        }
      ]
    }
  ]
};
})();
