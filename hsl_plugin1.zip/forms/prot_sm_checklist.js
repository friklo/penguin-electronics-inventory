(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.prot_sm_checklist = {
  "id": "prot_sm_checklist",
  "title": "PROTECTION SYSTEM (SELF MONITORING) MAINTENANCE CHECKLIST",
  "sections": [
    {
      "title": "PROTECTION SYSTEM (SELF MONITORING) MAINTENANCE CHECKLIST",
      "fields": [
        {
          "id": "pssm_asset_num",
          "label": "Asset Number",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_project_no",
          "label": "Project No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_location",
          "label": "Location",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_feeder",
          "label": "Feeder",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_manufacturer",
          "label": "Manufacturer",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_model",
          "label": "Model",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_serial_no",
          "label": "Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_voltage",
          "label": "Voltage",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_test_equip",
          "label": "Test Equipment/Tools Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_test_asset_no",
          "label": "Asset No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_calib_date",
          "label": "Test/Calibration Date",
          "type": "date",
          "required": true
        },
        {
          "id": "pssm_expiry_date",
          "label": "Expiry Date",
          "type": "date",
          "required": true
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "pssm_task1_status",
          "label": "Inspect for damage, wear and tear.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Inspect for damage, wear and tear."
        },
        {
          "id": "pssm_task2_status",
          "label": "Test block current shorting contacts operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Test block current shorting contacts operate correctly."
        },
        {
          "id": "pssm_task3_status",
          "label": "Test block trip isolating mechanism operates correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Test block trip isolating mechanism operates correctly."
        },
        {
          "id": "pssm_task4_status",
          "label": "No loose nuts, screws and components.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "No loose nuts, screws and components."
        },
        {
          "id": "pssm_task5_status",
          "label": "Contacts operate the correct equipment.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Contacts operate the correct equipment."
        },
        {
          "id": "pssm_task6_status",
          "label": "Inputs from other equipment operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Inputs from other equipment operate correctly."
        },
        {
          "id": "pssm_task7_status",
          "label": "Pickup and/or drop-off values of elements correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup and/or drop-off values of elements correct and within tolerance."
        },
        {
          "id": "pssm_task8_status",
          "label": "Operate time delay values correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_task8_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time delay values correct and within tolerance."
        },
        {
          "id": "pssm_task9_status",
          "label": "Block functions and other logic operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_task9_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Block functions and other logic operate correctly."
        },
        {
          "id": "pssm_task10_status",
          "label": "Case and cover clean and free from damage.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_task10_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Case and cover clean and free from damage."
        }
      ]
    },
    {
      "title": "Indications Maintenance Tasks",
      "fields": [
        {
          "id": "pssm_ind_task1_status",
          "label": "Alarms, flags and LEDs operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_ind_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Alarms, flags and LEDs operate correctly."
        },
        {
          "id": "pssm_ind_task2_status",
          "label": "Alarms indication correct locally and remotely.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_ind_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Alarms indication correct locally and remotely."
        },
        {
          "id": "pssm_ind_task3_status",
          "label": "Alarms, flags and LEDs are reset.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_ind_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Alarms, flags and LEDs are reset."
        }
      ]
    },
    {
      "title": "Test Block Maintenance Tasks",
      "fields": [
        {
          "id": "pssm_tb_task1_status",
          "label": "Clean, free from dust and foreign materials.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_tb_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Clean, free from dust and foreign materials."
        },
        {
          "id": "pssm_tb_task2_status",
          "label": "Connections tight and secure.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_tb_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Connections tight and secure."
        },
        {
          "id": "pssm_tb_task3_status",
          "label": "Make and break action of contacts operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_tb_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Make and break action of contacts operate correctly."
        },
        {
          "id": "pssm_tb_task4_status",
          "label": "Covers (where applicable) are fitted.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_tb_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Covers (where applicable) are fitted."
        }
      ]
    },
    {
      "title": "Electrical System Maintenance Tasks",
      "fields": [
        {
          "id": "pssm_fill_0001_status",
          "label": "Cables secure and free of vermin infestation.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0001_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Cables secure and free of vermin infestation."
        },
        {
          "id": "pssm_fill_0002_status",
          "label": "Control wirings secure and free from damage.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0002_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Control wirings secure and free from damage."
        },
        {
          "id": "pssm_fill_0003_status",
          "label": "Terminations tight and secure.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0003_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Terminations tight and secure."
        },
        {
          "id": "pssm_fill_0004_status",
          "label": "AC circuits earthed at one point.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0004_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "AC circuits earthed at one point."
        },
        {
          "id": "pssm_fill_0005_status",
          "label": "Power supply (if applicable) is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0005_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Power supply (if applicable) is correct and within tolerance."
        },
        {
          "id": "pssm_fill_0006_status",
          "label": "Check internal batteries (if applicable) are still suitable.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0006_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check internal batteries (if applicable) are still suitable."
        },
        {
          "id": "pssm_fill_0007_status",
          "label": "DC power supply is wired in the correct polarity.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0007_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "DC power supply is wired in the correct polarity."
        },
        {
          "id": "pssm_fill_0008_status",
          "label": "Trip circuit supervision operates correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0008_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Trip circuit supervision operates correctly."
        },
        {
          "id": "pssm_fill_0009_status",
          "label": "Trip circuit loop resistance within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0009_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Trip circuit loop resistance within tolerance."
        },
        {
          "id": "pssm_fill_0010_status",
          "label": "MCBs and fuses are rated correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0010_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "MCBs and fuses are rated correctly."
        }
      ]
    },
    {
      "title": "Panels and Cubicles Maintenance Tasks",
      "fields": [
        {
          "id": "pssm_fill_0011_status",
          "label": "Clean, free from debris and no signs of vermin infestation.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0011_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Clean, free from debris and no signs of vermin infestation."
        },
        {
          "id": "pssm_fill_0012_status",
          "label": "Free from damage and corrosion acceptable.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0012_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Free from damage and corrosion acceptable."
        },
        {
          "id": "pssm_fill_0013_status",
          "label": "Door and latches open and close effectively.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0013_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Door and latches open and close effectively."
        },
        {
          "id": "pssm_fill_0014_status",
          "label": "Gasket sealing effective and still suitable.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0014_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Gasket sealing effective and still suitable."
        },
        {
          "id": "pssm_fill_0015_status",
          "label": "No signs of water leaks or penetration.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0015_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "No signs of water leaks or penetration."
        },
        {
          "id": "pssm_fill_0016_status",
          "label": "Mounting tight and secure.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0016_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Mounting tight and secure."
        },
        {
          "id": "pssm_notes",
          "label": "Notes",
          "type": "textarea",
          "required": true,
          "rows": 3
        }
      ]
    },
    {
      "title": "Overcurrent Relay \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0053",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0064",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0075",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0017_status",
          "label": "Pickup, drop-off, and time delay for each phase is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0017",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup, drop-off, and time delay for each phase is correct and within tolerance."
        },
        {
          "id": "pssm_fill_0018_status",
          "label": "Operate time of the inverse element at a minimum of two points on the time curve.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0018",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time of the inverse element at a minimum of two points on the time curve."
        },
        {
          "id": "pssm_fill_0019_status",
          "label": "Operate time of the instantaneous or the definite time element at a defined value.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0019",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time of the instantaneous or the definite time element at a defined value."
        },
        {
          "id": "pssm_fill_0020_status",
          "label": "Operate region of a directional element for each phase is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0020",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate region of a directional element for each phase is correct and within tolerance."
        }
      ]
    },
    {
      "title": "Earth Fault \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0054",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0065",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0076",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0021_status",
          "label": "Pickup, drop-off and time delay is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0021",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup, drop-off and time delay is correct and within tolerance."
        },
        {
          "id": "pssm_fill_0022_status",
          "label": "Operate time of the inverse element at a minimum of two points on the time curve.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0022",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time of the inverse element at a minimum of two points on the time curve."
        },
        {
          "id": "pssm_fill_0023_status",
          "label": "Operate time of the instantaneous or the definite time element at a defined value.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0023",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time of the instantaneous or the definite time element at a defined value."
        }
      ]
    },
    {
      "title": "Voltage Relay \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0055",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0066",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0077",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0024_status",
          "label": "Pickup, drop-off and time delay is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0024",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup, drop-off and time delay is correct and within tolerance."
        }
      ]
    },
    {
      "title": "Transformer Differential Relay \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0056",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0067",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0078",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0025_status",
          "label": "Restraint and unrestrained differential current pickup are correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0025",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Restraint and unrestrained differential current pickup are correct and within tolerance."
        },
        {
          "id": "pssm_fill_0026_status",
          "label": "Slope pickup at two points of the slope setting is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0026",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Slope pickup at two points of the slope setting is correct and within tolerance."
        },
        {
          "id": "pssm_fill_0027_status",
          "label": "Operation of the magnetising inrush and harmonic restraint correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0027",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the magnetising inrush and harmonic restraint correct."
        },
        {
          "id": "pssm_fill_0028_status",
          "label": "Operate time delay is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0028",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time delay is correct and within tolerance."
        }
      ]
    },
    {
      "title": "Distance Relay \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0057",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0068",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0079",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0029_status",
          "label": "Pickup reach of a MHO characteristic relay at the characteristic angle for all fault combinations for each zone is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0029",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup reach of a MHO characteristic relay at the characteristic angle for all fault combinations for each zone is correct and within tolerance."
        },
        {
          "id": "pssm_fill_0030_status",
          "label": "Pickup of the resistive reach (0\u00b0/180\u00b0) and reactive reach (+90\u00b0/-90\u00b0) of a quadrilateral characteristic relay for all fault combinations for each zone is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0030",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup of the resistive reach (0\u00b0/180\u00b0) and reactive reach (+90\u00b0/-90\u00b0) of a quadrilateral characteristic relay for all fault combinations for each zone is correct and within tolerance."
        },
        {
          "id": "pssm_fill_0031_status",
          "label": "Operate time delay for all fault combinations for each zone is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0031",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time delay for all fault combinations for each zone is correct and within tolerance."
        },
        {
          "id": "pssm_fill_0032_status",
          "label": "Operation of the switch on to fault logic (SOTF, if enabled) is correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0032",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the switch on to fault logic (SOTF, if enabled) is correct."
        },
        {
          "id": "pssm_fill_0033_status",
          "label": "Operation of the loss of potential logic (LOP, if enabled) is correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0033",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the loss of potential logic (LOP, if enabled) is correct."
        },
        {
          "id": "pssm_fill_0034_status",
          "label": "Operation of the power swing block logic (PSB, if enabled) is correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0034",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the power swing block logic (PSB, if enabled) is correct."
        }
      ]
    },
    {
      "title": "Line Current \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0058",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0069",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0080",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0035_status",
          "label": "Pickup of the operate and restraint current is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0035",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup of the operate and restraint current is correct and within tolerance."
        },
        {
          "id": "pssm_fill_0036_status",
          "label": "Operate region and time delay is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0036",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate region and time delay is correct and within tolerance."
        }
      ]
    },
    {
      "title": "Automatic Voltage Regulator (AVR) \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0059",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0070",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0081",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0037_status",
          "label": "Pickup and drop-off of the raise and lower values correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0037",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup and drop-off of the raise and lower values correct and within tolerance."
        },
        {
          "id": "pssm_fill_0038_status",
          "label": "Initial and interval time delays correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0038",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Initial and interval time delays correct and within tolerance."
        }
      ]
    },
    {
      "title": "Auto Recloser \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0060",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0071",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0082",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0039_status",
          "label": "Reclose and reset time delays are correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0039",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Reclose and reset time delays are correct and within tolerance."
        },
        {
          "id": "pssm_fill_0040_status",
          "label": "Operation of the auto\u2011reclose sequence is correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0040",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the auto\u2011reclose sequence is correct."
        },
        {
          "id": "pssm_fill_0041_status",
          "label": "Auto reclose blocking functions operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0041",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Auto reclose blocking functions operate correctly."
        }
      ]
    },
    {
      "title": "Time Delay Relays \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0061",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0072",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0083",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0042_status",
          "label": "Operate time is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0042",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time is correct and within tolerance."
        }
      ]
    },
    {
      "title": "Trip and Auxiliary Relay \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0062",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0073",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0084",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0043_status",
          "label": "DC voltage pickup and drop\u2011off and/or reset values are correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0043",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "DC voltage pickup and drop\u2011off and/or reset values are correct and within tolerance."
        },
        {
          "id": "pssm_fill_0044_status",
          "label": "Outputs operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0044",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Outputs operate correctly."
        }
      ]
    },
    {
      "title": "Functional \u2013 Specific Tests",
      "fields": [
        {
          "id": "pssm_fill_0063",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0074",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pssm_fill_0085",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0045_status",
          "label": "Outputs operate the correct equipment.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0045",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Outputs operate the correct equipment."
        },
        {
          "id": "pssm_fill_0046_status",
          "label": "Inputs from other devices operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0046",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Inputs from other devices operate correctly."
        },
        {
          "id": "pssm_fill_0047_status",
          "label": "Flags, LEDs and other types of indications operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0047",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Flags, LEDs and other types of indications operate correctly."
        },
        {
          "id": "pssm_fill_0048_status",
          "label": "Alarms operate and correctly indicate locally (local alarm panels, where installed) and remotely (SCADA indications).",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0048",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Alarms operate and correctly indicate locally (local alarm panels, where installed) and remotely (SCADA indications)."
        },
        {
          "id": "pssm_fill_0049_status",
          "label": "Trip coil supervision operates correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0049",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Trip coil supervision operates correctly."
        },
        {
          "id": "pssm_fill_0050_status",
          "label": "Trip circuit loop resistance is within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0050",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Trip circuit loop resistance is within tolerance."
        },
        {
          "id": "pssm_fill_0051_status",
          "label": "Correct circuit breaker tripping and reclosing (where applicable) via the relay.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0051",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Correct circuit breaker tripping and reclosing (where applicable) via the relay."
        },
        {
          "id": "pssm_fill_0052_status",
          "label": "CB controller (local and SCADA where applicable) and indications operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pssm_fill_0052",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "CB controller (local and SCADA where applicable) and indications operate correctly."
        }
      ]
    }
  ]
};
})();
