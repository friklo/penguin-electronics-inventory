(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.ahi_pole = {
  "id": "ahi_pole",
  "title": "Asset Health Index - INSP - Pole",
  "sections": [
    {
      "title": "Access",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_i_access",
          "level": 1,
          "label": "Can you access the asset for inspection (including at a distance)? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Yes - Proceed",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_i_location",
          "level": 2,
          "label": "Is the asset located in any of the following regions? *",
          "type": "select",
          "options": [
            "NA",
            "Crowded area",
            "Drain/Culvert",
            "Driveway",
            "Pedestrian pathway",
            "Private"
          ],
          "required": true,
          "multiple": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_bowing",
          "level": 2,
          "label": "Is the pole bowing in any direction? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_heg_suff",
          "level": 2,
          "label": "Is the height of the pole insufficient for hosting the present assets on it? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_detero_4",
          "level": 2,
          "label": "Determine the level of degradation of the pole *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_stay_wire",
          "level": 2,
          "label": "Is there a stay wire present for the pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_stay_cnd_1",
          "level": 3,
          "label": "If Rusty/Corroded or Broken, Determine the level of the damage. *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_stay_wire",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_type",
          "level": 2,
          "label": "Select the pole material *",
          "type": "select",
          "options": [
            "CONCRETE",
            "STEEL / COMPOSITE",
            "WOODEN"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Concrete",
      "level": 3,
      "fields": [
        {
          "id": "xa_ws_ahiip_11",
          "label": "Select the Pole type manufacturer *",
          "type": "select",
          "options": [
            "BOPE",
            "BUSCK",
            "FIRTH",
            "OPEN BAY",
            "OTHER",
            "RIVERRUN",
            "STAHLTON",
            "STRESS CRETE"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "CONCRETE"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_con_cnd_1",
          "level": 3,
          "label": "Is there any sign of spalling or cracks on the pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "CONCRETE"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_con_cnd_2",
          "level": 4,
          "label": "Determine the level of spalling or cracks *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_con_cnd_1",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "CONCRETE"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_con_cnd_3",
          "level": 3,
          "label": "Is the steel core of the pole exposed and corroded? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "CONCRETE"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_con_cnd_4",
          "level": 4,
          "label": "Determine the level of steel core exposure *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_con_cnd_3",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "CONCRETE"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_corro_damg",
          "level": 4,
          "label": "Determine the level of steel core damage or corrosion *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "CONCRETE"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_con_cnd_5",
          "level": 3,
          "label": "Is there any sign of Calcium leaching (white powder deposit)? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "CONCRETE"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Wooden",
      "level": 3,
      "fields": [
        {
          "id": "xa_ws_ahiip_20",
          "label": "Select the wood type *",
          "type": "select",
          "options": [
            "HARDWOOD",
            "LARCH",
            "OTHER",
            "SOFTWOOD (PINE)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "WOODEN"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_n_pole_cap",
          "level": 3,
          "label": "Is there a pole cap present on the pole? *",
          "type": "radio",
          "options": [
            "YES",
            "NO",
            "NA"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "WOODEN"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_wod_cnd",
          "level": 3,
          "label": "Are there any signs of splitting either at ground or top level? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "WOODEN"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_wod_cnd_1",
          "level": 4,
          "label": "Determine the level of splitting *",
          "type": "select",
          "options": [
            "NONE",
            "SLIGHT (1-20%)",
            "MINOR (21-40%)",
            "MODERATE (41-70%)",
            "MAJOR (71-100%)"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_wod_cnd",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_i_type",
              "values": [
                "WOODEN"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Comments",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_i_comment",
          "level": 2,
          "label": "Additional comments (if any): *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_i_desktop",
          "level": 2,
          "label": "Is this a desktop inspection? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Health Index",
      "level": 2,
      "fields": [
        {
          "id": "xa_ws_i_insp_ratng",
          "level": 2,
          "label": "Determine the overall Health Index for the asset and the setup *",
          "type": "select",
          "options": [
            "H5 - GOOD OR AS NEW CONDITION",
            "H4 - NEAR NEW CONDITION - NOT YET ONSET OF UNRELIABILITY",
            "H3 - NORMAL DETERIORATION - REQUIRE REGULAR MONITORING",
            "H2 - MATERIAL DETERIORATION - INTERVENTION LIKELY WITHIN 3 YEARS",
            "H1 - END OF SERVICEABLE LIFE - IMMEDIATE INTERVENTION REQUIRED"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_i_access",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    }
  ]
};
})();
