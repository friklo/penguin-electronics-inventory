(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.poletop_nova_cb_maint = {
  "id": "poletop_nova_cb_maint",
  "title": "Poletop Nova CB Maintenance Checklist",
  "sections": [
    {
      "title": "Asset & Site",
      "fields": [
        {
          "id": "asset_number",
          "label": "Asset Number",
          "type": "text",
          "required": true
        },
        {
          "id": "project_no",
          "label": "Project No.",
          "type": "text",
          "required": true
        },
        {
          "id": "location",
          "label": "Location",
          "type": "text",
          "required": true
        },
        {
          "id": "feeder",
          "label": "Feeder",
          "type": "text",
          "required": true
        }
      ]
    },
    {
      "title": "Equipment",
      "fields": [
        {
          "id": "manufacturer",
          "label": "Manufacturer",
          "type": "text",
          "required": true
        },
        {
          "id": "model",
          "label": "Model",
          "type": "text",
          "required": true
        },
        {
          "id": "serial_no",
          "label": "Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "voltage",
          "label": "Voltage",
          "type": "text",
          "required": true
        }
      ]
    },
    {
      "title": "Inspection",
      "fields": [
        {
          "id": "inspection_type",
          "label": "Inspection type",
          "type": "text",
          "required": true
        },
        {
          "id": "test_tools",
          "label": "Test equipment / tools used",
          "type": "text",
          "required": true
        },
        {
          "id": "test_asset_no",
          "label": "Asset No.",
          "type": "text",
          "required": true
        },
        {
          "id": "calib_date",
          "label": "Test / calibration date",
          "type": "date",
          "required": true
        },
        {
          "id": "expiry_date",
          "label": "Expiry date",
          "type": "date",
          "required": true
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "cond_1",
          "label": "Safety and hazard assessment of the works",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_1",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Safety and hazard assessment of the works"
        },
        {
          "id": "cond_2",
          "label": "Verify labels and equipment identifiers are installed",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_2",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Verify labels and equipment identifiers are installed"
        },
        {
          "id": "cond_3",
          "label": "Thermal inspection of all HT equipment",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_3",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Thermal inspection of all HT equipment"
        },
        {
          "id": "cond_4",
          "label": "Inspection and operation of bypass switches",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_4",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Inspection and operation of bypass switches"
        },
        {
          "id": "cond_5",
          "label": "Inspection of isolation links for damage or corrosion",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_5",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Inspection of isolation links for damage or corrosion"
        },
        {
          "id": "cond_6",
          "label": "Visual inspection of lightning arresters, local service transformer, and mounting brackets condition",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_6",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Visual inspection of lightning arresters, local service transformer, and mounting brackets condition"
        },
        {
          "id": "cond_7",
          "label": "Verify all fastenings are tight",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_7",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Verify all fastenings are tight"
        },
        {
          "id": "cond_8",
          "label": "Check control box for damage, ants, and weather tightness",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_8",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check control box for damage, ants, and weather tightness"
        },
        {
          "id": "cond_9",
          "label": "Replace communications battery",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_9",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Replace communications battery"
        },
        {
          "id": "cond_10",
          "label": "Verify communication with SCADA and remotely operate open and close from SCADA",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_10",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Verify communication with SCADA and remotely operate open and close from SCADA"
        },
        {
          "id": "cond_11",
          "label": "Inspection of radio antenna and cables",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_11",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Inspection of radio antenna and cables"
        },
        {
          "id": "cond_12",
          "label": "Verify and record communication radio TX power and RX levels",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_12",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Verify and record communication radio TX power and RX levels"
        },
        {
          "id": "cond_13",
          "label": "Apply any vendor required modifications including control firmware as required",
          "type": "select",
          "options": [
            "OK",
            "Attention",
            "Defect",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "comm_13",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Apply any vendor required modifications including control firmware as required"
        }
      ]
    },
    {
      "title": "Tests",
      "fields": [
        {
          "id": "t1_equipment",
          "label": "Equipment",
          "type": "text",
          "required": true,
          "help": "Test manual open controls"
        },
        {
          "id": "t1_serial",
          "label": "Serial no.",
          "type": "text",
          "required": true,
          "help": "Test manual open controls"
        },
        {
          "id": "t1_result",
          "label": "Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true,
          "help": "Test manual open controls"
        },
        {
          "id": "t1_comments",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Test manual open controls"
        },
        {
          "id": "t2_equipment",
          "label": "Equipment",
          "type": "text",
          "required": true,
          "help": "Test Nova protection battery"
        },
        {
          "id": "t2_serial",
          "label": "Serial no.",
          "type": "text",
          "required": true,
          "help": "Test Nova protection battery"
        },
        {
          "id": "t2_result",
          "label": "Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true,
          "help": "Test Nova protection battery"
        },
        {
          "id": "t2_comments",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Test Nova protection battery"
        },
        {
          "id": "t3_equipment",
          "label": "Equipment",
          "type": "text",
          "required": true,
          "help": "Test battery charger float voltage"
        },
        {
          "id": "t3_serial",
          "label": "Serial no.",
          "type": "text",
          "required": true,
          "help": "Test battery charger float voltage"
        },
        {
          "id": "t3_result",
          "label": "Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true,
          "help": "Test battery charger float voltage"
        },
        {
          "id": "t3_comments",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Test battery charger float voltage"
        },
        {
          "id": "t4_equipment",
          "label": "Equipment",
          "type": "text",
          "required": true,
          "help": "Hi pot test as required"
        },
        {
          "id": "t4_serial",
          "label": "Serial no.",
          "type": "text",
          "required": true,
          "help": "Hi pot test as required"
        },
        {
          "id": "t4_result",
          "label": "Result",
          "type": "select",
          "options": [
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true,
          "help": "Hi pot test as required"
        },
        {
          "id": "t4_comments",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Hi pot test as required"
        }
      ]
    },
    {
      "title": "Notes",
      "fields": [
        {
          "id": "notes",
          "label": "Notes",
          "type": "textarea",
          "required": true,
          "rows": 3
        }
      ]
    }
  ]
};
})();
