(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.zone_sub_90d_report = {
  "id": "zone_sub_90d_report",
  "title": "Zone Sub stations 90 days Inspection Report",
  "sections": [
    {
      "title": "Field staff details:",
      "fields": [
        {
          "id": "xa_ws_hazard_done",
          "label": "Have you completed your Hazard ID/Liveline? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_liveline_no",
          "label": "Please record your liveline number for this job: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_hazard_done",
              "values": [
                "YES",
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Zone Substation",
      "fields": [
        {
          "id": "xa_ws_zone_sub",
          "label": "Select the Zone Substation: *",
          "type": "select",
          "options": [
            "EAST BANK ROAD SUBSTATION",
            "GALATEA SUBSTATION",
            "KAINGAROA SUBSTATION",
            "KAWERAU SUBSTATION",
            "KOPE SUBSTATION",
            "NONE",
            "OHOPE SUBSTATION",
            "OPOTIKI SUBSTATION",
            "PLAINS SUBSTATION",
            "STATION ROAD SUBSTATION",
            "TE KAHA SUBSTATION",
            "TE RAHU SWITCHING STATION",
            "WAIOTAHI SUBSTATION"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Single Line Diagrams (SLDs)",
      "fields": [
        {
          "id": "xa_ws_sld_available",
          "label": "Are the SLDs available onsite and up-to-date? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_sld_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_sld_available",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_asset_voltage",
          "label": "Please select the Operating Voltage of the assets to be inspected: *",
          "type": "select",
          "options": [
            "0.4KV",
            "11KV",
            "33KV",
            "50KV"
          ],
          "required": true,
          "multiple": true
        },
        {
          "id": "xa_ws_insulators_ok",
          "label": "Are the Insulators and bushings visually clean, unbroken and secure? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_insulators_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_insulators_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_busbars_ok",
          "label": "Are the Over Head Busbars OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_busbars_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_busbars_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_steelworks_ok",
          "label": "Are the Overhead steelworks OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_steelworks_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_steelworks_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_concrete_ok",
          "label": "Are the Concrete structures OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_concrete_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_concrete_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_ins_earth_ok",
          "label": "Are the Insulators and Bushings OK with secure earth lead connections? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_ins_earth_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ins_earth_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_vtct_ins_ok",
          "label": "Are the Insulators and bushings visually clean, unbroken and secure? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_vtct_ins_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_vtct_ins_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_vtct_struct_ok",
          "label": "Are the Outdoor Structures free of Rust, Corrosion and Leakage? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_vtct_struct_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_vtct_struct_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_silica_ok",
          "label": "Are the Silica gel/dehydrating breathers lubricated/full? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_silica_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_silica_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_oil_vis_ok",
          "label": "Is the Visibility of Oil levels OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_oil_vis_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_oil_vis_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_seismic_ok",
          "label": "Are the Seismic restraints OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_seismic_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_seismic_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_signs_ok",
          "label": "Are the Signs and Information OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_signs_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_signs_ok",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - G11",
      "fields": [
        {
          "id": "xa_ws_cb_g11_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_g11_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_g11_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_g11_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_g11_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_g11_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_g11_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - G12",
      "fields": [
        {
          "id": "xa_ws_cb_g12_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_g12_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_g12_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_g12_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_g12_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_g12_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_g12_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - G13",
      "fields": [
        {
          "id": "xa_ws_cb_g13_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_g13_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_g13_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_g13_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_g13_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_g13_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_g13_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - G14",
      "fields": [
        {
          "id": "xa_ws_cb_g14_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_g14_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_g14_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_g14_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_g14_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_g14_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_g14_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - G15",
      "fields": [
        {
          "id": "xa_ws_cb_g15_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_g15_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_g15_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_g15_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_g15_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_g15_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_g15_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - KA102",
      "fields": [
        {
          "id": "xa_ws_cb_ka102_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_ka102_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_ka102_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_ka102_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_ka102_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_ka102_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_ka102_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - KA202",
      "fields": [
        {
          "id": "xa_ws_cb_ka202_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_ka202_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_ka202_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_ka202_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_ka202_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_ka202_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_ka202_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - KS4",
      "fields": [
        {
          "id": "xa_ws_cb_ks4_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_ks4_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_ks4_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_ks4_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_ks4_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_ks4_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_ks4_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - KS10",
      "fields": [
        {
          "id": "xa_ws_cb_ks10_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_ks10_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_ks10_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_ks10_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_ks10_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_ks10_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_ks10_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - 80",
      "fields": [
        {
          "id": "xa_ws_cb_80_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_80_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_80_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_80_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_80_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_80_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_80_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - P12",
      "fields": [
        {
          "id": "xa_ws_cb_p12_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_p12_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_p12_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_p12_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_p12_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_p12_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_p12_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Outdoor Circuit Breaker Inspection - 62",
      "fields": [
        {
          "id": "xa_ws_cb_62_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_62_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_62_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_62_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_62_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_62_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_62_status",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_sf_6_pressure",
          "label": "Is the SF6 Pressure OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_sf_6_pr_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_sf_6_pressure",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_1042_cyclo",
          "label": "Please record the Cyclometer reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_1042_heater",
          "label": "Is the Cabinet Heater OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_1042_ht_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_1042_heater",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_cb_1042_status",
          "label": "Is the physical status of the CB OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_1042_st_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_1042_status",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Neutral Earthing Resistors (NER)",
      "fields": [
        {
          "id": "xa_ws_ner_present",
          "label": "Is there a NER onsite? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_ner_earthing",
          "label": "Are the Earthing leads intact and OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ner_present",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_ner_e_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ner_earthing",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_ner_present",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_ner_signage",
          "label": "Is the HV isolators signage OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ner_present",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_ner_s_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ner_signage",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_ner_present",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_ner_cabinet",
          "label": "Is the Equipment cabinet physical structure OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ner_present",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_ner_c_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ner_cabinet",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_ner_present",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Local service Tx and Service supply equipment",
      "fields": [
        {
          "id": "xa_ws_serv_ins_ok",
          "label": "Are the Insulators and bushings visually clean, unbroken and secure? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_serv_ins_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_serv_ins_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_supp_struct_ok",
          "label": "Are the Supply structures OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_supp_struct_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_supp_struct_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_sightglass_ok",
          "label": "Are the sight glass/level indicators clean with oil levels clearly visible/correct? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_sightglass_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_sightglass_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_waste_oil_ok",
          "label": "Is the Waste oil tank level within acceptable limits? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_waste_oil_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_waste_oil_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_seals_ok",
          "label": "Are the Health of seals and gaskets OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_seals_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_seals_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_bushing_ok",
          "label": "Are the Bushing conditions OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_bushing_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_bushing_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_label_ok",
          "label": "Labelling - Transformer number label present *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_label_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_label_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_rmc_rust",
          "label": "Is the RMC free of Rust and corrosion? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_rmc_rust_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_rmc_rust",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_rmc_handles",
          "label": "Are the RMC handles free of rust and easy to operate? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_rmc_h_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_rmc_handles",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_rmc_earth",
          "label": "Are the Earth connections secure? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_rmc_e_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_rmc_earth",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_rmc_oil",
          "label": "Are the Oil or SF6 levels OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_rmc_o_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_rmc_oil",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_rmc_oil_leaks",
          "label": "Is the RMC free of signs of Oil Leaks? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_rmc_oil_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_rmc_oil_leaks",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Mobile Generators Check",
      "fields": [
        {
          "id": "xa_ws_mob_gen",
          "label": "Is there a Mobile generator onsite? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_gen_leaks",
          "label": "Are there any fuel, oil or water leaks around? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_gen_l_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_gen_leaks",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_gen_overheat",
          "label": "Is the generator setup over heated? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_gen_oh_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_gen_overheat",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_radio_ok",
          "label": "Is the Radio communication unit working? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_radio_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_radio_ok",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_gen_rust",
          "label": "Are there any rust or corrosion around the setup? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_gen_r_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_gen_rust",
              "values": [
                "YES"
              ]
            },
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_padlocks",
          "label": "Are the padlocks locked? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_pad_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_padlocks",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_gen_gaskets",
          "label": "Are the gaskets on the generators OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_gen_g_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_gen_gaskets",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_vib_abs_ok",
          "label": "Are the generator vibration absorbers OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_vib_abs_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_vib_abs_ok",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_mob_gen",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Substation Buildings",
      "fields": [
        {
          "id": "xa_ws_roofs_ok",
          "label": "Are roofs and gutters free of derbis? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_roofs_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_roofs_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_gutters_ok",
          "label": "Are the Gutters and downpipes are draining freely? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_gutters_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_gutters_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_ext_paint_ok",
          "label": "Is the exterior painted surface is clean and free of graffiti? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_ext_paint_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_ext_paint_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_doors_ok",
          "label": "Are the Doors and windows secure and lockable? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_doors_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_doors_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_emerg_light_ok",
          "label": "Are the emergency lighting systems working? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_emerg_light_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_emerg_light_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_danger_signs_ok",
          "label": "Are the site danger signs are in place and legible from appropriate distances? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_danger_signs_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_danger_signs_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_hazard_board_ok",
          "label": "Is the site hazard board installed inside building and legible? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_hazard_board_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_hazard_board_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_toilets_ok",
          "label": "Are the Toilet and wash facilities are clean, operational and appropriately stocked *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_toilets_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_toilets_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_walls_ok",
          "label": "Are the internal and external walls are in good repair; free of mould, dirt and gaps greater than 1mm? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_walls_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_walls_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_wall_clad_ok",
          "label": "Is the Wall cladding and framing free of deterioration? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_wall_clad_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_wall_clad_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_roof_clad_ok",
          "label": "Are the roof cladding/flashings free from signs of leaks? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_roof_clad_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_roof_clad_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_paint_surfaces_ok",
          "label": "Are the painted surfaces in good repair; free of peeling, flaking and weathering? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_paint_surfaces_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_paint_surfaces_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_latches_ok",
          "label": "Are the door and window latches, locks, hinges effective? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_latches_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_latches_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_window_panes_ok",
          "label": "Are the window panes intact, clean and free of vermin and debris? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_window_panes_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_window_panes_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_door_gaps_ok",
          "label": "Gaps around doors do not exceed 10mm *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_door_gaps_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_door_gaps_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_floors_ok",
          "label": "Are the floors clean; free of moisture, debris, dust and food scraps? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_floors_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_floors_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_taps_ok",
          "label": "Are the taps, basins, sinks, drains, showers and toilets clean, in good working condition, and are free from vermin and debris? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_taps_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_taps_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_drains_ok",
          "label": "Are the drains unblocked and free flowing? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_drains_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_drains_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_drain_openings_ok",
          "label": "Are the drain openings inside the substation building sealed or covered with mesh; no holes greater than 10mm? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_drain_openings_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_drain_openings_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_consumables_ok",
          "label": "Are the consumables restocked (toilet paper, soap, paper towels, gloves)? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_consumables_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_consumables_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_rubbish_ok",
          "label": "Is the rubbish emptied from bins and removed from site? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_rubbish_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_rubbish_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_lightbulbs_ok",
          "label": "Are the Light bulbs and fluorescent tubes working, with all diffusers clean and free from vermin and debris? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_lightbulbs_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_lightbulbs_ok",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Control Panels and Safety Equipment",
      "fields": [
        {
          "id": "xa_ws_indoor_cb_ok",
          "label": "Visual inspection of indoor CBs OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_indoor_cb_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_indoor_cb_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_panels_clean",
          "label": "Are the panels clean and free from dust and oil, vermin and debris? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_panels_details",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_panels_clean",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fire_tags_ok",
          "label": "Are the inspection tags on Fire extinguishers up to date? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_fire_tags_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fire_tags_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_handrails_ok",
          "label": "Are the handrails mechanically sound and firmly fixed in place? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_handrails_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_handrails_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_stairs_ok",
          "label": "Are the stairways mechanically sound, firmly in place, and steps/tread in sound condition? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_stairs_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_stairs_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_safety_notices_ok",
          "label": "Are the Safety notices OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_safety_notices_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_safety_notices_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_e_fence_kv",
          "label": "Electric fence voltage (kV): *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_oil_sep_ok",
          "label": "Does the oil separator test run OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_oil_sep_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_oil_sep_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_radio_check_ok",
          "label": "Are the Radio check OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_radio_check_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_radio_check_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_scada_ok",
          "label": "Is SCADA Operation OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_scada_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_scada_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_batt_conn_ok",
          "label": "Are the Battery connections OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_batt_conn_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_batt_conn_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_batt_charger_ok",
          "label": "Is the battery charger operation OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_batt_charger_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_batt_charger_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_batt_ripple_ok",
          "label": "Is the battery ripple voltage 1mV? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_batt_ripple_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_batt_ripple_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_radio_confirm_ok",
          "label": "Radio check with control room, Confirm with Control and field staff OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_radio_confirm_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_radio_confirm_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_scada_norm_ok",
          "label": "Are the SCADA normal OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_scada_norm_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_scada_norm_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_port_earth_kits_ok",
          "label": "Are the portable earthing kits, substation site ladders, stepladders and safety helmets in sound condition, with annual inspection tags up-to-date? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_port_earth_kits_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_port_earth_kits_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_first_aid_ok",
          "label": "Are the First aid OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_first_aid_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_first_aid_ok",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Site Infrastructure, Access and Security",
      "fields": [
        {
          "id": "xa_ws_access_ok",
          "label": "Are the access ways and parking areas unobstructed and in sound condition? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_access_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_access_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_trench_covers_ok",
          "label": "Are the Trench covers OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_trench_covers_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_trench_covers_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fences_ok",
          "label": "Are the security fences and gates effective and fit for purpose? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_fences_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fences_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_locks_ok",
          "label": "Are the Locks OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_locks_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_locks_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_hazard_signs_ok",
          "label": "Are the hazard signs in place and legible from appropriate distances? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_hazard_signs_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_hazard_signs_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_intruder_alarm_ok",
          "label": "Are the Intruder alarm OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_intruder_alarm_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_intruder_alarm_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_smoke_det_ok",
          "label": "Are the smoke detectors tested and confirmed functional? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_smoke_det_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_smoke_det_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_e_fence_ok",
          "label": "Are the Electric fence OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_e_fence_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_e_fence_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_all_gates_locked",
          "label": "Are all gates locked? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_all_gates_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_all_gates_locked",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_sec_light_ok",
          "label": "Are the Security lighting OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_sec_light_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_sec_light_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_local_icp_reading",
          "label": "Please record the current reading (number) on the local ICP meter *",
          "type": "text",
          "required": true
        }
      ]
    },
    {
      "title": "Site Vegetation, Waterways and Drains",
      "fields": [
        {
          "id": "xa_ws_grass_mown_ok",
          "label": "Is the close mown grass below 75mm in height with edges trimmed? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_grass_mown_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_grass_mown_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_rough_grass_ok",
          "label": "Are the Rough grass OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_rough_grass_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_rough_grass_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_weed_free_ok",
          "label": "Is the site free of weeds when sprayed with weed killer? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_weed_free_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_weed_free_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_unintended_plants_ok",
          "label": "Are the Unintended plants OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_unintended_plants_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_unintended_plants_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_veg_rubbish_ok",
          "label": "Is the site free of vegetation rubbish and trimmings? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_veg_rubbish_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_veg_rubbish_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_weeds_sub_ok",
          "label": "Are the Weeds sub OK? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_weeds_sub_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_weeds_sub_ok",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_add_comments_ok",
          "label": "Are there any additional comments? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_add_comments_det",
          "label": "Please provide details: *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_add_comments_ok",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_partial_discharge",
          "label": "Are any assets displaying measurements or signs of partial discharge? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_partial_dis_asset",
          "label": "Please provide asset numbers and details of failed readings *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_partial_discharge",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Field staff Signature:",
      "fields": [
        {
          "id": "xa_ws_sig_other_staff",
          "label": "Did any other Field staff attend the inspection? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    }
  ]
};
})();
