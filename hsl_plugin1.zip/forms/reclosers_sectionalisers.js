(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.reclosers_sectionalisers = {
  "id": "reclosers_sectionalisers",
  "title": "11kV Line Reclosers and Sectionalisers",
  "sections": [
    {
      "title": "General Information",
      "fields": [
        {
          "id": "xa_ws_date",
          "label": "Date *",
          "type": "date",
          "required": true
        },
        {
          "id": "xa_ws_gps_location",
          "label": "GPS Location *",
          "type": "text",
          "required": true
        }
      ]
    },
    {
      "title": "Visual Observations",
      "fields": [
        {
          "id": "xa_ws_safety_issues_asset",
          "label": "Are there any safety issues with the asset? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Safety Issue Identified",
      "fields": [
        {
          "id": "xa_ws_record_safety_issue",
          "label": "Record the safety issue *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_safety_issues_asset",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Visual Observation",
      "fields": [
        {
          "id": "xa_ws_asset_tag_number",
          "label": "Asset Tag Number *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_service_schedule",
          "label": "Service Schedule *",
          "type": "select",
          "options": [
            "NA",
            "MAJOR",
            "MINOR"
          ],
          "required": true
        },
        {
          "id": "xa_ws_equipment_labelling",
          "label": "Equipment Labelling Inspection *",
          "type": "select",
          "options": [
            "NA",
            "FAULTY",
            "OK"
          ],
          "required": true
        },
        {
          "id": "xa_ws_is_there_a_defect",
          "label": "Is there a defect? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_thermographic_result",
          "label": "Thermographic inspection result *",
          "type": "select",
          "options": [
            "NA",
            "FAULTY",
            "OK"
          ],
          "required": true
        },
        {
          "id": "xa_ws_partial_discharge_result",
          "label": "Partial Discharge Inspection Result *",
          "type": "select",
          "options": [
            "NA",
            "FAULTY",
            "OK"
          ],
          "required": true
        },
        {
          "id": "xa_ws_earthing_conductor_check",
          "label": "Earthing Conductors Visual Inspection *",
          "type": "select",
          "options": [
            "FAULTY",
            "OK"
          ],
          "required": true
        },
        {
          "id": "xa_ws_isolation_links_check",
          "label": "Isolation Links Inspection *",
          "type": "select",
          "options": [
            "FAULTY",
            "OK"
          ],
          "required": true
        },
        {
          "id": "xa_ws_lightning_arrestor_check",
          "label": "Lightening arrestors visual inspection *",
          "type": "select",
          "options": [
            "FAULTY",
            "OK"
          ],
          "required": true
        },
        {
          "id": "xa_ws_arrestor_upgraded_15kv",
          "label": "Has the arrestor been upgraded to 15kV? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_local_service_transformer",
          "label": "Local Service Transformer visual inspection *",
          "type": "select",
          "options": [
            "FAULTY",
            "OK"
          ],
          "required": true
        },
        {
          "id": "xa_ws_cb_mounting_bracket_check",
          "label": "CB/Sectionaliser mounting brackets in good condition *",
          "type": "select",
          "options": [
            "FAULTY",
            "OK"
          ],
          "required": true
        },
        {
          "id": "xa_ws_control_box_check",
          "label": "Control Box visual inspection *",
          "type": "select",
          "options": [
            "FAULTY",
            "OK"
          ],
          "required": true
        },
        {
          "id": "xa_ws_circuit_breaker_check",
          "label": "Visual inspection of Circuit Breaker or Sectionaliser *",
          "type": "select",
          "options": [
            "FAULTY",
            "OK"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Defect Identified",
      "fields": [
        {
          "id": "xa_ws_describe_visual_defect",
          "label": "Describe the visual observation defect *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_is_there_a_defect",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_raise_defect",
          "label": "Raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_is_there_a_defect",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Thermographic Inspection fault identified",
      "fields": [
        {
          "id": "xa_ws_describe_thermo_defect",
          "label": "Describe any themograpic inspection defects *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_thermographic_result",
              "values": [
                "FAULTY"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_if_faulty_raise_defect",
          "label": "If faulty, raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_thermographic_result",
              "values": [
                "FAULTY"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Partial discharge inspection fault identified",
      "fields": [
        {
          "id": "xa_ws_describe_partial_defect",
          "label": "Describe partial discharge inspection defect *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_partial_discharge_result",
              "values": [
                "FAULTY"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_if_faulty_raise_defect_2",
          "label": "If faulty, raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_partial_discharge_result",
              "values": [
                "FAULTY"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Earthing conductor visual fault identified",
      "fields": [
        {
          "id": "xa_ws_if_faulty_raise_defect_3",
          "label": "If faulty, rasie a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_earthing_conductor_check",
              "values": [
                "FAULTY"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Isolation link fault identified",
      "fields": [
        {
          "id": "xa_ws_if_faulty_raise_defect_4",
          "label": "If faulty, raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_isolation_links_check",
              "values": [
                "FAULTY"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Lightening arrestor visual fault identified",
      "fields": [
        {
          "id": "xa_ws_if_faulty_raise_defect_5",
          "label": "If faulty, raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_lightning_arrestor_check",
              "values": [
                "FAULTY"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Arrestor not upgraded to 15kV",
      "fields": [
        {
          "id": "xa_ws_if_not_upgrade_raise_defect",
          "label": "If not upgraded to 15kV, raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_arrestor_upgraded_15kv",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Transformer visual fault identified",
      "fields": [
        {
          "id": "xa_ws_if_faulty_raise_defect_6",
          "label": "If faulty, raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_local_service_transformer",
              "values": [
                "FAULTY"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Mounting bracket fault",
      "fields": [
        {
          "id": "xa_ws_if_faulty_raise_defect_7",
          "label": "If faulty, raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_cb_mounting_bracket_check",
              "values": [
                "FAULTY"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Control box fault",
      "fields": [
        {
          "id": "xa_ws_what_is_wrong",
          "label": "What is wrong? *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_control_box_check",
              "values": [
                "FAULTY"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_fault_repaired_on_site",
          "label": "Fault Repaired On Site *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_control_box_check",
              "values": [
                "FAULTY"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Fault unable to be repaired on site",
      "fields": [
        {
          "id": "xa_ws_if_faulty_raise_defect_8",
          "label": "If faulty, raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_fault_repaired_on_site",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_control_box_check",
              "values": [
                "FAULTY"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "CB or Sectionaliser fault identified",
      "fields": [
        {
          "id": "xa_ws_what_is_wrong_2",
          "label": "What is wrong? *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_circuit_breaker_check",
              "values": [
                "FAULTY"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_if_faulty_raise_defect_9",
          "label": "If faulty, raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_circuit_breaker_check",
              "values": [
                "FAULTY"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Apply switching schedule",
      "fields": [
        {
          "id": "xa_ws_control_room_operation",
          "label": "Control Room Operation Successful? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_test_manual_lock_out",
          "label": "Test Manual Lock Out *",
          "type": "select",
          "options": [
            "FAIL",
            "PASS"
          ],
          "required": true
        },
        {
          "id": "xa_ws_defects_observed_during_switching",
          "label": "Were any other defects observed during switching? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Control Room Operation Failue",
      "fields": [
        {
          "id": "xa_ws_control_room_indication",
          "label": "Control room have received open-closed indication? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_control_room_operation",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_what_is_the_issue",
          "label": "What is the issue? *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_control_room_operation",
              "values": [
                "NO"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_can_manually_operate",
          "label": "Can you manually operate? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_control_room_operation",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Cannot Manually Operate",
      "fields": [
        {
          "id": "xa_ws_what_is_the_issue_2",
          "label": "What is the issue? *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_can_manually_operate",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_control_room_operation",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Control Room Operation Failure",
      "fields": [
        {
          "id": "xa_ws_raise_defect_control_room",
          "label": "Raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_control_room_operation",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Defect observed during switching",
      "fields": [
        {
          "id": "xa_ws_describe_observed_defects",
          "label": "Describe the observed defects *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_defects_observed_during_switching",
              "values": [
                "YES"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_if_faulty_raise_defect_10",
          "label": "If faulty, raise defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_defects_observed_during_switching",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Battery Inspection",
      "fields": [
        {
          "id": "xa_ws_replace_batteries",
          "label": "Replace Batteries *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_all_battery_voltage_test",
          "label": "All battery voltage test (read from relay screen). *",
          "type": "select",
          "options": [
            "FAIL",
            "PASS"
          ],
          "required": true
        },
        {
          "id": "xa_ws_radio_battery_13_8v",
          "label": "Radio Battery float voltage 13.8V *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_entec_battery_27_5v",
          "label": "Entec battery float voltage 27.5V +-0.5V *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_float_voltage_issues",
          "label": "Are there any float voltage issues? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Did not replace batteries",
      "fields": [
        {
          "id": "xa_ws_why_batteries_not_replaced",
          "label": "Why were the batteries not replaced? *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_replace_batteries",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "If all battery voltage test fail",
      "fields": [
        {
          "id": "xa_ws_record_failed_battery_test",
          "label": "Record failed results *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_all_battery_voltage_test",
              "values": [
                "FAIL"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Float voltage issue",
      "fields": [
        {
          "id": "xa_ws_if_float_voltage_raise_defect",
          "label": "If yes, raise a defect. *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_float_voltage_issues",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Radio Inspection",
      "fields": [
        {
          "id": "xa_ws_radio_antenna_cable_check",
          "label": "Radio antenna and cable inspection *",
          "type": "select",
          "options": [
            "FAIL",
            "PASS"
          ],
          "required": true
        },
        {
          "id": "xa_ws_antenna_pan_max_gain",
          "label": "Antenna - Pan for Maximum Gain (Major Service) *",
          "type": "select",
          "options": [
            "COMPLETE",
            "NOT COMPLETE"
          ],
          "required": true
        },
        {
          "id": "xa_ws_radio_function_receive",
          "label": "Radio Function - Receive Signal Level *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_radio_function_noise_floor",
          "label": "Radio Function - Noise floor level *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_radio_function_forward_power",
          "label": "Radio Function - Forward power measurement *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_radio_function_reverse_power",
          "label": "Radio Function - Reverse power measurement *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_radio_function_transmit_power",
          "label": "Radio Functinon - transmit power level setting *",
          "type": "select",
          "options": [
            "12W",
            "1W",
            "25W",
            "5W"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Radio antenna or cable fault",
      "fields": [
        {
          "id": "xa_ws_list_failed_items",
          "label": "List failed items *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_radio_antenna_cable_check",
              "values": [
                "FAIL"
              ]
            }
          ]
        },
        {
          "id": "xa_ws_radio_fault_repaired_on_site",
          "label": "Fault repaired on site? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_radio_antenna_cable_check",
              "values": [
                "FAIL"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Radio antenna or cable fault not repaired on site",
      "fields": [
        {
          "id": "xa_ws_if_antenna_fault_raise_defect",
          "label": "If faulty, raise a defect *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_radio_fault_repaired_on_site",
              "values": [
                "NO"
              ]
            },
            {
              "field": "xa_ws_radio_antenna_cable_check",
              "values": [
                "FAIL"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Equipment Lifecycle",
      "fields": [
        {
          "id": "xa_ws_device_operations_counter",
          "label": "Device operations counter reading *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_cb_duty_cycle_monitor",
          "label": "CB Duty Cycle Monitor reading *",
          "type": "text",
          "required": true
        }
      ]
    },
    {
      "title": "Maintanence Work",
      "fields": [
        {
          "id": "xa_ws_radio_exchanged_serviced",
          "label": "Radio has been exchanged for a serviced unit? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        },
        {
          "id": "xa_ws_nova_relay_firmware_version",
          "label": "Nova relay firmware version? Update to version 5.0 minimum. *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_protection_function_testing",
          "label": "Protection Function testing completed *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    },
    {
      "title": "Radio exchanged for serviced unit",
      "fields": [
        {
          "id": "xa_ws_exchanged_radio_power_level",
          "label": "Is the exchanged radio transmit power level correct? *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_radio_exchanged_serviced",
              "values": [
                "YES"
              ]
            }
          ]
        }
      ]
    },
    {
      "title": "Protection function testing not completed",
      "fields": [
        {
          "id": "xa_ws_comments_maintenance",
          "label": "Comments *",
          "type": "text",
          "required": true,
          "showIf": [
            {
              "field": "xa_ws_protection_function_testing",
              "values": [
                "NO"
              ]
            }
          ]
        }
      ]
    }
  ]
};
})();
