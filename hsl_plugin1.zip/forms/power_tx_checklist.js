(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.power_tx_checklist = {
  "id": "power_tx_checklist",
  "title": "POWER TX MAINTENANCE CHECKLIST",
  "sections": [
    {
      "title": "POWER TX MAINTENANCE CHECKLIST",
      "fields": [
        {
          "id": "ptx_asset_num",
          "label": "Asset Number",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_project_no",
          "label": "Project No.",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_location",
          "label": "Location",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_feeder",
          "label": "Feeder",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_manufacturer",
          "label": "Manufacturer",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_model",
          "label": "Model",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_serial_no",
          "label": "Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_voltage",
          "label": "Voltage",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_test_equip",
          "label": "Test Equipment/Tools Used",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_test_asset_no",
          "label": "Asset No.",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_calib_date",
          "label": "Test/Calibration Date",
          "type": "date",
          "required": true
        },
        {
          "id": "ptx_expiry_date",
          "label": "Expiry Date",
          "type": "date",
          "required": true
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "ptx_task1_status",
          "label": "Visual check of the transformers and all attached componentry, bunding etc.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Visual check of the transformers and all attached componentry, bunding etc."
        },
        {
          "id": "ptx_task2_status",
          "label": "Transformer bolts all checked and torqued to check tightness.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Transformer bolts all checked and torqued to check tightness."
        },
        {
          "id": "ptx_task3_status",
          "label": "Check transformer for rusting; if found, treat and repaint areas as required.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check transformer for rusting; if found, treat and repaint areas as required."
        },
        {
          "id": "ptx_task4_status",
          "label": "Silica gel breather checked; if > 1/3 saturation, replace silica gel unless sealed self\u2011healing breathers.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Silica gel breather checked; if > 1/3 saturation, replace silica gel unless sealed self\u2011healing breathers."
        },
        {
          "id": "ptx_task5_status",
          "label": "Silica gel breather heater checked and tested.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Silica gel breather heater checked and tested."
        },
        {
          "id": "ptx_task6_status",
          "label": "Full exterior clean of the transformer housing. Degrease all oil staining. Note sections for repainting if more than a touch up is required.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Full exterior clean of the transformer housing. Degrease all oil staining. Note sections for repainting if more than a touch up is required."
        },
        {
          "id": "ptx_task7_status",
          "label": "Test OLTC manual operation and note tap changer count for network.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Test OLTC manual operation and note tap changer count for network."
        },
        {
          "id": "ptx_task8_status",
          "label": "TX marshalling box terminations checked and tightened.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task8_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "TX marshalling box terminations checked and tightened."
        },
        {
          "id": "ptx_task9_status",
          "label": "TX manual fan operation on all settings to confirm fans manually engage, work, and are free moving.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task9_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "TX manual fan operation on all settings to confirm fans manually engage, work, and are free moving."
        },
        {
          "id": "ptx_task10_status",
          "label": "TX bund checked, cleaned, and pumps tested.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task10_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "TX bund checked, cleaned, and pumps tested."
        },
        {
          "id": "ptx_task11_status",
          "label": "Oil separator pump checked and tested.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task11_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Oil separator pump checked and tested."
        },
        {
          "id": "ptx_task12_status",
          "label": "Oil separator oil sump emptied and cleaned.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task12_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Oil separator oil sump emptied and cleaned."
        },
        {
          "id": "ptx_task13_status",
          "label": "Oil separator filter checked and replaced.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_task13_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Oil separator filter checked and replaced."
        }
      ]
    },
    {
      "title": "Test Completed",
      "fields": [
        {
          "id": "ptx_test_equip_used",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_test_equip_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "ptx_test_comments",
          "label": "Ptx test comments",
          "type": "textarea",
          "required": true,
          "rows": 3
        },
        {
          "id": "ptx_oil_dga_result",
          "label": "Oil DGA and Furan tests.",
          "type": "text",
          "required": true
        },
        {
          "id": "ptx_oil_dga_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Oil DGA and Furan tests."
        },
        {
          "id": "ptx_notes",
          "label": "Notes",
          "type": "textarea",
          "required": true,
          "rows": 3
        }
      ]
    }
  ]
};
})();
