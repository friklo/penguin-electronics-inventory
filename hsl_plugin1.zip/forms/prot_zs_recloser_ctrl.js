(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.prot_zs_recloser_ctrl = {
  "id": "prot_zs_recloser_ctrl",
  "title": "PROTECTION SYSTEMS MAINTENANCE (ZONE SUBSTATION RECLOSER CONTROLLER) MAINTENANCE CHECKLIST",
  "sections": [
    {
      "title": "General",
      "fields": [
        {
          "id": "pszsrc_asset_num",
          "label": "Asset Number",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_project_no",
          "label": "Project No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_location",
          "label": "Location",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_feeder",
          "label": "Feeder",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_manufacturer",
          "label": "Manufacturer",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_model",
          "label": "Model",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_serial_no",
          "label": "Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_voltage",
          "label": "Voltage",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_test_equip",
          "label": "Test Equipment/Tools Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_test_asset_no",
          "label": "Asset No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_calib_date",
          "label": "Test/Calibration Date",
          "type": "date",
          "required": true
        },
        {
          "id": "pszsrc_expiry_date",
          "label": "Expiry Date",
          "type": "date",
          "required": true
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "pszsrc_task1_status",
          "label": "Inspect for damage, wear and tear.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Inspect for damage, wear and tear."
        },
        {
          "id": "pszsrc_task2_status",
          "label": "Clean, free from dust and foreign materials.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Clean, free from dust and foreign materials."
        },
        {
          "id": "pszsrc_task3_status",
          "label": "Secure and free from damage.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Secure and free from damage."
        },
        {
          "id": "pszsrc_task4_status",
          "label": "Pickup and/or drop-off values of minimum trip correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup and/or drop-off values of minimum trip correct and within tolerance."
        },
        {
          "id": "pszsrc_task5_status",
          "label": "Reclose and reset time delays correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Reclose and reset time delays correct and within tolerance."
        },
        {
          "id": "pszsrc_task6_status",
          "label": "Operation of reclose sequence correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of reclose sequence correct."
        },
        {
          "id": "pszsrc_task7_status",
          "label": "Operation of recloser correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of recloser correct."
        },
        {
          "id": "pszsrc_task8_status",
          "label": "Operation of the block functions correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task8_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the block functions correct."
        },
        {
          "id": "pszsrc_task9_status",
          "label": "Local control commands operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task9_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Local control commands operate correctly."
        },
        {
          "id": "pszsrc_task10_status",
          "label": "Remote control (SCADA operations) operates correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task10_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Remote control (SCADA operations) operates correctly."
        },
        {
          "id": "pszsrc_task11_status",
          "label": "Recloser contact position indication correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_task11_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Recloser contact position indication correct."
        }
      ]
    },
    {
      "title": "Indications Maintenance Tasks",
      "fields": [
        {
          "id": "pszsrc_ind_task1_status",
          "label": "Alarms, flags and LEDs operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ind_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Alarms, flags and LEDs operate correctly."
        },
        {
          "id": "pszsrc_ind_task2_status",
          "label": "Alarms indication correct locally and remotely.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ind_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Alarms indication correct locally and remotely."
        },
        {
          "id": "pszsrc_ind_task3_status",
          "label": "Alarms, flags and LEDs are reset.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ind_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Alarms, flags and LEDs are reset."
        }
      ]
    },
    {
      "title": "Test Block Maintenance Tasks",
      "fields": [
        {
          "id": "pszsrc_tb_task1_status",
          "label": "Clean, free from dust and foreign materials.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tb_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Clean, free from dust and foreign materials."
        },
        {
          "id": "pszsrc_tb_task2_status",
          "label": "Connections tight and secure.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tb_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Connections tight and secure."
        },
        {
          "id": "pszsrc_tb_task3_status",
          "label": "Make and break action of contacts operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tb_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Make and break action of contacts operate correctly."
        },
        {
          "id": "pszsrc_tb_task4_status",
          "label": "Covers (where applicable) are fitted.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tb_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Covers (where applicable) are fitted."
        }
      ]
    },
    {
      "title": "Electrical System Maintenance Tasks",
      "fields": [
        {
          "id": "pszsrc_es_task1_status",
          "label": "Cables secure and free of vermin infestation.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_es_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Cables secure and free of vermin infestation."
        },
        {
          "id": "pszsrc_es_task2_status",
          "label": "Control wirings secure and free from damage.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_es_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Control wirings secure and free from damage."
        },
        {
          "id": "pszsrc_es_task3_status",
          "label": "Terminations tight and secure.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_es_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Terminations tight and secure."
        },
        {
          "id": "pszsrc_es_task4_status",
          "label": "AC circuits earthed at one point.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_es_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "AC circuits earthed at one point."
        },
        {
          "id": "pszsrc_es_task5_status",
          "label": "Power supply (if applicable) is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_es_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Power supply (if applicable) is correct and within tolerance."
        },
        {
          "id": "pszsrc_es_task6_status",
          "label": "Check internal batteries (if applicable) are still suitable.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_es_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check internal batteries (if applicable) are still suitable."
        },
        {
          "id": "pszsrc_es_task7_status",
          "label": "DC power supply is wired in the correct polarity.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_es_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "DC power supply is wired in the correct polarity."
        },
        {
          "id": "pszsrc_es_task8_status",
          "label": "Trip circuit supervision operates correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_es_task8_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Trip circuit supervision operates correctly."
        },
        {
          "id": "pszsrc_es_task9_status",
          "label": "Trip circuit loop resistance within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_es_task9_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Trip circuit loop resistance within tolerance."
        },
        {
          "id": "pszsrc_es_task10_status",
          "label": "MCBs and fuses are rated correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_es_task10_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "MCBs and fuses are rated correctly."
        }
      ]
    },
    {
      "title": "Panels and Cubicles Maintenance Tasks",
      "fields": [
        {
          "id": "pszsrc_pc_task1_status",
          "label": "Clean, free from debris and no signs of vermin infestation.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_pc_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Clean, free from debris and no signs of vermin infestation."
        },
        {
          "id": "pszsrc_pc_task2_status",
          "label": "Free from damage and corrosion acceptable.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_pc_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Free from damage and corrosion acceptable."
        },
        {
          "id": "pszsrc_pc_task3_status",
          "label": "Door and latches open and close effectively.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_pc_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Door and latches open and close effectively."
        },
        {
          "id": "pszsrc_pc_task4_status",
          "label": "Gasket sealing effective and still suitable.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_pc_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Gasket sealing effective and still suitable."
        },
        {
          "id": "pszsrc_pc_task5_status",
          "label": "No signs of water leaks or penetration.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_pc_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "No signs of water leaks or penetration."
        },
        {
          "id": "pszsrc_pc_task6_status",
          "label": "Mounting tight and secure.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_pc_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Mounting tight and secure."
        },
        {
          "id": "pszsrc_notes",
          "label": "Notes",
          "type": "textarea",
          "required": true,
          "rows": 3
        }
      ]
    },
    {
      "title": "Overcurrent Relay \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_ocr_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_ocr_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_ocr_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ocr_test1_status",
          "label": "Pickup, drop-off, and time delay for each phase is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ocr_test1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup, drop-off, and time delay for each phase is correct and within tolerance."
        },
        {
          "id": "pszsrc_ocr_test2_status",
          "label": "Operate time of the inverse element at a minimum of two points on the time curve.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ocr_test2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time of the inverse element at a minimum of two points on the time curve."
        },
        {
          "id": "pszsrc_ocr_test3_status",
          "label": "Operate time of the instantaneous or definite time element at a defined value.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ocr_test3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time of the instantaneous or definite time element at a defined value."
        },
        {
          "id": "pszsrc_ocr_test4_status",
          "label": "Operate region of a directional element for each phase is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ocr_test4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate region of a directional element for each phase is correct and within tolerance."
        }
      ]
    },
    {
      "title": "Earth Fault \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_ef_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_ef_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_ef_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ef_test1_status",
          "label": "Pickup, drop-off and time delay is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ef_test1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup, drop-off and time delay is correct and within tolerance."
        },
        {
          "id": "pszsrc_ef_test2_status",
          "label": "Operate time of the inverse element at a minimum of two points on the time curve.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ef_test2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time of the inverse element at a minimum of two points on the time curve."
        },
        {
          "id": "pszsrc_ef_test3_status",
          "label": "Operate time of the instantaneous or the definite time element at a defined value.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ef_test3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time of the instantaneous or the definite time element at a defined value."
        }
      ]
    },
    {
      "title": "Voltage Relay \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_vr_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_vr_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_vr_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_vr_test1_status",
          "label": "Pickup, drop-off and time delay is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_vr_test1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup, drop-off and time delay is correct and within tolerance."
        }
      ]
    },
    {
      "title": "Transformer Differential Relay \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_tdr_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_tdr_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_tdr_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tdr_test1_status",
          "label": "Restraint and unrestrained differential current pickup are correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tdr_test1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Restraint and unrestrained differential current pickup are correct and within tolerance."
        },
        {
          "id": "pszsrc_tdr_test2_status",
          "label": "Slope pickup at two points of the slope setting is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tdr_test2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Slope pickup at two points of the slope setting is correct and within tolerance."
        },
        {
          "id": "pszsrc_tdr_test3_status",
          "label": "Operation of the magnetising inrush and harmonic restraint correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tdr_test3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the magnetising inrush and harmonic restraint correct."
        },
        {
          "id": "pszsrc_tdr_test4_status",
          "label": "Operate time delay is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tdr_test4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time delay is correct and within tolerance."
        }
      ]
    },
    {
      "title": "Distance Relay \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_dr_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_dr_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_dr_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_dr_test1_status",
          "label": "Pickup reach of a MHO characteristic relay at the characteristic angle for all fault combinations for each zone is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_dr_test1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup reach of a MHO characteristic relay at the characteristic angle for all fault combinations for each zone is correct and within tolerance."
        },
        {
          "id": "pszsrc_dr_test2_status",
          "label": "Pickup of the resistive reach (0\u00b0/180\u00b0) and reactive reach (+90\u00b0/-90\u00b0) of a quadrilateral characteristic relay for all fault combinations for each zone is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_dr_test2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup of the resistive reach (0\u00b0/180\u00b0) and reactive reach (+90\u00b0/-90\u00b0) of a quadrilateral characteristic relay for all fault combinations for each zone is correct and within tolerance."
        },
        {
          "id": "pszsrc_dr_test3_status",
          "label": "Operate time delay for all fault combinations for each zone is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_dr_test3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time delay for all fault combinations for each zone is correct and within tolerance."
        },
        {
          "id": "pszsrc_dr_test4_status",
          "label": "Operation of the switch on to fault logic (SOTF, if enabled) is correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_dr_test4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the switch on to fault logic (SOTF, if enabled) is correct."
        },
        {
          "id": "pszsrc_dr_test5_status",
          "label": "Operation of the loss of potential logic (LOP, if enabled) is correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_dr_test5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the loss of potential logic (LOP, if enabled) is correct."
        },
        {
          "id": "pszsrc_dr_test6_status",
          "label": "Operation of the power swing block logic (PSB, if enabled) is correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_dr_test6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the power swing block logic (PSB, if enabled) is correct."
        }
      ]
    },
    {
      "title": "Line Current \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_lc_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_lc_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_lc_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_lc_test1_status",
          "label": "Pickup of the operate and restraint current is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_lc_test1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup of the operate and restraint current is correct and within tolerance."
        },
        {
          "id": "pszsrc_lc_test2_status",
          "label": "Operate region and time delay is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_lc_test2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate region and time delay is correct and within tolerance."
        }
      ]
    },
    {
      "title": "Automatic Voltage Regulator (AVR) \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_avr_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_avr_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_avr_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_avr_test1_status",
          "label": "Pickup and drop-off of the raise and lower values correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_avr_test1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Pickup and drop-off of the raise and lower values correct and within tolerance."
        },
        {
          "id": "pszsrc_avr_test2_status",
          "label": "Initial and interval time delays correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_avr_test2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Initial and interval time delays correct and within tolerance."
        }
      ]
    },
    {
      "title": "Auto Recloser \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_ar_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_ar_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_ar_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ar_test1_status",
          "label": "Reclose and reset time delays are correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ar_test1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Reclose and reset time delays are correct and within tolerance."
        },
        {
          "id": "pszsrc_ar_test2_status",
          "label": "Operation of the auto\u2011reclose sequence is correct.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ar_test2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operation of the auto\u2011reclose sequence is correct."
        },
        {
          "id": "pszsrc_ar_test3_status",
          "label": "Auto reclose blocking functions operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_ar_test3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Auto reclose blocking functions operate correctly."
        }
      ]
    },
    {
      "title": "Time Delay Relays \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_tdr_test_equip__2",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_tdr_test_serial__2",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_tdr_test_result__2",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tdr_test1_status__2",
          "label": "Operate time is correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tdr_test1_comm__2",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Operate time is correct and within tolerance."
        }
      ]
    },
    {
      "title": "Trip and Auxiliary Relay \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_tar_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_tar_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_tar_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tar_test1_status",
          "label": "DC voltage pickup and drop\u2011off and/or reset values are correct and within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tar_test1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "DC voltage pickup and drop\u2011off and/or reset values are correct and within tolerance."
        },
        {
          "id": "pszsrc_tar_test2_status",
          "label": "Outputs operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_tar_test2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Outputs operate correctly."
        }
      ]
    },
    {
      "title": "Functional \u2013 Specific Tests",
      "fields": [
        {
          "id": "pszsrc_func_test_equip",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_func_test_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "pszsrc_func_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_func_test1_status",
          "label": "Outputs operate the correct equipment.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_func_test1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Outputs operate the correct equipment."
        },
        {
          "id": "pszsrc_func_test2_status",
          "label": "Inputs from other devices operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_func_test2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Inputs from other devices operate correctly."
        },
        {
          "id": "pszsrc_func_test3_status",
          "label": "Flags, LEDs and other types of indications operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_func_test3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Flags, LEDs and other types of indications operate correctly."
        },
        {
          "id": "pszsrc_func_test4_status",
          "label": "Alarms operate and correctly indicate locally (local alarm panels, where installed) and remotely (SCADA indications).",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_func_test4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Alarms operate and correctly indicate locally (local alarm panels, where installed) and remotely (SCADA indications)."
        },
        {
          "id": "pszsrc_func_test5_status",
          "label": "Trip coil supervision operates correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_func_test5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Trip coil supervision operates correctly."
        },
        {
          "id": "pszsrc_func_test6_status",
          "label": "Trip circuit loop resistance is within tolerance.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_func_test6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Trip circuit loop resistance is within tolerance."
        },
        {
          "id": "pszsrc_func_test7_status",
          "label": "Correct circuit breaker tripping and reclosing (where applicable) via the relay.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_func_test7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Correct circuit breaker tripping and reclosing (where applicable) via the relay."
        },
        {
          "id": "pszsrc_func_test8_status",
          "label": "CB controller (local and SCADA where applicable) and indications operate correctly.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "pszsrc_func_test8_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "CB controller (local and SCADA where applicable) and indications operate correctly."
        }
      ]
    }
  ]
};
})();
