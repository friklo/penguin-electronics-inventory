(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.rmu_maint_comms = {
  "id": "rmu_maint_comms",
  "title": "RMU MAINTENANCE (COMMUNICATIONS) MAINTENANCE CHECKLIST",
  "sections": [
    {
      "title": "General",
      "fields": [
        {
          "id": "rmmc_asset_num",
          "label": "Asset Number",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_project_no",
          "label": "Project No.",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_location",
          "label": "Location",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_feeder",
          "label": "Feeder",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_manufacturer",
          "label": "Manufacturer",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_model",
          "label": "Model",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_serial_no",
          "label": "Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_voltage",
          "label": "Voltage",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_test_equip",
          "label": "Test Equipment/Tools Used",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_test_asset_no",
          "label": "Asset No.",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_calib_date",
          "label": "Test/Calibration Date",
          "type": "date",
          "required": true
        },
        {
          "id": "rmmc_expiry_date",
          "label": "Expiry Date",
          "type": "date",
          "required": true
        }
      ]
    },
    {
      "title": "General Tasks",
      "fields": [
        {
          "id": "rmmc_task1_status",
          "label": "Check for signs of imminent failure such as odours or unusual noises.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task1_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check for signs of imminent failure such as odours or unusual noises."
        },
        {
          "id": "rmmc_task2_status",
          "label": "Check all required tools are on hand and have a valid calibration certificate (if required).",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task2_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check all required tools are on hand and have a valid calibration certificate (if required)."
        },
        {
          "id": "rmmc_task3_status",
          "label": "Check all appropriate hazard & equipment ID is present and in good legible condition.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task3_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check all appropriate hazard & equipment ID is present and in good legible condition."
        },
        {
          "id": "rmmc_task4_status",
          "label": "Check all locks are present and in good working condition.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task4_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check all locks are present and in good working condition."
        },
        {
          "id": "rmmc_task5_status",
          "label": "Check voltage indicators (if fitted) are working and showing voltage.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task5_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check voltage indicators (if fitted) are working and showing voltage."
        },
        {
          "id": "rmmc_task6_status",
          "label": "Clean & spray all vegetation build up, weeds, dust and debris away from the asset.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task6_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Clean & spray all vegetation build up, weeds, dust and debris away from the asset."
        },
        {
          "id": "rmmc_task7_status",
          "label": "Check external surface is free from corrosion, electrical discharge/tracking and graffiti.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task7_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check external surface is free from corrosion, electrical discharge/tracking and graffiti."
        },
        {
          "id": "rmmc_task8_status",
          "label": "Check any external visible earth is attached to the unit and not broken or disconnected.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task8_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check any external visible earth is attached to the unit and not broken or disconnected."
        },
        {
          "id": "rmmc_task9_status",
          "label": "Check the correct fuse size is installed if fuse switches are in use and is graded appropriately.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task9_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Check the correct fuse size is installed if fuse switches are in use and is graded appropriately."
        },
        {
          "id": "rmmc_task10_status",
          "label": "Earth conductor is attached (if visible).",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task10_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Earth conductor is attached (if visible)."
        },
        {
          "id": "rmmc_task11_status",
          "label": "Cables wiped, cleaned and there is no scoring or damage to the outer cable sheath.",
          "type": "radio",
          "options": [
            "Done",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_task11_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Cables wiped, cleaned and there is no scoring or damage to the outer cable sheath."
        }
      ]
    },
    {
      "title": "Test Completed",
      "fields": [
        {
          "id": "rmmc_test_equip_used",
          "label": "Test Equipment Used",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_test_equip_serial",
          "label": "Test Equipment Serial No.",
          "type": "text",
          "required": true
        },
        {
          "id": "rmmc_test_result",
          "label": "Test Result",
          "type": "select",
          "options": [
            "Select...",
            "Pass",
            "Fail",
            "N/A"
          ],
          "required": true
        },
        {
          "id": "rmmc_test_comments",
          "label": "Rmmc test comments",
          "type": "textarea",
          "required": true,
          "rows": 3
        },
        {
          "id": "rmmc_pd_result",
          "label": "Perform PD testing & check unit is safe to remove from service.",
          "type": "number",
          "required": true,
          "min": 0,
          "max": 999,
          "step": 1
        },
        {
          "id": "rmmc_pd_comm",
          "label": "Comments",
          "type": "textarea",
          "required": true,
          "rows": 3,
          "help": "Perform PD testing & check unit is safe to remove from service."
        },
        {
          "id": "rmmc_notes",
          "label": "Notes",
          "type": "textarea",
          "required": true,
          "rows": 3
        }
      ]
    }
  ]
};
})();
