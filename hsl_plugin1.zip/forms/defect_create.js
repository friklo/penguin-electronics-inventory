(function () {
  "use strict";

  window.FormConfigs = window.FormConfigs || {};
  window.FormConfigs.defect_create = {
  "id": "defect_create",
  "title": "Defect Create",
  "sections": [
    {
      "title": "Defect Create",
      "level": 1,
      "fields": [
        {
          "id": "xa_ws_dc_1",
          "label": "GPS Location: *",
          "type": "text",
          "required": true,
          "readonly": true
        },
        {
          "id": "xa_ws_dc_2",
          "label": "Defect Priority? *",
          "type": "select",
          "options": [
            "EXTREME PRIORITY - RAISE FAULT",
            "HIGH PRIORITY",
            "LOW PRIORITY",
            "MEDIUM PRIORITY"
          ],
          "required": true
        },
        {
          "id": "xa_ws_dc_5",
          "label": "Address/Location *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_inspclassification02",
          "level": 1,
          "label": "Asset Type *",
          "type": "select",
          "options": [
            "ABS",
            "CABLE",
            "CB/RECLOSER",
            "CONDUCTOR",
            "CONNECTION",
            "CROSSARM",
            "DDO",
            "ENCLOSED SWITCH",
            "FUSE",
            "GUYWIRE",
            "INSULATOR",
            "LIGHTNING ARRESTOR",
            "LINK PILLAR",
            "PILLAR",
            "POLE",
            "POTHEAD",
            "RMU",
            "ROAD CROSSING",
            "SECTIONALISER",
            "STRUCTURE",
            "TRANSFORMER"
          ],
          "required": true
        },
        {
          "id": "xa_ws_dc_7",
          "label": "How long until this asset fails? (failure timeframe) *",
          "type": "select",
          "options": [
            "1. LESS THAN 2 WEEKS",
            "2. 0.5 - 3 MONTHS",
            "3. 3 - 12 MONTHS",
            "4. 12-24 MONTHS",
            "5. 24+ MONTHS"
          ],
          "required": true
        },
        {
          "id": "xa_ws_inspclassification03",
          "level": 1,
          "label": "Failure Mode *",
          "type": "select",
          "options": [
            "01. SPLIT/CRACK",
            "02. ROTTEN",
            "03. CORROSION/RUST",
            "04. OIL LEAK",
            "05. BROKEN",
            "06. SPALLING",
            "07. LOW LINE",
            "08. CHIPPED",
            "09. MELTED/BURNT",
            "10. LEANING",
            "OTHER"
          ],
          "required": true
        },
        {
          "id": "xa_ws_inspclassification01",
          "level": 1,
          "label": "Cause *",
          "type": "select",
          "options": [
            "01. AGE/DEGRADATION",
            "02. ADVERSE WEATHER",
            "03. THIRD PARTY",
            "04. ENVIRONMENTAL (COASTAL, GEOTHERMAL ETC)",
            "05. INSTALLATION ISSUE/POOR WORKMANSHIP",
            "06. ELECTRICAL OVERLOAD/SURGE",
            "07. STRUCTURAL OVERLOAD",
            "08. VEGETATION",
            "09. TYPE ISSUE",
            "10. CAUSE UNKNOWN",
            "OTHER"
          ],
          "required": true
        },
        {
          "id": "xa_ws_faultfounddescription",
          "level": 1,
          "label": "Defect Description *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_correctiveaction",
          "level": 1,
          "label": "Work Required *",
          "type": "text",
          "required": true
        },
        {
          "id": "xa_ws_dc_14",
          "label": "Highest voltage shut required to fix the defect *",
          "type": "select",
          "options": [
            "1. NO OUTAGE REQUIRED",
            "2. LV OUTAGE ONLY",
            "3. HV OUTAGE REQUIRED",
            "4. EHV OUTAGE REQUIRED",
            "5. UNKNOWN"
          ],
          "required": true
        },
        {
          "id": "xa_ws_dc_yes_no_15",
          "label": "Are there any access issues with the site? (locked gates, steep terrain, etc.) *",
          "type": "radio",
          "options": [
            "YES",
            "NO"
          ],
          "required": true
        }
      ]
    }
  ]
};
})();
