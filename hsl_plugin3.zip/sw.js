/* global self, caches */
/**
 * HSL worksheet plugin — offline cache.
 * Bump CACHE_VERSION when assets change so old caches are purged.
 */
(function () {
  "use strict";

  var CACHE_TAG = "hsl-worksheet";
  var CACHE_VERSION = 1;
  var PRECACHE = CACHE_TAG + "-precache-v" + CACHE_VERSION;

  var BOOTSTRAP_CSS =
    "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css";

  /** Keep in sync with forms/manifest.js FormManifest entries. */
  var FORM_IDS = [
    "ahi_crossarms_ins_pins",
    "ahi_oh_switches",
    "ahi_pole",
    "ahi_rmcs_rmus",
    "ahi_transformer_gen",
    "conduct_test",
    "defect_create",
    "distribution_tx_checklist",
    "entec_switches_maint",
    "fault_response",
    "magnefix_checklist",
    "poletop_nova_cb_maint",
    "power_tx_checklist",
    "prot_non_self_mon",
    "prot_nsm_checklist",
    "prot_self_mon",
    "prot_sm_checklist",
    "prot_zar_checklist",
    "prot_zs_recloser_ctrl",
    "reclosers_sectionalisers",
    "rmu_comms_checklist",
    "rmu_gas_checklist",
    "rmu_maint_comms",
    "rmu_oil_checklist",
    "zone_sub_90d_report"
  ];

  function scopeUrl(scope, path) {
    return new URL(path, scope).href;
  }

  function precacheList(scope) {
    var u = function (p) {
      return scopeUrl(scope, p);
    };
    var list = [
      u("index.html"),
      u("plugin.js"),
      u("js/router.js"),
      u("js/schema.js"),
      u("js/storage.js"),
      u("js/app.js"),
      u("js/sw-register.js"),
      u("forms/manifest.js"),
      u("css/styles.css"),
      u("sw.js")
    ];
    FORM_IDS.forEach(function (id) {
      list.push(u("forms/" + id + ".js"));
    });
    list.push(BOOTSTRAP_CSS);
    return list;
  }

  function precacheAll(scope) {
    var urls = precacheList(scope);
    return caches.open(PRECACHE).then(function (cache) {
      return Promise.all(
        urls.map(function (url) {
          return cache.add(url).catch(function () {
            return null;
          });
        })
      );
    });
  }

  function staleWhileRevalidate(request, cacheName) {
    return caches.open(cacheName).then(function (cache) {
      return cache.match(request).then(function (cached) {
        var networkFetch = fetch(request)
          .then(function (response) {
            if (response && response.ok) {
              cache.put(request, response.clone());
            }
            return response;
          })
          .catch(function () {
            return cached;
          });
        if (cached) {
          networkFetch.catch(function () {});
          return cached;
        }
        return networkFetch;
      });
    });
  }

  self.addEventListener("install", function (event) {
    var scope = self.registration.scope;
    event.waitUntil(
      precacheAll(scope)
        .then(function () {
          return self.skipWaiting();
        })
    );
  });

  self.addEventListener("activate", function (event) {
    event.waitUntil(
      caches.keys().then(function (keys) {
        return Promise.all(
          keys.map(function (key) {
            if (key.indexOf(CACHE_TAG) === 0 && key !== PRECACHE) {
              return caches.delete(key);
            }
            return null;
          })
        );
      }).then(function () {
        return self.clients.claim();
      })
    );
  });

  self.addEventListener("fetch", function (event) {
    var req = event.request;
    if (req.method !== "GET") return;

    var url;
    try {
      url = new URL(req.url);
    } catch (e) {
      return;
    }

    if (url.href === BOOTSTRAP_CSS || url.hostname === "cdn.jsdelivr.net") {
      event.respondWith(staleWhileRevalidate(req, PRECACHE));
      return;
    }

    if (url.origin !== self.location.origin) {
      return;
    }

    if (req.mode === "navigate") {
      event.respondWith(
        fetch(req).catch(function () {
          return caches.open(PRECACHE).then(function (cache) {
            return cache.match(scopeUrl(self.registration.scope, "index.html"));
          });
        })
      );
      return;
    }

    event.respondWith(staleWhileRevalidate(req, PRECACHE));
  });
})();
