(function () {
  "use strict";

  if (!("serviceWorker" in navigator)) {
    console.info("[HSL SW] Service workers not supported in this browser.");
    return;
  }

  if (!window.isSecureContext) {
    console.info("[HSL SW] Skipped: needs a secure context (HTTPS or http://localhost).");
    return;
  }

  window.addEventListener("load", function () {
    var swUrl = new URL("sw.js", window.location.href).href;
    navigator.serviceWorker
      .register(swUrl, { type: "classic" })
      .then(function (reg) {
        console.info("[HSL SW] Registered", swUrl, "scope:", reg.scope);
        if (reg.waiting && reg.installing === null) {
          console.info("[HSL SW] New version waiting; activate on next full reload.");
        }
        reg.addEventListener("updatefound", function () {
          var inst = reg.installing;
          if (!inst) return;
          inst.addEventListener("statechange", function () {
            if (inst.state === "installed" && navigator.serviceWorker.controller) {
              console.info("[HSL SW] Installed; reload to use new cache.");
            }
          });
        });
      })
      .catch(function (err) {
        console.warn("[HSL SW] Registration failed:", err);
      });
  });
})();
