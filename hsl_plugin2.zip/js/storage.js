(function () {
  "use strict";

  var STORAGE_KEY = "ofs_data";
  var debounceTimer = null;

  function loadLocal() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  function saveLocal(formData) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(function () {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(formData));
    }, 400);
  }

  function saveToActivity(formData) {
    var aid =
      (formData && formData.activityId) ||
      (window.ofscPlugin && window.ofscPlugin.activityId) ||
      (window.ofscPlugin && window.ofscPlugin.currentActivity && window.ofscPlugin.currentActivity.aid) ||
      "";
    if (!aid) {
      console.warn("[StorageManager.saveToActivity] missing activity id (aid); OFSC update may fail.");
    }
    var jsonStr = JSON.stringify(formData);
    var msg = {
      apiVersion: 1,
      method: "update",
      activity: {
        aid: aid,
        customProperties: {
          xa_worksheet_data: jsonStr
        }
      }
    };
    var target = "*";
    if (window.ofscPlugin && typeof window.ofscPlugin.getOrigin === "function" && document.referrer) {
      target = window.ofscPlugin.getOrigin(document.referrer) || "*";
    }
    console.info("[StorageManager.saveToActivity]", {
      aid: aid,
      xa_worksheet_data_bytes: jsonStr.length,
      postMessage_target: target
    });
    if (window.ofscPlugin && typeof window.ofscPlugin.sendPostMessageData === "function") {
      console.info("[StorageManager.saveToActivity] routing via window.ofscPlugin.sendPostMessageData");
      window.ofscPlugin.sendPostMessageData(msg);
    } else {
      console.info("[StorageManager.saveToActivity] routing via parent.postMessage (no ofscPlugin)");
      window.parent.postMessage(JSON.stringify(msg), target);
    }
  }

  function loadFromActivity(activity) {
    var cp = activity && activity.customProperties;
    var raw = cp && cp.xa_worksheet_data;
    if (!raw) return {};
    try {
      return JSON.parse(raw);
    } catch (e) {
      return {};
    }
  }

  window.StorageManager = {
    loadLocal: loadLocal,
    saveLocal: saveLocal,
    saveToActivity: saveToActivity,
    loadFromActivity: loadFromActivity
  };
})();
